//
//  QDDVerifyTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDVerifyTask.h"

@implementation QDDVerifyTask

@synthesize tel = _tel;

@end
