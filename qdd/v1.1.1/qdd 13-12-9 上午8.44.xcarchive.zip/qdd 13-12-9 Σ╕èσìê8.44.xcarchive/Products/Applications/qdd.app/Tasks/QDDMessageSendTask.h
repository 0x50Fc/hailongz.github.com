//
//  QDDMessageSendTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDMessageSendTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) long long uid;
@property(nonatomic,retain) NSString * body;
@property(nonatomic,retain) UIImage * image;
@property(nonatomic,retain) NSString * imageUri;

@end

@interface QDDMessageSendTask : VTUplinkTask<IQDDMessageSendTask>

@end
