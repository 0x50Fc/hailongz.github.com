//
//  QDDPublishRemoveTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDPublishRemoveTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) long long pid;

@end

@interface QDDPublishRemoveTask : VTUplinkTask<IQDDPublishRemoveTask>

@end
