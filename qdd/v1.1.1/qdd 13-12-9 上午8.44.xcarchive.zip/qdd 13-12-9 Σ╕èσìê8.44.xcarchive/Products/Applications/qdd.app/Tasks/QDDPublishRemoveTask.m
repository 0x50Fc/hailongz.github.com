//
//  QDDPublishRemoveTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishRemoveTask.h"

@implementation QDDPublishRemoveTask

@synthesize pid = _pid;

@end
