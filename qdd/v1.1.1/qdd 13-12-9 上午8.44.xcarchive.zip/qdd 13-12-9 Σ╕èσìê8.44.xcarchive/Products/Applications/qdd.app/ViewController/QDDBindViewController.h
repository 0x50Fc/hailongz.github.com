//
//  QDDBindViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDBindViewController : QDDViewController
@property (strong, nonatomic) IBOutlet UIView *bindView;
@property (strong, nonatomic) IBOutlet UIView *unbindView;
@property (strong, nonatomic) IBOutlet UITableViewCell *bindWeiboCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *unbindWeiboCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *bindQQCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *unbindQQCell;
@property (strong, nonatomic) IBOutlet UIButton *enabledWeiboButton;
@property (strong, nonatomic) IBOutlet UIButton *disabledWeiboButton;
@property (strong, nonatomic) IBOutlet UIButton *enabledQQButton;
@property (strong, nonatomic) IBOutlet UIButton *disabledQQButton;
@property (strong, nonatomic) IBOutlet VTTableSource *tableSource;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)onEnabledAction:(id)sender;
- (IBAction)bindWeiboAction:(id)sender;
- (IBAction)bindQQAction:(id)sender;

@end
