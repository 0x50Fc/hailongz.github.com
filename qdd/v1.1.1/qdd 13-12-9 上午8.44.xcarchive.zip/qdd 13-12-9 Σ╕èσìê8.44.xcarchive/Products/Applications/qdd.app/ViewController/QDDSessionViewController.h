//
//  QDDSessionViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDSessionController.h"

@interface QDDSessionViewController : QDDViewController<IVTUplinkTaskDelegate,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *bodyField;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;
@property (strong, nonatomic) IBOutlet QDDSessionController *sessionController;

- (IBAction)doSendAction:(id)sender;

- (IBAction)doUserAction:(id)sender;

@end
