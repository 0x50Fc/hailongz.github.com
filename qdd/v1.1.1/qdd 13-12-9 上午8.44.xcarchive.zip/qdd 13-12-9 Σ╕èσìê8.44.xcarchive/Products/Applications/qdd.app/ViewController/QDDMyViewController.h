//
//  QDDMyViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDMyViewController : QDDViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,IVTUplinkTaskDelegate>
@property (strong, nonatomic) IBOutlet VTImageView *imageView;
@property (strong, nonatomic) IBOutlet UITextField * nickTextField;
@property(strong,nonatomic) IBOutlet VTStatusView * statusView;
@property (strong, nonatomic) IBOutlet UITextField *cityField;
@property (strong, nonatomic) IBOutlet UITextField *constellationField;
@property (strong, nonatomic) IBOutlet UITextField *jobField;
@property (strong, nonatomic) IBOutlet UITextField *ageField;
@property (strong, nonatomic) IBOutlet UIScrollView *contentView;

- (IBAction)doLogoAction:(id)sender;

- (IBAction)doSaveAction:(id)sender;

-(IBAction) doCancelInputAction:(id)sender;

@end
