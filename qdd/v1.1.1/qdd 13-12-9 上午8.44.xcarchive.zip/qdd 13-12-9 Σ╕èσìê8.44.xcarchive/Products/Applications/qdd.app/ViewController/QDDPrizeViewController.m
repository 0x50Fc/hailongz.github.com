//
//  QDDPrizeViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeViewController.h"

@interface QDDPrizeViewController ()

@end

@implementation QDDPrizeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) dealloc{
    
    [_detailsController cancel];
    
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_detailsController.dataSource isLoaded]
       && ![_detailsController.dataSource isLoading]){
        [_detailsController reloadData];
    }
}

-(void) vtDocumentController:(VTDocumentController *) controller doActionElement:(VTDOMElement *) element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"buy"]){
        
        [self.context setFocusValue:controller.dataItem forKey:@"prize"];
        
        [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/prize/prize-buy"] animated:YES];
        
    }
    
}

@end
