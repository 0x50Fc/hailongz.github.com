//
//  QDDUserDetailsViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDUserFeedController.h"
#import "QDDUserDetailsController.h"

@interface QDDUserDetailsViewController : QDDViewController<QDDUserDetailsControllerDelegate,VTDataControllerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,IVTUplinkTaskDelegate,VTDocumentControllerDelegate>

@property (strong, nonatomic) IBOutlet QDDUserFeedController *feedController;
@property (strong, nonatomic) IBOutlet QDDUserDetailsController *detailsController;
@property (strong, nonatomic) IBOutlet VTTableViewCell *detailsTableViewCell;
@property (strong, nonatomic) IBOutlet UIButton *followButton;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;

- (IBAction)onFollowAction:(id)sender;

@end
