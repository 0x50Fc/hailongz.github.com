//
//  QDDPrizeSearchDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeSearchDataSource.h"

@interface QDDPrizeSearchDataSource(){
    NSTimeInterval _localTime;
}


@end


@implementation QDDPrizeSearchDataSource

-(NSTimeInterval) nowTimestamp{
    return _timestamp + ([[NSDate date] timeIntervalSince1970] - _localTime);
}

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    self.timestamp = [[resultsData dataForKeyPath:self.timestampKey] doubleValue];
    _localTime = [[NSDate date] timeIntervalSince1970];
    
    for(id dataItem in [self dataObjects]){
        
        if([dataItem valueForKey:@"status"] == nil){
            
            NSTimeInterval saleTime = [[dataItem dataForKeyPath:@"saleTime"] doubleValue];
            NSTimeInterval endTime = [[dataItem dataForKeyPath:@"endTime"] doubleValue];
            
            if(_timestamp >= saleTime && _timestamp <= endTime){
                
                [dataItem setValue:@"兑奖中" forKey:@"status"];
                [dataItem setValue:[NSNumber numberWithBool:YES] forKey:@"canBuy"];
            }
            else if(_timestamp < saleTime){
                [dataItem setValue:@"未开始" forKey:@"status"];
            }
            else{
                [dataItem setValue:@"已结束" forKey:@"status"];
            }
            
        }
        
        if([dataItem valueForKey:@"process"] == nil){
            
            NSInteger count = [[dataItem valueForKey:@"count"] intValue];
            NSInteger publishCount = [[dataItem valueForKey:@"publishCount"] intValue];
            
            [dataItem setValue:[NSNumber numberWithDouble:(double)(publishCount - count) / publishCount] forKey:@"process"];
            
            [dataItem setValue:[NSString stringWithFormat:@"%d/%d",publishCount - count,publishCount] forKey:@"processTitle"];
        }
        
    }
    
}

@end
