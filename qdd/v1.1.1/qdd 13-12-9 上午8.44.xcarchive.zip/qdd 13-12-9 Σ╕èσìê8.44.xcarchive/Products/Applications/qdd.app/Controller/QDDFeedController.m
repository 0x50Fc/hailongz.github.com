//
//  QDDFeedController.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFeedController.h"

#import "QDDLikeTask.h"
#import "QDDUnLikeTask.h"

#import <vTeam/VTDOMElement+Render.h>

#import "QDDFeedDocumentController.h"

@interface QDDFeedController()

@property(nonatomic,retain) NSIndexPath * focusIndexPath;

@end

@implementation QDDFeedController


-(void) document:(VTDOMDocument *) document willLoadDataObject:(id)dataObject{
    
    [QDDFeedDocumentController document:document willLoadDataObject:dataObject context:self.context];
    
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

    if(buttonIndex == 0 && _focusIndexPath){
        
        id dataItem = [self dataObjectByIndexPath:_focusIndexPath];
        VTDOMDocument * document = [self documentByIndexPath:_focusIndexPath];
        
        QDDUnLikeTask * task = [[QDDUnLikeTask alloc] init];
        
        [task setIndexPath:_focusIndexPath];
        [task setPid:[[dataItem valueForKey:@"pid"] longLongValue]];
        
        [self.context handle:@protocol(IQDDUnLikeTask) task:task priority:0];
        
        [dataItem setValue:[NSNumber numberWithInt:[[dataItem valueForKey:@"likedCount"] intValue] -1] forKey:@"likedCount"];
        
        [self.dataItem setValue:[NSNumber numberWithBool:NO] forKey:@"liked"];
        
        
        [QDDFeedDocumentController document:document setLiked:NO dataItem:dataItem context:self.context];
    }
    
}

-(void) vtDOMView:(VTDOMView *)view doActionElement:(VTDOMElement *)element{
    
    UITableViewCell * cell = (UITableViewCell *) [view superview];
    
    while(cell && ![cell isKindOfClass:[UITableViewCell class]]){
        
        cell = (UITableViewCell *) [cell superview];
    }
    
    NSIndexPath * indexPath = [self.tableView indexPathForCell:cell];
    
    id dataItem = [self dataObjectByIndexPath:indexPath];
    
    [self.context setFocusValue:dataItem forKey:@"feed"];
    
    if([element conformsToProtocol:@protocol(IVTAction)]) {
        
        NSString * actionName = [(id<IVTAction>)element actionName];
        
        if([actionName isEqualToString:@"like"]){
            
            if(indexPath){
                
                VTDOMDocument * document = [self documentByIndexPath:indexPath];
                
                BOOL liked = [[dataItem valueForKey:@"liked"] boolValue];
                
                if(liked){
                    
                    self.focusIndexPath = indexPath;
                    
                    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"确定不攒了?" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
                    
                    [alertView show];
                    
                    return;
                }
                else{
                    
                    QDDLikeTask * task = [[QDDLikeTask alloc] init];
                    
                    [task setIndexPath:indexPath];
                    [task setPid:[[dataItem valueForKey:@"pid"] longLongValue]];
                    
                    [self.context handle:@protocol(IQDDLikeTask) task:task priority:0];
                    
                    [dataItem setValue:[NSNumber numberWithInt:[[dataItem valueForKey:@"likedCount"] intValue] +1] forKey:@"likedCount"];
                }
                
                [dataItem setValue:[NSNumber numberWithBool:!liked] forKey:@"liked"];
   
                [QDDFeedDocumentController document:document setLiked:!liked dataItem:dataItem context:self.context];
                
            }
        }
        else if([actionName isEqualToString:@"comment"]){
            
            
            [self.context waitResultsData:^(id resultsData) {
               
                if([resultsData boolValue]){
                    
                    VTDOMDocument * document = [self documentByIndexPath:indexPath];
                    
                    id dataItem = [self dataObjectByIndexPath:indexPath];
                    
                    [dataItem setValue:[NSNumber numberWithInt:[[dataItem valueForKey:@"commentCount"] intValue] +1] forKey:@"commentCount"];
                    
                    [QDDFeedDocumentController documentUpdateCommentCount:document dataItem:dataItem];
                    
                    
                }
                
            }];
            
        }
        
    }

    [super vtDOMView:view doActionElement:element];
}

@end
