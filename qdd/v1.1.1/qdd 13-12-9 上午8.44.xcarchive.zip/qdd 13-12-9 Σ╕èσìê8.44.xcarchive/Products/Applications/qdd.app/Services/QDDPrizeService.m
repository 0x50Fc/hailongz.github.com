//
//  QDDPrizeService.m
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeService.h"

#import "QDDPrizeBuyTask.h"

@implementation QDDPrizeService

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDPrizeBuyTask)){
        
        id<IQDDPrizeBuyTask> prizeTask = (id<IQDDPrizeBuyTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDPrizeBuyTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[prizeTask productId]] forKey:@"qdd-productId"];
        
        NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:4];
        
        if([prizeTask address]){
            [data setValue:[prizeTask address] forKey:@"address"];
        }
        
        if([prizeTask postCode]){
            [data setValue:[prizeTask postCode] forKey:@"postCode"];
        }
        
        if([prizeTask name]){
            [data setValue:[prizeTask name] forKey:@"name"];
        }
        
        if([prizeTask other]){
            [data setValue:[prizeTask other] forKey:@"other"];
        }
        
        [body addItemValue:[VTJSON encodeObject:data] forKey:@"qdd-body"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(taskType == @protocol(IVTAPIResponseTask)) {
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDPrizeBuyTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                id results = [[respTask resultsData] dataForKeyPath:@"coin-results"];
                
                if(results){
                    
                    [(id<QDDContext>)self.context setIntegral:[results longLongValue]];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDUserInfoChangedNotification object:nil];
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

@end
