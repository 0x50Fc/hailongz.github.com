//
//  QDDInviteDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteDataSource.h"

@implementation QDDInviteDataSource

-(id) dataObjectAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section < [_sections count]){
        NSMutableDictionary * section = [_sections objectAtIndex:indexPath.section];
        NSArray * items = [section valueForKey:@"items"];
        if(indexPath.row < [items count]){
            return [items objectAtIndex:indexPath.row];
        }
    }
    return nil;
}

-(id) valueForKey:(NSString *)key{
    if([key isEqualToString:@"sections"]){
        return [self sections];
    }
    return [super valueForKey:key];
}

-(BOOL) isEmpty{
    return [_sections count] ==0;
}

@end
