//
//  QDDDaytopDataSource.m
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDDaytopDataSource.h"

@interface QDDDaytopDataSource()

@property(nonatomic,readonly) NSDateFormatter * dateFormatter;

@end

@implementation QDDDaytopDataSource

@synthesize dateFormatter = _dateFormatter;

-(NSDateFormatter *) dateFormatter{
    if(_dateFormatter == nil){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return _dateFormatter;
}

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    for(id dataItem in [self dataObjects]){
        
        if([dataItem stringValueForKey:@"fmtDay"] == nil){
            
            NSDateFormatter * dateFormatter = [self dateFormatter];
            
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
            
            NSDate * date = [dateFormatter dateFromString:[dataItem stringValueForKey:@"day"]];
            
            [dateFormatter setDateFormat:@"dd"];
            
            [dataItem setObjectValue:[dateFormatter stringFromDate:date] forKey:@"fmtDay"];
            
            [dateFormatter setDateFormat:@"yyyy年MM月"];
            
            [dataItem setObjectValue:[dateFormatter stringFromDate:date] forKey:@"fmtYearMonth"];
            
        }
        
    }
}
@end
