//
//  QDDInviteWeiboDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-12-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteWeiboDataSource.h"

@implementation QDDInviteWeiboDataSource

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];

    id dataObject = [self dataObject];
    
    NSMutableArray * sections = [NSMutableArray arrayWithCapacity:4];
    
    NSArray * users = [dataObject dataForKeyPath:@"users"];
    NSArray * wbusers = [dataObject dataForKeyPath:@"wbusers"];
    
    if([users isKindOfClass:[NSArray class]] && [users count]){
        
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"钱多多",@"title"
                             ,@"user",@"type",users,@"items", nil]];
        
    }
    
    if([wbusers isKindOfClass:[NSArray class]] && [wbusers count]){
        
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"微博好友",@"title"
                             ,@"wbuser",@"type",wbusers,@"items", nil]];
        
    }
    
    self.sections = sections;

    
}

@end
