//
//  QDDInviteWeiboDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-12-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteDataSource.h"

@interface QDDInviteWeiboDataSource : QDDInviteDataSource

@end
