//
//  QDDInviteQQDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-12-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteQQDataSource.h"

@implementation QDDInviteQQDataSource

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    id dataObject = [self dataObject];
    
    NSMutableArray * sections = [NSMutableArray arrayWithCapacity:4];
    
    NSArray * users = [dataObject dataForKeyPath:@"users"];
    NSArray * qqusers = [dataObject dataForKeyPath:@"qqusers"];
    
    if([users isKindOfClass:[NSArray class]] && [users count]){
        
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"钱多多",@"title"
                             ,@"user",@"type",users,@"items", nil]];
        
    }
    
    if([qqusers isKindOfClass:[NSArray class]] && [qqusers count]){
        
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"QQ好友",@"title"
                             ,@"qquser",@"type",qqusers,@"items", nil]];
        
    }
    
    self.sections = sections;
    
    
}


@end
