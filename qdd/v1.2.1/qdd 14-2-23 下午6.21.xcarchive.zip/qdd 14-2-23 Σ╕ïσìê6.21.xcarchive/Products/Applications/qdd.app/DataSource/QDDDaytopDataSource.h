//
//  QDDDaytopDataSource.h
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDPageDataSource.h"

@interface QDDDaytopDataSource : QDDPageDataSource

@end
