//
//  QDDTopicUnLikeTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDTopicUnLikeTask.h"

@implementation QDDTopicUnLikeTask

@synthesize topicId = _topicId;

@end
