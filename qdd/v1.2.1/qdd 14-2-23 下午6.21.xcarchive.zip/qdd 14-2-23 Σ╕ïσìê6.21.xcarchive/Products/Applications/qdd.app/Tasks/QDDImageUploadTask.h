//
//  QDDImageUploadTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@protocol IQDDImageUploadTask <IVTUplinkTask>

@property(nonatomic,retain) UIImage * image;
@property(nonatomic,assign) CGFloat maxWidth;

@property(nonatomic,assign) CGSize imageSize;
@property(nonatomic,retain) id resultsData;

@property(nonatomic,retain) id task;
@property(nonatomic,assign) Protocol * taskType;

@end

@interface QDDImageUploadTask : VTUplinkTask<IQDDImageUploadTask>

@end
