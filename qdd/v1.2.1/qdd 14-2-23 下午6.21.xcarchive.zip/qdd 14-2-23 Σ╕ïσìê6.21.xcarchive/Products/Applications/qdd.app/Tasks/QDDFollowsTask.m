//
//  QDDFollowsTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFollowsTask.h"

@implementation QDDFollowsTask

@synthesize tuids = _tuids;

@end
