//
//  QDDProductLikeTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductLikeTask.h"

@implementation QDDProductLikeTask

@synthesize productId = _productId;

@end
