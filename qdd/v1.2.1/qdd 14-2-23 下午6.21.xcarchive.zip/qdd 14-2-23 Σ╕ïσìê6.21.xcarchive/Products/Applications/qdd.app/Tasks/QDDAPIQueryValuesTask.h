//
//  QDDAPIQueryValuesTask.h
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@protocol IQDDAPIQueryValuesTask <IVTTask>

@property(nonatomic,retain) NSMutableDictionary * queryValues;

@end

@interface QDDAPIQueryValuesTask : VTTask<IQDDAPIQueryValuesTask>

@end
