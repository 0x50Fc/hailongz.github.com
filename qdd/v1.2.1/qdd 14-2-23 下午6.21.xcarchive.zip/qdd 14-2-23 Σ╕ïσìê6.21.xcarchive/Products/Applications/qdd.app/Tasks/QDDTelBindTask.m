//
//  QDDTelBindTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDTelBindTask.h"

@implementation QDDTelBindTask

@synthesize tel = _tel;
@synthesize telVerify = _telVerify;


@end
