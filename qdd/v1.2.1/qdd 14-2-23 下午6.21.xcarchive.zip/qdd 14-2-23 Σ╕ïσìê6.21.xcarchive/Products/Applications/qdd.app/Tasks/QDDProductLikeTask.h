//
//  QDDProductLikeTask.h
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDProductLikeTask <IVTUplinkTask,IQDDAPITask>

@property(nonatomic,retain) id productId;

@end

@interface QDDProductLikeTask : VTUplinkTask<IQDDProductLikeTask>

@end
