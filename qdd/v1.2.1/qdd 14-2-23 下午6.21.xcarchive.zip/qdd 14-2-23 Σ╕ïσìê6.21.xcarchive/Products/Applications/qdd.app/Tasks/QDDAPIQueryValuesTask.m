//
//  QDDAPIQueryValuesTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDAPIQueryValuesTask.h"

@implementation QDDAPIQueryValuesTask

@synthesize queryValues = _queryValues;

-(NSMutableDictionary *) queryValues{
    
    if(_queryValues == nil){
        _queryValues = [[NSMutableDictionary alloc] initWithCapacity:4];
    }
    
    return _queryValues;
}

@end
