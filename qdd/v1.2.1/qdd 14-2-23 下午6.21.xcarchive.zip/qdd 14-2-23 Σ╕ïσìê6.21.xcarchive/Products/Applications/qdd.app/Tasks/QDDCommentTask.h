//
//  QDDCommentTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDCommentTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * body;
@property(nonatomic,assign) long long publishId;
@property(nonatomic,assign) long long commentId;
@property(nonatomic,retain) id topicId;
@property(nonatomic,retain) id productId;
@property(nonatomic,assign) long long tuid;

@end

@interface QDDCommentTask : VTUplinkTask<IQDDCommentTask>

@end
