//
//  QDDPrizeBuyTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeBuyTask.h"

@implementation QDDPrizeBuyTask

@synthesize productId = _productId;
@synthesize address = _address;
@synthesize postCode = _postCode;
@synthesize name = _name;
@synthesize phone = _phone;
@synthesize other = _other;

@end
