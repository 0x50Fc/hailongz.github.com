//
//  QDDMessageTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMessageTask.h"

@implementation QDDMessageTask

@end
