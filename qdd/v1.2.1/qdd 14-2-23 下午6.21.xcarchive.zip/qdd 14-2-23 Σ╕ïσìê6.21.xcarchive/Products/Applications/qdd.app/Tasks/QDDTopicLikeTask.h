//
//  QDDTopicLikeTask.h
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDTopicLikeTask <IVTUplinkTask,IQDDAPITask>

@property(nonatomic,retain) id topicId;

@end

@interface QDDTopicLikeTask : VTUplinkTask<IQDDTopicLikeTask>

@end
