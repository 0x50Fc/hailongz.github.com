//
//  QDDMessageRemoveTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-23.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDMessageRemoveTask.h"

@implementation QDDMessageRemoveTask

@synthesize mid = _mid;

@end
