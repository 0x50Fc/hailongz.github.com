//
//  QDDProductUnLikeTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductUnLikeTask.h"

@implementation QDDProductUnLikeTask

@synthesize productId = _productId;

@end
