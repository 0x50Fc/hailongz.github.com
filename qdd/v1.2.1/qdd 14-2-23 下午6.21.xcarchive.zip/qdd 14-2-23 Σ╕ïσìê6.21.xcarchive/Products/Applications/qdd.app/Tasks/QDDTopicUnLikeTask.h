//
//  QDDTopicUnLikeTask.h
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDTopicUnLikeTask <IVTUplinkTask,IQDDAPITask>

@property(nonatomic,retain) id topicId;

@end

@interface QDDTopicUnLikeTask : VTUplinkTask<IQDDTopicUnLikeTask>

@end
