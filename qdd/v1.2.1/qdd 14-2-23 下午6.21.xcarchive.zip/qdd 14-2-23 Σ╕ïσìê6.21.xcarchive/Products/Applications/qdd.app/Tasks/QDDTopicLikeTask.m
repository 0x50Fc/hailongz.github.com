//
//  QDDTopicLikeTask.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDTopicLikeTask.h"

@implementation QDDTopicLikeTask

@synthesize topicId = _topicId;

@end
