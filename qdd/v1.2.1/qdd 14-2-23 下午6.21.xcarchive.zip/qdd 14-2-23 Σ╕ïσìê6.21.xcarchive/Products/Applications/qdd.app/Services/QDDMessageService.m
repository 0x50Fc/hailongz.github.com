//
//  QDDMessageService.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMessageService.h"

#import "QDDMessageTask.h"

#import "QDDMessageObject.h"

#import "QDDSessionObject.h"

#import "QDDMessageSendTask.h"

#import "QDDImageUploadTask.h"

#import "QDDMessageRemoveTask.h"

@interface QDDMessageService()

@property(nonatomic,retain) id messageTask;

@end

@implementation QDDMessageService


-(void) addMessageData:(id) data dbContext:(VTDBContext *) dbContext uid:(long long) uid sessions:(NSMutableDictionary *) sessions{
    
    QDDMessageObject * dataObject = [[QDDMessageObject alloc] init];
    
    [dataObject setMid:[[data valueForKey:@"mid"] longLongValue]];
    [dataObject setTuid:[[data valueForKey:@"tuid"] longLongValue]];
    [dataObject setUid:[[data valueForKey:@"uid"] longLongValue]];
    [dataObject setBody:[data valueForKey:@"body"]];
    [dataObject setTimestamp:[[data valueForKey:@"createTime"] intValue]];
     
    if([[data valueForKey:@"hasAttach"] boolValue]){
        
        NSArray * attachs = [data valueForKey:@"attachs"];
        
        if([attachs isKindOfClass:[NSArray class]]){
            
            for(id attach in attachs){
                
                NSString * contentType = [attach valueForKey:@"contentType"];
                
                if([contentType hasPrefix:@"image"]){
                    
                    [dataObject setImageUri:[attach valueForKey:@"uri"]];
                    
                    break;
                }
                
                
            }
            
        }
        
    }
    
    if(dataObject.uid == uid){
        dataObject.sessionId = dataObject.tuid;
    }
    else{
        dataObject.sessionId = dataObject.uid;
    }
    
    QDDSessionObject * session = [sessions objectForKey:[NSNumber numberWithLongLong:dataObject.sessionId]];
    
    if(session == nil){
        
        session = [[QDDSessionObject alloc] init];
        
        id<IVTSqliteCursor> cursor = [dbContext query:[QDDSessionObject tableClass] sql:[NSString stringWithFormat:@"WHERE sessionId=%lld",dataObject.sessionId] data:nil];
        
        if([cursor next]){
            [cursor toDataObject:session];
        }
        else{
            [session setSessionId:dataObject.sessionId];
        }
        
        [cursor close];
        
        [sessions setObject:session forKey:[NSNumber numberWithLongLong:dataObject.sessionId]];
        
    }
    
    if(dataObject.uid == uid){
        session.uid = dataObject.tuid;
    }
    else {
        session.uid = dataObject.uid;
        if([[data valueForKey:@"mstate"] intValue] ==0){
            session.unreadCount ++;
        }
    }
    
    session.mid = dataObject.mid;
    session.body = dataObject.body;
    session.imageUri = dataObject.imageUri;
    session.timestamp = dataObject.timestamp;
    
    [dbContext insertObject:dataObject];
    
}

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    
    if(taskType == @protocol(IQDDMessageTask)){
        
        if(_messageTask == nil){
            
            self.messageTask = task;
            
            long long maxMid = 0;
            
            VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
            
            id<IVTSqliteCursor> cursor = [dbContext query:[QDDMessageObject tableClass] sql:@"ORDER BY [rowid] DESC LIMIT 1" data:nil];
            
            if([cursor next]){
                maxMid = [cursor longLongValueForName:@"mid"];
            }
            
            [cursor close];
            
            VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
            
            [httpTask setTaskType:taskType];
            [httpTask setTask:task];
            [httpTask setSource:[task source]];
            
            [httpTask setApiKey:@"url"];
            
            VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
            
            [body addItemValue:@"config_qdd" forKey:@"config"];
            [body addItemValue:@"QDDMessageSearchTask" forKey:@"taskType"];
            
            if(maxMid){
                [body addItemValue:[NSString stringWithFormat:@"%lld",maxMid] forKey:@"qdd-minMid"];
            }
            
            [body addItemValue:@"200" forKey:@"qdd-limit"];
            
            [httpTask setBody:body];
            
            [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
            
        }
        
        return YES;
    }
    else if(taskType == @protocol(IQDDMessageSendTask)){
        
        
        id<IQDDMessageSendTask> messageTask = (id<IQDDMessageSendTask>) task;
        
        if([messageTask imageUri] == nil && [messageTask image]){
            
            QDDImageUploadTask * imageTask = [[QDDImageUploadTask alloc] init];
            
            [imageTask setSource:[messageTask source]];
            [imageTask setDelegate:self];
            [imageTask setImage:[messageTask image]];
            [imageTask setMaxWidth:640];
            [imageTask setTask:messageTask];
            [imageTask setTaskType:taskType];
            
            [self.context handle:@protocol(IQDDImageUploadTask) task:imageTask priority:0];
        
        }
        else{
            VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
            
            [httpTask setTaskType:taskType];
            [httpTask setTask:task];
            [httpTask setSource:[task source]];
            
            [httpTask setApiKey:@"url"];
            
            VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
            
            [body addItemValue:@"config_qdd" forKey:@"config"];
            [body addItemValue:@"QDDMessageSendTask" forKey:@"taskType"];
            
    
            [body addItemValue:[NSString stringWithFormat:@"%lld",[messageTask uid]] forKey:@"qdd-tuid"];
            
    
            if([messageTask imageUri]){
                [body addItemValue:@"[图片]" forKey:@"qdd-body"];
                [body addItemValue:[messageTask imageUri] forKey:@"qdd-image"];
            }
            else{
                [body addItemValue:[messageTask body] forKey:@"qdd-body"];
            }
           
            [httpTask setBody:body];
            
            [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        }
        
        return YES;
    }
    else if(taskType == @protocol(IQDDMessageRemoveTask)){
        
        id<IQDDMessageRemoveTask> messageTask = (id<IQDDMessageRemoveTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDMessageRemoveTask" forKey:@"taskType"];
        
        [body addItemValue:[NSString stringWithFormat:@"%@",[messageTask mid]] forKey:@"qdd-mid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
    
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>)task;
        
        if([respTask taskType] == @protocol(IQDDMessageTask)){
            
            self.messageTask = nil;
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(!errorCode){
                
                id results = [[respTask resultsData] dataForKeyPath:@"message-search-results"];
                
                if([results isKindOfClass:[NSArray class]]){
            
                    if([results count]){
                        
                        long long uid = [[(id<QDDContext>) self.context uid] longLongValue];
                        
                        NSMutableDictionary * sessions = [NSMutableDictionary dictionaryWithCapacity:4];
                        
                        VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
            
                        NSEnumerator * dataEnum  = [results reverseObjectEnumerator];
                        
                        id data;
                        
                        while((data = [dataEnum nextObject])){
                            [self addMessageData:data dbContext:dbContext uid:uid sessions:sessions];
                        }
                        
                        for(QDDSessionObject * dataObject in [sessions allValues]){
                            
                            if(dataObject.rowid){
                                [dbContext updateObject:dataObject];
                            }
                            else{
                                [dbContext insertObject:dataObject];
                            }
                            
                        }
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:QDDMessageChangedNotification object:nil];
                        
                        [self handle:@protocol(IQDDMessageTask) task:[respTask task] priority:0];
                        
                    }
                    
                }
            
            }
            
            return YES;
        }
        else if([respTask taskType] == @protocol(IQDDMessageSendTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                id results = [[respTask resultsData] dataForKeyPath:@"message-send-results"];
                
                if([results isKindOfClass:[NSDictionary class]]){
                    
                    long long uid = [[(id<QDDContext>) self.context uid] longLongValue];
                    
                    NSMutableDictionary * sessions = [NSMutableDictionary dictionaryWithCapacity:4];
                    
                    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                    
                    [self addMessageData:results dbContext:dbContext uid:uid sessions:sessions];
                    
                    for(QDDSessionObject * dataObject in [sessions allValues]){
                        
                        if(dataObject.rowid){
                            [dbContext updateObject:dataObject];
                        }
                        else{
                            [dbContext insertObject:dataObject];
                        }
                        
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDMessageChangedNotification object:nil];
                    
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        else if([respTask taskType] == @protocol(IQDDMessageRemoveTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

-(BOOL) cancelHandle:(Protocol *)taskType task:(id<IVTTask>)task{
    
    if(taskType == @protocol(IQDDMessageTask)){
        
        if(_messageTask){
            
            VTAPITask * t = [[VTAPITask alloc] init];
            
            [t setTask:_messageTask];
            [t setTaskType:@protocol(IQDDMessageTask)];
            
            [self.context cancelHandle:@protocol(IVTAPICancelTask) task:t];
            
            self.messageTask = nil;
            
        }
        
    }
    
    return NO;
}

-(BOOL) cancelHandleForSource:(id)source{
    
    if([_messageTask source] == source){
    
        self.messageTask = nil;
    }
    
    return NO;
}


-(void) vtUploadTask:(id<IVTUplinkTask>) uplinkTask didSuccessResults:(id) results forTaskType:(Protocol *) taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDImageUploadTask * imageTask = (QDDImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDMessageSendTask)){
            
            id<IQDDMessageSendTask> messageTask = (id<IQDDMessageSendTask>) [imageTask task];
            
            [messageTask setImageUri:[results dataForKeyPath:@"uri"]];
            
            if([messageTask imageUri] == nil){
                
                [self vtUplinkTask:messageTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:0 userInfo:[NSDictionary dictionaryWithObject:@"图片上传错误" forKey:NSLocalizedDescriptionKey]] forTaskType:[imageTask taskType]];
            }
            else{
                [self.context handle:@protocol(IQDDMessageSendTask) task:messageTask priority:0];
            }
            
        }
        
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>) uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDImageUploadTask * imageTask = (QDDImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDMessageSendTask)){
            [self vtUplinkTask:imageTask didFailWithError:error forTaskType:[imageTask taskType]];
        }
    }
}



@end
