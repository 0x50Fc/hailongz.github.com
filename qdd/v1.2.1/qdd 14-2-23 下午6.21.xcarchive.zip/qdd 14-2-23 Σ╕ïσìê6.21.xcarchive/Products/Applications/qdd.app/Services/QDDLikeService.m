//
//  QDDLikeService.m
//  qdd
//
//  Created by zhang hailong on 13-11-13.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDLikeService.h"

#import "QDDLikeTask.h"
#import "QDDUnLikeTask.h"

#import "QDDTopicLikeTask.h"
#import "QDDTopicUnLikeTask.h"

#import "QDDProductLikeTask.h"
#import "QDDProductUnLikeTask.h"

@implementation QDDLikeService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(@protocol(IQDDLikeTask) == taskType){
        
        id<IQDDLikeTask> likeTask = (id<IQDDLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[likeTask pid]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDTopicLikeTask) == taskType){
        
        id<IQDDTopicLikeTask> likeTask = (id<IQDDTopicLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDTopicLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%@",[likeTask topicId]] forKey:@"qdd-tid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDTopicUnLikeTask) == taskType){
        
        id<IQDDTopicUnLikeTask> likeTask = (id<IQDDTopicUnLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDTopicUnLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%@",[likeTask topicId]] forKey:@"qdd-tid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDProductLikeTask) == taskType){
        
        id<IQDDProductLikeTask> likeTask = (id<IQDDProductLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDProductLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%@",[likeTask productId]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDProductUnLikeTask) == taskType){
        
        id<IQDDProductUnLikeTask> likeTask = (id<IQDDProductUnLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDProductUnLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%@",[likeTask productId]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDUnLikeTask) == taskType){
        
        id<IQDDUnLikeTask> likeTask = (id<IQDDUnLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDUnLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[likeTask pid]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IVTAPIResponseTask) == taskType){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDLikeTask) || [respTask taskType] == @protocol(IQDDUnLikeTask) || [respTask taskType] == @protocol(IQDDTopicLikeTask) || [respTask taskType] == @protocol(IQDDTopicUnLikeTask) || [respTask taskType] == @protocol(IQDDProductLikeTask) || [respTask taskType] == @protocol(IQDDProductUnLikeTask)){
            
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                if([respTask taskType] == @protocol(IQDDLikeTask)){
                    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"成功赞一下"];
                    
                    [alertView showDuration:1.2];
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:QDDLikeChangedNotification object:nil];
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

@end
