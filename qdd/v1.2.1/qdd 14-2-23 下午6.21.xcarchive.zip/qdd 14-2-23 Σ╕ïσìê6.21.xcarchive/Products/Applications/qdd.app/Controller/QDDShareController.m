//
//  QDDShareController.m
//  qdd
//
//  Created by zhang hailong on 14-2-19.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDShareController.h"

#import "WeiboSDK.h"

@implementation QDDShareController


-(IBAction) doBeginShareAction:(id)sender{
    
    [_view setAlpha:0.0];
    [_view setHidden:NO];
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_view setAlpha:1.0];
        
        [_contentView setFrame:CGRectMake(r.origin.x, size.height - r.size.height
                                          , r.size.width, r.size.height)];
        
    }];
    
}

-(IBAction) doCancelShareAction:(id)sender{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_view setAlpha:0.0];
        
        [_contentView setFrame:CGRectMake(r.origin.x, size.height
                                          , r.size.width, r.size.height)];
        
    } completion:^(BOOL finished) {
        
        [_view setHidden:YES];
        
    }];
    
}

-(IBAction) toFansAction:(id)sender{
    
    if([(id<QDDContext>) self.context uid] == nil){
        
        [[(id<QDDContext>) self.context rootViewController] openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
        
        [self doCancelShareAction:nil];
        
        return;
    }
    
    NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:4];
    
    [queryValues setValue:self.topicId forKey:@"topicId"];
    [queryValues setValue:self.productId forKey:@"productId"];
    [queryValues setValue:self.image forKey:@"image"];
    
    [[(id<QDDContext>) self.context rootViewController] openUrl:[NSURL URLWithString:@"present://root/publish-feed" queryValues:queryValues] animated:YES];
    
    [self doCancelShareAction:nil];
}

-(IBAction) toWeiboAction:(id)sender{
    
    if([(id<QDDContext>)self.context canSendWeiboWithAlert:YES]){
        
        UIImage * image = nil;
        
        if(self.image){
        
            VTImageView * imageView = [[VTImageView alloc] init];
        
            [imageView setSrc:self.image];
            
            [self.context handle:@protocol(IVTLocalImageTask) task:imageView priority:0];
            
            image = [imageView image];
        }
        
        [(id<QDDContext>) self.context sendWeiboWithBody:self.body withImage:image];
        
    }

}

-(IBAction) toWeixinAction:(id)sender{
    
    if([(id<QDDContext>)self.context canSendWeixinWithAlert:YES]){
        
        UIImage * image = nil;
        
        if(self.image){
            
            VTImageView * imageView = [[VTImageView alloc] init];
            
            [imageView setSrc:self.image];
            
            [self.context handle:@protocol(IVTLocalImageTask) task:imageView priority:0];
            
            image = [imageView image];
        }
        
        [(id<QDDContext>) self.context sendWeixinWithTitle:self.body withBody:nil withImage:image scene:QDDWXSceneTimeline];
        
    }
    
}

@end
