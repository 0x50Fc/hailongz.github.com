//
//  QDDInviteController.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteController.h"

#import "QDDInviteDataSource.h"

@implementation QDDInviteController

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return [[(QDDInviteDataSource *)self.dataSource sections] count];
}

-(UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    id dataItem = [[self.dataSource valueForKey:@"sections"] objectAtIndex:section];
    
    UIView * headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 20)];
    
    [headerView setBackgroundColor:[UIColor colorWithRed:255.0 / 255.0 green:204.0 / 255.0 blue:204.0 / 255.0 alpha:1.0]];
    
    UILabel * titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, tableView.bounds.size.width - 20, 20)];
    
    [titleLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    
    [titleLabel setTintColor:[UIColor colorWithRed:252.0 / 255.0 green:95.0 / 255.0 blue:94.0 / 255.0 alpha:1.0]];
    
    [titleLabel setFont:[UIFont boldSystemFontOfSize:14]];
    
    [titleLabel setText:[dataItem valueForKey:@"title"]];
    
    [headerView addSubview:titleLabel];
    
    return headerView;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    id dataItem = [[(QDDInviteDataSource *)self.dataSource sections] objectAtIndex:section];
    
    return [[dataItem valueForKey:@"items"] count];
}

-(id) dataObjectByIndexPath:(NSIndexPath *) indexPath;{
    return [(QDDInviteDataSource *)self.dataSource dataObjectAtIndexPath:indexPath];
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    VTDOMDocument * document = [self documentByIndexPath:indexPath];
    
    return [[document rootElement] frame].size.height;
}

-(NSString *) htmlContentByIndexPath:(NSIndexPath *)indexPath{
    
    id section = [[self.dataSource valueForKey:@"sections"] objectAtIndex:indexPath.section];
    
    NSString * type = [section valueForKey:@"type"];
   
    if([type isEqualToString:@"user"]){
        self.html = @"invite_user.html";
    }
    else if([type isEqualToString:@"people"]){
        self.html = @"invite_people.html";
    }
    else if([type isEqualToString:@"wbuser"]){
        self.html = @"invite_wbuser.html";
    }
    else if([type isEqualToString:@"qquser"]){
        self.html = @"invite_qquser.html";
    }
    
    return [super htmlContentByIndexPath:indexPath];
}


-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    VTDOMDocument * document = [self documentByIndexPath:indexPath];
    
    NSString * identifier = self.reusableCellIdentifier;
    
    if(identifier == nil){
        identifier = self.html;
    }
    
    if(identifier == nil){
        identifier = @"Document";
    }
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if(cell == nil){
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        
        [cell setBackgroundColor:[UIColor clearColor]];
        [cell.contentView setBackgroundColor:[UIColor clearColor]];
        
        CGSize size = cell.contentView.bounds.size;
        
        VTDOMView * documentView = [[VTDOMView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        
        [documentView setBackgroundColor:[UIColor clearColor]];
        [documentView setDelegate:self];
        [documentView setAllowAutoLayout:NO];
        [documentView setTag:100];
        [documentView setAutoresizingMask:UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth];
        
        [cell.contentView addSubview:documentView];
        
    }
    
    VTDOMView * documentView = (VTDOMView *) [cell.contentView viewWithTag:100];
    
    [documentView setElement:[document rootElement]];
    
    [self loadImagesForView:documentView];
    
    dispatch_async(dispatch_get_current_queue(), ^{
        [self downloadImagesForView:documentView];
    });
    
    if([document rootElement]){
        
        [self loadImagesForElement:[document rootElement]];
        
        dispatch_async(dispatch_get_current_queue(), ^{
            [self downloadImagesForElement:[document rootElement]];
        });
        
    }
    
    return cell;
}


@end
