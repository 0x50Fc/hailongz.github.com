//
//  QDDCommentController.m
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDCommentController.h"

#import "QDDCommentTask.h"

@implementation QDDCommentController


-(void) visableKeyboard:(CGRect) frame{
    
    if([_textView isFirstResponder]){
        
        [_view setAlpha:0.0];
        [_view setHidden:NO];
        
        CGSize size = [[_contentView superview] bounds].size;
        
        CGRect r = [_contentView frame];
        
        [UIView animateWithDuration:0.3 animations:^{
            
            [_view setAlpha:1.0];
            
            [_contentView setFrame:CGRectMake(r.origin.x, size.height - r.size.height - frame.size.height
                                              , r.size.width, r.size.height)];
            
        }];
    }
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_view setAlpha:0.0];
        
        [_contentView setFrame:CGRectMake(r.origin.x, size.height
                                          , r.size.width, r.size.height)];
        
    } completion:^(BOOL finished) {
        
        [_view setHidden:YES];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(IBAction) doCancelAction:(id)sender{
    if([_statusView status] == nil){
        [_textView resignFirstResponder];
        [_textView setText:nil];
    }
}

-(IBAction) doCommitAction:(id)sender{
    
    NSString * body = [[_textView text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([body length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入评论内容" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    [_statusView setStatus:@"loading"];
   
    QDDCommentTask * task = [[QDDCommentTask alloc] initWithSource:self];
    
    [task setDelegate:self];
    [task setTopicId:_topicId];
    [task setProductId:_productId];
    [task setPublishId:_publishId];
    [task setCommentId:_commentId];
    
    [task setBody:body];
    
    [self.context handle:@protocol(IQDDCommentTask) task:task priority:0];
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    [_statusView setStatus:nil];
 
    if([self.delegate respondsToSelector:@selector(commentControllerDidCommit:)]){
        [self.delegate commentControllerDidCommit:self];
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    [_statusView setStatus:nil];
   
    if([self.delegate respondsToSelector:@selector(commentController:didFialError:)]){
        [self.delegate commentController:self didFialError:error];
    }

}

@end
