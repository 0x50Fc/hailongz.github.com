//
//  QDDLikeController.h
//  qdd
//
//  Created by zhang hailong on 14-2-19.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDLikeController : VTController<UIAlertViewDelegate,IVTUplinkTaskDelegate>

@property(nonatomic,retain) id topicId;
@property(nonatomic,retain) id productId;
@property(nonatomic,retain) id publishId;

-(void) doLikeElement:(VTDOMElement *) element;

-(void) doLikeButton:(UIButton *) button;

@end
