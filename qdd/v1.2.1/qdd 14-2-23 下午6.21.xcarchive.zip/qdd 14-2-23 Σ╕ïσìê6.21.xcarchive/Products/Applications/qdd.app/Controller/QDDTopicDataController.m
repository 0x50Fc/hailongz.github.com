//
//  QDDTopicDataController.m
//  qdd
//
//  Created by zhang hailong on 14-2-19.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDTopicDataController.h"

@implementation QDDTopicDataController

-(void) document:(VTDOMDocument *)document willLoadDataObject:(id)dataObject{
    [super document:document willLoadDataObject:dataObject];
    
    VTDOMElement * element = [document elementById:@"productContent"];
    
    if(element){
        
        NSArray * products = [dataObject arrayValueForKey:@"products"];
        
        NSString * htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"topic_product" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
        
        VTDOMParse * parse = [[VTDOMParse alloc] init];
        
        for(id dataItem in products){
            
            [parse parseHTML:[htmlContent htmlStringByDOMSource:dataItem] toElement:element];
            
        }
        
    }
}

@end
