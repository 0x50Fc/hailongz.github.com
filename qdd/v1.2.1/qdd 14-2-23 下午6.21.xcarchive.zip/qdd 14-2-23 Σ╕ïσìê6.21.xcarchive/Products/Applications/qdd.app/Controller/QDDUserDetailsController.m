//
//  QDDUserDetailsController.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserDetailsController.h"

@implementation QDDUserDetailsController

-(void) dealloc{
    
    [_dataSource setDelegate:nil];
    
}

-(void) reloadData{
    [_dataSource reloadData];
}

-(void) vtDataSourceWillLoading:(VTDataSource *) dataSource{
    
}

-(void) didSourceDataChanged{
    self.dataItem = [_dataSource dataObject];
    self.document = nil;
    [super reloadData];
    
    if([self.delegate respondsToSelector:@selector(userDetailsControllerDidContentSizeChanged:)]){
        [self.delegate userDetailsControllerDidContentSizeChanged:self];
    }
}

-(void) vtDataSourceDidLoadedFromCache:(VTDataSource *) dataSource timestamp:(NSDate *) timestamp{
    [self didSourceDataChanged];
}

-(void) vtDataSourceDidLoaded:(VTDataSource *) dataSource{
    [self didSourceDataChanged];
}

-(void) vtDataSource:(VTDataSource *) dataSource didFitalError:(NSError *) error{
    
}

-(void) vtDataSourceDidContentChanged:(VTDataSource *) dataSource{
    
}

-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    
    [_dataSource setContext:context];
    
}

-(NSInteger) fansCount{
    return [[self.dataItem valueForKey:@"fansCount"] intValue];
}

-(void) setFansCount:(NSInteger)fansCount{
    [self.dataItem setValue:[NSNumber numberWithInt:fansCount] forKey:@"fansCount"];
    
    VTDOMElement * element = [self.document elementById:@"fansLabel"];
    
    if(element){
        [element setText:[NSString stringWithFormat:@"%d",fansCount]];
        [element layout];
        [element setNeedDisplay];
    }
    
}

-(void) udpateBGImage:(UIImage *) image{
    
    VTDOMElement * element = [self.document elementById:@"bgImage"];
    
    if([element isKindOfClass:[VTDOMImageElement class]]){
        
        [(VTDOMImageElement *) element setImage:image];
        
        [element setNeedDisplay];
    }
   
}

@end
