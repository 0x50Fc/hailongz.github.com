//
//  QDDCommentController.h
//  qdd
//
//  Created by zhang hailong on 14-2-16.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDCommentController : VTController<VTKeyboardControllerDelegate,IVTUplinkTaskDelegate>

@property(nonatomic,retain) IBOutlet UIView * view;
@property(nonatomic,retain) IBOutlet UIView * contentView;
@property(nonatomic,retain) IBOutlet UITextView * textView;
@property(nonatomic,retain) IBOutlet VTStatusView * statusView;
@property(nonatomic,retain) IBOutlet UILabel * titleLabel;
@property(nonatomic,retain) id topicId;
@property(nonatomic,retain) id productId;
@property(nonatomic,assign) long long publishId;
@property(nonatomic,assign) long long commentId;
@property(nonatomic,assign) long long tuid;

-(IBAction) doCancelAction:(id)sender;

-(IBAction) doCommitAction:(id)sender;

@end

@protocol QDDCommentControllerDelegate

@optional

-(void) commentControllerDidCommit:(QDDCommentController *) controller;

-(void) commentController:(QDDCommentController *) controller didFialError:(NSError *) error;

@end