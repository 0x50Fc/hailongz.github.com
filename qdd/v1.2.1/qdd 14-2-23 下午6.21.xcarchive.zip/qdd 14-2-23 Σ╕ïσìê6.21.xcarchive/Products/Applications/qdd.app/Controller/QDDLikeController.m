//
//  QDDLikeController.m
//  qdd
//
//  Created by zhang hailong on 14-2-19.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDLikeController.h"

#import "QDDTopicLikeTask.h"
#import "QDDLikeTask.h"
#import "QDDProductLikeTask.h"
#import "QDDTopicUnLikeTask.h"
#import "QDDProductUnLikeTask.h"
#import "QDDUnLikeTask.h"

@interface QDDLikeControllerLikeTask : QDDLikeTask

@property(nonatomic,retain) VTDOMElement * element;

@end

@implementation QDDLikeControllerLikeTask

@synthesize element = _element;

@end

@interface QDDLikeControllerTopicLikeTask : QDDTopicLikeTask

@property(nonatomic,retain) VTDOMElement * element;

@end

@implementation QDDLikeControllerTopicLikeTask

@synthesize element = _element;

@end

@interface QDDLikeControllerProductLikeTask : QDDProductLikeTask

@property(nonatomic,retain) VTDOMElement * element;

@end

@implementation QDDLikeControllerProductLikeTask

@synthesize element = _element;

@end

@interface QDDLikeController()

@property(nonatomic,retain) VTDOMElement * element;
@property(nonatomic,retain) UIButton * button;

@end

@implementation QDDLikeController

-(void) alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex == 1){
        
        if(_topicId){
            
            QDDTopicUnLikeTask * task = [[QDDTopicUnLikeTask alloc] init];
            
            [task setTopicId:_topicId];
            
            [self.context handle:@protocol(IQDDTopicUnLikeTask) task:task priority:0];
            
        }
        else if(_productId){
            
            QDDProductUnLikeTask * task = [[QDDProductUnLikeTask alloc] init];
            
            [task setProductId:_productId];
            
            [self.context handle:@protocol(IQDDProductUnLikeTask) task:task priority:0];
            
        }
        else{
            
            QDDUnLikeTask * task = [[QDDUnLikeTask alloc] init];
            
            [task setPid:[_publishId longLongValue]];
            
            [self.context handle:@protocol(IQDDUnLikeTask) task:task priority:0];
            
        }
        
        if(_element){
            
            [_element setAttributeValue:@"false" forKey:@"selected"];
            
            if([_element isKindOfClass:[VTDOMViewElement class]]){
                
                UIButton * button = (UIButton *) [(VTDOMViewElement *) _element view];
                
                if([button isKindOfClass:[UIButton class]]){
                    
                    [button setSelected:![button isSelected]];
                    
                    int count = [[button titleForState:UIControlStateNormal] intValue] - 1;
                    
                    if(count <0 ){
                        count = 0;
                    }
                    
                    [button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
                }
            }
            else if([_element isKindOfClass:[VTDOMActionElement class]]){
                
                [_element setAttributeValue:@"#464646" forKey:@"background-color"];
                
                [_element setNeedDisplay];
                
            }
        }
        
        if(_button){
            
            [_button setSelected:![_button isSelected]];
            
            int count = [[_button titleForState:UIControlStateNormal] intValue] - 1;
            
            if(count <0 ){
                count = 0;
            }
            
            [_button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
        }
    }
    
    self.button = nil;
    self.element = nil;
}

-(void) doLikeElement:(VTDOMElement *) element{
    
    self.topicId = [element attributeValueForKey:@"topicId"];
    self.productId = [element attributeValueForKey:@"productId"];
    self.publishId = [element attributeValueForKey:@"pid"];
    
    BOOL isLiked = [element booleanValueForKey:@"selected"];
    
    if(isLiked){
        
        self.element = element;
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"确定不攒了?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        
        [alertView show];
        
    }
    else {
        
        if(_topicId){
            
            QDDTopicLikeTask * task = [[QDDTopicLikeTask alloc] init];
            
            [task setTopicId:_topicId];
            
            [self.context handle:@protocol(IQDDTopicLikeTask) task:task priority:0];
            
        }
        else if(_productId){
            
            QDDProductLikeTask * task = [[QDDProductLikeTask alloc] init];
            
            [task setProductId:_productId];
            
            [self.context handle:@protocol(IQDDProductLikeTask) task:task priority:0];
            
        }
        else{
            
            QDDLikeTask * task = [[QDDLikeTask alloc] init];
            
            [task setPid:[_publishId longLongValue]];
            
            [self.context handle:@protocol(IQDDLikeTask) task:task priority:0];
            
        }
        
        [element setAttributeValue:@"true" forKey:@"selected"];
        
        if([element isKindOfClass:[VTDOMViewElement class]]){
            
            UIButton * button = (UIButton *) [(VTDOMViewElement *) element view];
            
            if([button isKindOfClass:[UIButton class]]){
                
                [button setSelected:![button isSelected]];
                
                int count = [[button titleForState:UIControlStateNormal] intValue] +1;
                
                if(count <0 ){
                    count = 0;
                }
                
                [button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
            }
        }
        else if([element isKindOfClass:[VTDOMActionElement class]]){
            
            [element setAttributeValue:@"#f26c4f" forKey:@"background-color"];
            
            [element setNeedDisplay];
            
        }
    }
    
}

-(void) doLikeButton:(UIButton *) button{
    
    if([button isSelected]){
        
        self.button = button;
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"确定不攒了?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        
        [alertView show];
        
    }
    else {
        
        if(_topicId){
            
            QDDTopicLikeTask * task = [[QDDTopicLikeTask alloc] init];
            
            [task setTopicId:_topicId];
            
            [self.context handle:@protocol(IQDDTopicLikeTask) task:task priority:0];
            
        }
        else if(_productId){
            
            QDDProductLikeTask * task = [[QDDProductLikeTask alloc] init];
            
            [task setProductId:_productId];
            
            [self.context handle:@protocol(IQDDProductLikeTask) task:task priority:0];
            
        }
        else{
            
            QDDLikeTask * task = [[QDDLikeTask alloc] init];
            
            [task setPid:[_publishId longLongValue]];
            
            [self.context handle:@protocol(IQDDLikeTask) task:task priority:0];
            
        }
        

        [button setSelected:![button isSelected]];
        
        int count = [[button titleForState:UIControlStateNormal] intValue] +1;
        
        if(count <0 ){
            count = 0;
        }
        
        [button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];

    }
    
}

@end
