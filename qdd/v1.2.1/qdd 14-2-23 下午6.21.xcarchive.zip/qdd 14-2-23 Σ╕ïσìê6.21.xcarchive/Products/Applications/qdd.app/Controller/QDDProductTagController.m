//
//  QDDProductTagController.m
//  qdd
//
//  Created by zhang hailong on 14-2-14.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductTagController.h"

@interface QDDProductTagItemControl : UIButton

@property(nonatomic,retain) id dataItem;

@end

@implementation QDDProductTagItemControl

@synthesize dataItem = _dataItem;

@end

@implementation QDDProductTagController

@synthesize selectedTag = _selectedTag;

-(void) dealloc{
    
    [_contentView setDelegate:nil];
    
}
-(void) itemViewAction:(id) itemView{
    
    for(QDDProductTagItemControl * view in [_contentView subviews]){
        if([view isKindOfClass:[QDDProductTagItemControl class]]){
            [view setSelected: view == itemView];
        }
    }
    
    if([self.delegate respondsToSelector:@selector(productTagController:didTagAction:)]){
        [self.delegate productTagController:self didTagAction:[itemView dataItem]];
    }
    
}

-(void) refreshNextButton{
    
    CGSize contentSize = [_contentView contentSize];
    CGPoint contentOffset = [_contentView contentOffset];
    
    if(contentSize.width - contentOffset.x > _contentView.bounds.size.width){
        [_nextButton setHidden:NO];
    }
    else{
        [_nextButton setHidden:YES];
    }
    
}

-(void) reloadContentView{
    
    NSMutableArray * itemViews = [NSMutableArray arrayWithCapacity:4];
    
    for(UIView * itemView in [_contentView subviews]){
        if([itemView isKindOfClass:[QDDProductTagItemControl class]]){
            [itemViews addObject:itemView];
        }
    }
    
    NSInteger index = 0;
    
    CGSize size = _contentView.bounds.size;
    
    CGSize itemSize = CGSizeMake(0, 24);
    CGPoint p = CGPointMake(0, (size.height - itemSize.height) / 2.0);
    
    
    UIFont * titleFont = [UIFont systemFontOfSize:12];
    
    UIColor * highColor = [UIColor whiteColor];
    UIColor * focusColor = [UIColor colorWithRed:242.0 / 255.0 green:108.0 / 255.0 blue:79.0 / 255.0 alpha:1.0];
    
    NSMutableArray * dataItems = [NSMutableArray arrayWithObject:[NSDictionary dictionaryWithObjectsAndKeys:@"0",@"tid",@"全部",@"tag", nil]];
    
    if([self.dataSource dataObjects]){
        [dataItems addObjectsFromArray:[self.dataSource dataObjects]];
    }
    
    for(id dataItem in dataItems){
        
        NSString * title = [dataItem stringValueForKey:@"tag"];
        
        itemSize = [title sizeWithFont:titleFont];
        
        itemSize.width += 30;
        itemSize.height = 24;
        
        CGRect r = CGRectMake(p.x, p.y, itemSize.width, itemSize.height);
        
        QDDProductTagItemControl * itemView = index < [itemViews count] ? [itemViews objectAtIndex:index] : nil;
        
        if(itemView == nil){
            
            itemView = [[QDDProductTagItemControl alloc] initWithFrame:r];
            [itemView.titleLabel setFont:titleFont];
            [itemView setTitleColor:highColor forState:UIControlStateNormal];
            [itemView setTitleColor:focusColor forState:UIControlStateHighlighted];
            [itemView setTitleColor:focusColor forState:UIControlStateSelected];
            
            [itemView addTarget:self action:@selector(itemViewAction:) forControlEvents:UIControlEventTouchUpInside];
            
            [_contentView addSubview:itemView];
        }
        else{
            [itemView setFrame:r];
        }
        
        [itemView setTitle:title forState:UIControlStateNormal];
        [itemView setDataItem:dataItem];
        
        if(_selectedTag == nil){
            _selectedTag = title;
            [itemView setSelected:YES];
        }
        else{
            [itemView setSelected:[_selectedTag isEqualToString:title]];
        }
        
        p.x += itemSize.width;
        
        index ++;
    }
    
    while(index < [itemViews count]){
        [[itemViews objectAtIndex:index] removeFromSuperview];
        index ++;
    }
    
    [_contentView setContentSize:CGSizeMake(p.x + 30, 0)];
    
    [self refreshNextButton];
}

-(void) setSelectedTag:(NSString *)selectedTag{
    _selectedTag = selectedTag;
    for(QDDProductTagItemControl * view in [_contentView subviews]){
        if([view isKindOfClass:[QDDProductTagItemControl class]]){
            [view setSelected: [selectedTag isEqualToString:[[view dataItem] stringValueForKey:@"tag"]]];
        }
    }
}

-(void) vtDataSourceDidLoaded:(VTDataSource *)dataSource{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self reloadContentView];
    [super vtDataSourceDidLoaded:dataSource];
}

-(void) vtDataSourceDidLoadedFromCache:(VTDataSource *)dataSource timestamp:(NSDate *)timestamp{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self performSelector:@selector(reloadContentView) withObject:nil afterDelay:0.3];
    [super vtDataSourceDidLoadedFromCache:dataSource timestamp:timestamp];
}

-(void) vtDataSource:(VTDataSource *)dataSource didFitalError:(NSError *)error{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self reloadContentView];
    [super vtDataSource:dataSource didFitalError:error];
}

-(void) cancel{
    [super cancel];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

-(void) scrollView:(UIScrollView *) scrollView didContentOffsetChanged:(CGPoint) contentOffset{
    [self refreshNextButton];
}

-(IBAction) doScrollNextAction:(id)sender{
    
    CGPoint contentOffset = [_contentView contentOffset];
    CGSize contentSize = [_contentView contentSize];
    CGSize size = [_contentView bounds].size;
    
    contentOffset.x += 30;
    
    if(contentOffset.x > contentSize.width - size.width){
        contentOffset.x = contentSize.width - size.width;
    }
    
    [_contentView setContentOffset:contentOffset animated:YES];
    
}

@end
