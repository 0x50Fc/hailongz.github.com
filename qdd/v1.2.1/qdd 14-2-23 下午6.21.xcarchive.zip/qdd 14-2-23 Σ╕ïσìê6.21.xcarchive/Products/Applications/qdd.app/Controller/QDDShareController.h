//
//  QDDShareController.h
//  qdd
//
//  Created by zhang hailong on 14-2-19.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDShareController : VTController

@property(nonatomic,retain) IBOutlet UIView * view;
@property(nonatomic,retain) IBOutlet UIView * contentView;
@property(nonatomic,retain) id topicId;
@property(nonatomic,retain) id productId;
@property(nonatomic,retain) NSString * image;
@property(nonatomic,retain) NSString * body;

-(IBAction) doBeginShareAction:(id)sender;

-(IBAction) doCancelShareAction:(id)sender;

-(IBAction) toFansAction:(id)sender;

-(IBAction) toWeiboAction:(id)sender;

-(IBAction) toWeixinAction:(id)sender;

@end
