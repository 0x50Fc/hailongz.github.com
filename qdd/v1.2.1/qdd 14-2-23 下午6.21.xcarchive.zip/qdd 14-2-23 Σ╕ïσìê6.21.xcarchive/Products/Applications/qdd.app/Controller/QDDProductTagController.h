//
//  QDDProductTagController.h
//  qdd
//
//  Created by zhang hailong on 14-2-14.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDProductTagController : VTDataController<VTScrollViewDelegate>

@property(nonatomic,retain) IBOutlet UIScrollView * contentView;

@property(nonatomic,retain) NSString * selectedTag;
@property(nonatomic,retain) IBOutlet UIButton * nextButton;

-(void) reloadContentView;

-(IBAction) doScrollNextAction:(id)sender;

@end

@protocol QDDProductTagControllerDelegate <VTDataControllerDelegate>

@optional

-(void) productTagController:(QDDProductTagController *) tagController didTagAction:(id) dataItem;

@end