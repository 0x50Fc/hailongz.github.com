//
//  QDDPublishController.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishController.h"

#import "QDDPublishTask.h"

#define ACTION_DELETE   @"删除"
#define ACTION_CAMERA   @"拍照"
#define ACTION_LIBRARY  @"相册"

#import "WXApi.h"

#import "QDDCoinTask.h"

@interface QDDPublishController()

@property(nonatomic,retain) UIImageView * focusImageView;

-(void) visableKeyboard:(CGRect) frame;

-(void) hiddenKeyboard:(CGRect) frame;

@end

@implementation QDDPublishController


-(void) dealloc{
    
    [_keyboardView setDelegate:nil];
    [_keyboardView setKeyInput:nil];
    
}

-(void) awakeFromNib{
    [super awakeFromNib];
    
    UIImage * image = [UIImage imageNamed:@"btn6.png"];
    
    for (VTImageView * imageView in _imageViews) {
        [imageView setDefaultImage:image];
    }
}

-(void) visableKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
       
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - frame.size.height - r.origin.y)];
        
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - r.origin.y)];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(BOOL) textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if([text isEqualToString:@"\n"]){
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

-(void) textViewDidBeginEditing:(UITextView *)textView{
    [_contentView scrollRectToVisible:textView.frame animated:YES];
}

-(IBAction) imageAction:(id)sender{
    UIImageView * imageView = sender;
    if(![imageView isKindOfClass:[UIImageView class]]){
        for (imageView in [sender subviews]) {
            if([imageView isKindOfClass:[UIImageView class]]){
                break;
            }
        }
    }
    
    self.focusImageView = imageView;
    
    if(imageView){
        
        UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles: nil];
        
        [actionSheet setTag:100];
        
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            [actionSheet addButtonWithTitle:ACTION_CAMERA];
        }
        
        [actionSheet addButtonWithTitle:ACTION_LIBRARY];
        
        if([imageView image] && [imageView image] != [UIImage imageNamed:@"btn6.png"]){
            [actionSheet addButtonWithTitle:ACTION_DELETE];
        }
        
        [actionSheet setCancelButtonIndex:[actionSheet addButtonWithTitle:@"取消"]];
        
        [actionSheet showInView:imageView.window];
    }
}

- (IBAction)publishAction:(id)sender {
    
    NSString * body = [[_bodyTextView text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([body length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入内容" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if(_payMoneyField){
        
        double payMoney = [[_payMoneyField text] doubleValue];
        double expendMoney = [[_expendMoneyField text] doubleValue];
        
        if(payMoney == 0.0){
            
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入一般花费" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            
            [alertView show];
            
            return;
            
        }
        
        if(expendMoney > payMoney){
            
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"实际花费应小于一般花费" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            
            [alertView show];
            
            return;
        }
        
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDPublishTask * task = [[QDDPublishTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setBody:body];
    [task setTagObjects:[_tagController selectedDataObjects]];
    [task setClassifyObjects:[_classifyController selectedClassifyObjects]];
    [task setPayMoney:[[_payMoneyField text] doubleValue]];
    [task setExpendMoney:[[_expendMoneyField text] doubleValue]];
    [task setToWeibo:[_weiboButton isSelected]];
    [task setToQQ:[_qqButton isSelected]];
    [task setTopicId:self.topicId];
    [task setProductId:self.productId];
    
    CLLocation * location = [(id<QDDContext>)self.context location];
    
    if(location){
        [task setLatitude:location.coordinate.latitude];
        [task setLongitude:location.coordinate.longitude];
    }
    
    NSMutableArray * images = [NSMutableArray arrayWithCapacity:4];
    
    for(VTImageView * imageView in _imageViews){
        if([imageView image] && [imageView image] != [imageView defaultImage]){
            [images addObject:[imageView image]];
        }
    }
    
    [task setImages:images];
    
    [self.context handle:@protocol(IQDDPublishTask) task:task priority:0];
    
    
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(actionSheet.tag == 100){
    
        NSString * title = [actionSheet buttonTitleAtIndex:buttonIndex];
        
        
        if([title isEqualToString:ACTION_CAMERA]){
            
            UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
            
            [imagePickerController setDelegate:self];
            [imagePickerController setSourceType:UIImagePickerControllerSourceTypeCamera];
            
            id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
            
            [rootViewController presentModalViewController:imagePickerController animated:YES];
        }
        else if([title isEqualToString:ACTION_LIBRARY]){
            
            UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
            
            [imagePickerController setDelegate:self];
            [imagePickerController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            
            id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
            
            [rootViewController presentModalViewController:imagePickerController animated:YES];
            
        }
        else if([title isEqualToString:ACTION_DELETE]){
            
            [_focusImageView setImage:nil];
            
        }
    }
    else if(actionSheet.tag == 200){
        
        NSString * body = [[_bodyTextView text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        UIImage * image = nil;
 
        for(VTImageView * imageView in _imageViews){
            if([imageView image] && [imageView image] != [imageView defaultImage]){
                image = [imageView image];
                break;
            }
        }
        
        if(buttonIndex == 0){
        

            [(id<QDDContext>)self.context sendWeixinWithTitle:@"钱多多" withBody:body withImage:image scene:QDDWXSceneSession];
            
        }
        else if(buttonIndex == 1){
            
            [(id<QDDContext>)self.context sendWeixinWithTitle:@"钱多多" withBody:body withImage:image scene:QDDWXSceneTimeline];
            
        }
        
    }
    
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage * image = [info valueForKey:UIImagePickerControllerEditedImage];
    
    if(image == nil){
        image = [info valueForKey:UIImagePickerControllerOriginalImage];
    }
    
    [self.focusImageView setImage:image];
    
    [picker dismissModalViewControllerAnimated:YES];
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissModalViewControllerAnimated:YES];
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{

    [_statusView setUserInteractionEnabled:YES];
    [_statusView setStatus:nil];
    
    if([self.delegate respondsToSelector:@selector(publishController:didFailWithError:)]){
        [self.delegate publishController:self didFailWithError:error];
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    [self.context handle:@protocol(IQDDCoinTask) task:[[QDDCoinTask alloc] init] priority:0];
    
    [_statusView setUserInteractionEnabled:YES];
    [_statusView setStatus:nil];
    
    if([self.delegate respondsToSelector:@selector(publishController:didSuccessResults:)]){
        [self.delegate publishController:self didSuccessResults:results];
    }
    
}

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
    
    if(_payMoneyField == textField || _expendMoneyField == textField){
        
        [_keyboardView setKeyInput:textField];
        
        [textField setInputView:_keyboardView];
        [textField reloadInputViews];
    }
    
    return YES;
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(_payMoneyField == textField){
        [_expendMoneyField becomeFirstResponder];
    }
    else if(_expendMoneyField == textField){
        [_bodyTextView becomeFirstResponder];
    }
    
    return YES;
}

-(BOOL) keyboardView:(QDDKeyboardView *)keyboardView inputKey:(NSString *)key{
    
    if([key isEqualToString:@"ok"]){
        if([keyboardView keyInput] == _payMoneyField){
            [_expendMoneyField becomeFirstResponder];
        }
        else if([keyboardView keyInput] == _expendMoneyField){
            [_bodyTextView becomeFirstResponder];
        }
        return NO;
    }
    else if([key isEqualToString:@"<-"]){
        [[keyboardView keyInput] deleteBackward];
        return NO;
    }
    else if([key isEqualToString:@"clear"]){
        [(UITextField *)[keyboardView keyInput] setText:@""];
        return NO;
    }
    
    return YES;
}

-(IBAction) doWeiboAction:(id)sender{
    
    if([_weiboButton isSelected]){
        [_weiboButton setSelected:NO];
    }
    else{
        
        if([(id<QDDContext>)self.context weiboToken]){
            [_weiboButton setSelected:YES];
        }
        else{
            [(id<QDDContext>)self.context weiboLogin];
        }
    }
    
}

-(IBAction) doQQAction:(id)sender{
    
    if([_qqButton isSelected]){
        [_qqButton setSelected:NO];
    }
    else{
        
        if([(id<QDDContext>)self.context qqToken]){
            [_qqButton setSelected:YES];
        }
        else{
            [(id<QDDContext>)self.context qqLogin];
        }
    }

}

-(IBAction) doWeixinAction:(id)sender{
    
    if([(id<QDDContext>)self.context canSendWeixinWithAlert:YES]){
        UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:@"分享到微信" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"好友",@"朋友圈", nil];
        
        [actionSheet setTag:200];
        
        [actionSheet showInView:[sender window]];
    }
    
}

-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    
    if(context){
        
        id<QDDContext> ctx = (id<QDDContext>)context;
        
        if([ctx weiboToken]){
            
            [_weiboButton setSelected:![ctx disabledWeibo]];
            
        }
        
        if([ctx qqToken]){
            [_qqButton setSelected:![ctx disabledQQ]];
        }
        
        NSArray * images = [self.context focusValueForKey:@"publish-images"];
        
        NSInteger index = 0;
        
        while(index < [images count] && index < [_imageViews count]){
            
            [(VTImageView *)[_imageViews objectAtIndex:index] setImage:[images objectAtIndex:index]];
            
            index ++;
        }
        
        [self.context setFocusValue:nil forKey:@"publish-images"];
        
    }
}

@end
