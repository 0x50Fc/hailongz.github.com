//
//  QDDCommentListViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-20.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDCommentListViewController.h"

#import "QDDAPIQueryValuesTask.h"


@interface QDDCommentListViewController ()


@end

@implementation QDDCommentListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    QDDAPIQueryValuesTask * task = [[QDDAPIQueryValuesTask alloc] init];
    
    [task setQueryValues:[NSMutableDictionary dictionaryWithDictionary:self.url.queryValues]];
    
    [self.context handle:@protocol(IQDDAPIQueryValuesTask) task:task priority:0];
    
    NSURL * url = [NSURL URLWithString:[self.config stringValueForKey:@"url"] queryValues:[task queryValues]];
    
    NSLog(@"%@",url);
    
    [_documentController setDocumentURL:url];
    
    [_documentController reloadData];
    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) vtURLDocumentControllerWillLoading:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
}

-(void) vtURLDocumentControllerDidLoaded:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
}


-(void) vtURLDocumentController:(VTURLDocumentController *)controller doActionElement:(VTDOMElement *)element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if([uid length]){
            
            [self openUrl:[NSURL URLWithString:@"comment-list/user-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:uid,@"uid",nick,@"nick", nil]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"comment"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        id topicId = [element attributeValueForKey:@"topicId"];
        id commentId = [element attributeValueForKey:@"commentId"];
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if(topicId || commentId){
            
            if(commentId){
                [_commentController setTopicId:nil];
                [_commentController setCommentId:[commentId longLongValue]];
                [_commentController setTuid:[uid longLongValue]];
                
                [_commentController.titleLabel setText:[NSString stringWithFormat:@"回复: %@",nick]];
            }
            else {
                [_commentController setTopicId:topicId];
                [_commentController setCommentId:0];
                [_commentController setTuid:0];
                
                [_commentController.titleLabel setText:@"写评论"];
            }
        
            [_commentController.textView becomeFirstResponder];
        }
        
    }
    else if([actionName isEqualToString:@"image"]){
        
        NSString * src = [element attributeValueForKey:@"src"];
        
        if(src){
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:src forKey:@"image"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"web"]){
        
        NSString * url = [element attributeValueForKey:@"url"];
        
        if(url){
            
            [self openUrl:[NSURL URLWithString:@"comment-list/browser" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:url forKey:@"url"]] animated:YES];
            
        }
        
    }
}


-(void) commentControllerDidCommit:(QDDCommentController *) controller{
    
    [controller doCancelAction:nil];
    
    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"成功发布评论"];
    
    [alertView showDuration:1.2];
    
    [_documentController reloadData];
    
}

-(void) commentController:(QDDCommentController *) controller didFialError:(NSError *) error{
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];

}

@end
