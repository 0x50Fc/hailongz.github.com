//
//  QDDProductDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-15.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductDetailsViewController.h"

#import "QDDAPIQueryValuesTask.h"

@interface QDDProductDetailsViewController ()

@end

@implementation QDDProductDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    QDDAPIQueryValuesTask * task = [[QDDAPIQueryValuesTask alloc] init];
    
    [task setQueryValues:[NSMutableDictionary dictionaryWithDictionary:self.url.queryValues]];
    
    [self.context handle:@protocol(IQDDAPIQueryValuesTask) task:task priority:0];
    
    NSURL * url = [NSURL URLWithString:[self.config stringValueForKey:@"url"] queryValues:[task queryValues]];
    
    NSLog(@"%@",url);
    
    [_documentController setDocumentURL:url];
    
    
    [_documentController reloadData];
    

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(likeChangedAction:) name:QDDLikeChangedNotification object:nil];
    
}

-(void) viewDidUnload{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDLikeChangedNotification object:nil];
    
    [super viewDidUnload];
}

-(void) dealloc{
    
     [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDLikeChangedNotification object:nil];
    
}

-(void) likeChangedAction:(NSNotification *) notification{
    
    [_documentController reloadElement:[_documentController.document elementById:@"likedContent"] queryValues:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) vtURLDocumentControllerWillLoading:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
}

-(void) vtURLDocumentControllerDidLoaded:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
}


-(void) vtURLDocumentController:(VTURLDocumentController *)controller doActionElement:(VTDOMElement *)element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if([uid length]){
            
            [self openUrl:[NSURL URLWithString:@"product-details/user-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:uid,@"uid",nick,@"nick", nil]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"like"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        id productId = [element stringValueForKey:@"productId"];
        
        if(productId){
            
            [_likeController doLikeElement:element];
            
        }
        
    }
    else if([actionName isEqualToString:@"image"]){
        
        NSString * src = [element attributeValueForKey:@"src"];
        
        if(src){
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:src forKey:@"image"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"web"]){
        
        NSString * url = [element attributeValueForKey:@"url"];
        NSString * title = [element attributeValueForKey:@"title"];
        
        if(url){
            
            [self openUrl:[NSURL URLWithString:@"product-details/browser" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:url,@"url",title,@"title", nil]] animated:YES];
            
        }
        
    }
}

@end
