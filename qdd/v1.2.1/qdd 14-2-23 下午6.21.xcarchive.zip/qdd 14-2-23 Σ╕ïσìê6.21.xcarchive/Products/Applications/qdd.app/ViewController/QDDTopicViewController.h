//
//  QDDTopicViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-15.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDCommentController.h"
#import "QDDShareController.h"
#import "QDDLikeController.h"

@interface QDDTopicViewController : QDDViewController<VTDocumentDataControllerDelegate,QDDCommentControllerDelegate>

@property (strong, nonatomic) IBOutlet VTDocumentDataController *dataController;
@property (strong, nonatomic) IBOutlet QDDCommentController *commentController;
@property (strong, nonatomic) IBOutlet QDDShareController *shareController;
@property (strong, nonatomic) IBOutlet QDDLikeController *likeController;

@end
