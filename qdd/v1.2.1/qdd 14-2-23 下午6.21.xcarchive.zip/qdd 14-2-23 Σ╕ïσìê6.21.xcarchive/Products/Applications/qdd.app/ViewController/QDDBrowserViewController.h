//
//  QDDBrowserViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDRefreshButton.h"

@interface QDDBrowserViewController : QDDViewController<UIWebViewDelegate>

@property (strong, nonatomic) IBOutlet UIBarButtonItem *refreshButtonItem;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *loadingButtonItem;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loadingView;
@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) IBOutlet UINavigationItem *toolItem;
@property (strong, nonatomic) IBOutlet QDDRefreshButton *refreshButton;

@end
