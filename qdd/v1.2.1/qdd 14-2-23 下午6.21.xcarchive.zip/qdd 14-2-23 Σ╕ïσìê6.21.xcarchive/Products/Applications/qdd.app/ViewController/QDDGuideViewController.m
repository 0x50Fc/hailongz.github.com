//
//  QDDGuideViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDGuideViewController.h"

@interface QDDGuideViewController ()

@end

@implementation QDDGuideViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) toRootViewController{
    
    [(id<QDDContext>)self.context setGuided:YES];
    
    [(id<QDDContext>)self.context toRootViewController:YES];
    
}

-(void) scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.x + scrollView.bounds.size.width > scrollView.contentSize.width + 10){
        
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(toRootViewController) object:nil];
        
        [self performSelector:@selector(toRootViewController) withObject:nil afterDelay:0.0];
        
    }
    else{
        [_pageControl setCurrentPage:scrollView.contentOffset.x / scrollView.bounds.size.width];
    }
}

@end
