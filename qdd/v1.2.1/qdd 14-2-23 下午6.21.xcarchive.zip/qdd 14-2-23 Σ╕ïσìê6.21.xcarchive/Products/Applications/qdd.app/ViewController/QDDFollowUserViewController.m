//
//  QDDFollowUserViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-22.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDFollowUserViewController.h"

@interface QDDFollowUserViewController ()

@end

@implementation QDDFollowUserViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded]
       && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
    
}


-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"user"]){
        
        NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [data setValue:[element attributeValueForKey:@"uid"] forKey:@"uid"];
        [data setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        NSURL * url = [NSURL URLWithString:@"root:///root/fold/center/follow-user/user-details"
                             relativeToURL:self.url queryValues:data];
        
        [self openUrl:url animated:YES];
        
    }
}

@end
