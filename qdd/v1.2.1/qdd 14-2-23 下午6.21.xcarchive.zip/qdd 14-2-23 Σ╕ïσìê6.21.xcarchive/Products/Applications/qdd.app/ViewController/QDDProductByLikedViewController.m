//
//  QDDProductByLikedViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-23.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductByLikedViewController.h"

#import "QDDProductUnLikeTask.h"

#import "QDDAPIQueryValuesTask.h"

@interface QDDProductByLikedViewController ()

@end

@implementation QDDProductByLikedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    QDDAPIQueryValuesTask * task = [[QDDAPIQueryValuesTask alloc] init];
    
    [task setQueryValues:[NSMutableDictionary dictionaryWithDictionary:self.url.queryValues]];
    
    [self.context handle:@protocol(IQDDAPIQueryValuesTask) task:task priority:0];
    
    NSURL * url = [NSURL URLWithString:[self.config stringValueForKey:@"url"] queryValues:[task queryValues]];
    
    NSLog(@"%@",url);
    
    [_documentController setDocumentURL:url];
    
    [_documentController reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void) vtURLDocumentControllerWillLoading:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
}

-(void) vtURLDocumentControllerDidLoaded:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
}


-(void) vtURLDocumentController:(VTURLDocumentController *)controller doActionElement:(VTDOMElement *)element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if([uid length]){
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/product-byliked/user-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:uid,@"uid",nick,@"nick", nil]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"image"]){
        
        NSString * src = [element attributeValueForKey:@"src"];
        
        if(src){
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:src forKey:@"image"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"web"]){
        
        NSString * url = [element attributeValueForKey:@"url"];
        
        if(url){
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/product-byliked/browser" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:url forKey:@"url"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"product"]){
        
        NSString * productId = [element attributeValueForKey:@"productId"];
        
        if(productId){
            
            NSString * event = [element attributeValueForKey:@"event"];
            
            if([event isEqualToString:@"commitEditing"]){
                
                
                QDDProductUnLikeTask * task = [[QDDProductUnLikeTask alloc] init];
                
                [task setProductId:productId];
                
                [self.context handle:@protocol(IQDDProductUnLikeTask) task:task priority:0];
                
                UIView * v = [element delegate];
                
                UITableView * tableView = nil;
                UITableViewCell * tableViewCell = nil;
                
                while (tableView == nil && v) {
                    
                    if([v isKindOfClass:[UITableView class]]){
                        tableView = (UITableView *) v;
                    }
                    else if([v isKindOfClass:[UITableViewCell class]]){
                        tableViewCell = (UITableViewCell *) v;
                    }
                    
                    v = [v superview];
                }
                
                [element removeFromParentElement];
                
                [_documentController relayout];
                
                if(tableView && tableViewCell){
                    
                    NSIndexPath * indexPath = [tableView indexPathForCell:tableViewCell];
                    
                    if(indexPath){
                        if([tableView numberOfRowsInSection:indexPath.section] == 1){
                            [tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationFade];
                        }
                        else{
                            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
                        }
                    }
                    
                }
                
            }
            else if([event isEqualToString:@"didSelect"]){
                
                UIView * v = [element delegate];
                
                UITableView * tableView = nil;
                UITableViewCell * tableViewCell = nil;
                
                while (tableView == nil && v) {
                    
                    if([v isKindOfClass:[UITableView class]]){
                        tableView = (UITableView *) v;
                    }
                    else if([v isKindOfClass:[UITableViewCell class]]){
                        tableViewCell = (UITableViewCell *) v;
                    }
                    
                    v = [v superview];
                }
                
                if(tableView && tableViewCell){
                    
                    NSIndexPath * indexPath = [tableView indexPathForCell:tableViewCell];
                    
                    if(indexPath){
                        
                        [tableView deselectRowAtIndexPath:indexPath animated:YES];
                        
                    }
                    
                }
            
                [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/product-byliked/product-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:productId forKey:@"pid"]] animated:YES];
            }
            else{
                
                [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/product-byliked/product-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:productId forKey:@"pid"]] animated:YES];
                
            }
        }
        
    }
    
}

@end
