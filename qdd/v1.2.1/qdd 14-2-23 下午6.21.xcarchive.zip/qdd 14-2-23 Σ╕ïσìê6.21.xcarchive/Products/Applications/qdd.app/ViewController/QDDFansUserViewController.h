//
//  QDDFansUserViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-22.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDFansUserViewController : QDDViewController<VTDocumentDataControllerDelegate>

@property (strong, nonatomic) IBOutlet VTDocumentDataController *dataController;

@end
