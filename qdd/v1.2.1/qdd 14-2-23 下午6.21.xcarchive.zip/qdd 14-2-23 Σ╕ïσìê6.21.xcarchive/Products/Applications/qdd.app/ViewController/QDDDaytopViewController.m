//
//  QDDDaytopViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDDaytopViewController.h"

@interface QDDDaytopViewController ()

@end

@implementation QDDDaytopViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded] && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
    
}

-(void) vtDataControllerWillLoading:(VTDataController *)controller{
    
    self.topNavigationItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
}

-(void) vtDataControllerDidLoaded:(VTDataController *)controller{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
}

-(void) vtDataController:(VTDataController *)controller didFitalError:(NSError *)error{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
}

-(void) vtPageDataController:(VTPageDataController *)dataController itemViewController:(VTItemViewController *)itemViewController doAction:(id<IVTAction>)action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"topic"]){
        
        id dataItem = [itemViewController dataItem];
        
        id tid = [dataItem stringValueForKey:@"tid"];
        
        if(tid){
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/daytop/topic-details" queryValues:[NSDictionary dictionaryWithObject:tid forKey:@"tid"]] animated:YES];
        }
        
    }
    else if([actionName isEqualToString:@"image"]){
        
        id dataItem = [itemViewController dataItem];
        
        id image = [dataItem stringValueForKey:@"image"];
        
        if(image){
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:image forKey:@"image"]] animated:YES];
        }
        
    }
    else if([actionName isEqualToString:@"like"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        id dataItem = [itemViewController dataItem];
        
        id tid = [dataItem stringValueForKey:@"tid"];
        id pid = [dataItem stringValueForKey:@"pid"];
        
        if(tid){
            
            [_likeController setTopicId:tid];
            [_likeController setProductId:nil];
            
            [_likeController doLikeButton:(UIButton *)action];
        }
        else if(pid){
            
            [_likeController setTopicId:nil];
            [_likeController setProductId:pid];
            
            [_likeController doLikeButton:(UIButton *)action];
        }
        
    }
    
}

-(IBAction) doRefreshAction:(id)sender{
    if(! [[_dataController dataSource] isLoading]){
        [_dataController reloadData];
    }
}

@end
