//
//  QDDImagePickerPromptViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDImagePickerPromptViewController : QDDViewController

@property (strong, nonatomic) IBOutlet UIView *contentView;
- (IBAction) doKeyAction:(id)sender;

@end
