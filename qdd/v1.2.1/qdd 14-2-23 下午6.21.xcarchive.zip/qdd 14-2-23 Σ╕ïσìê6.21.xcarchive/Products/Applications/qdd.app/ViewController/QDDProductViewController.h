//
//  QDDProductViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDProductTagController.h"

#import "QDDLikeController.h"

@interface QDDProductViewController : QDDViewController<QDDProductTagControllerDelegate,VTContainerDataControllerDelegate>

@property (strong, nonatomic) IBOutlet VTContainerDataController *dataController;
@property (strong, nonatomic) IBOutlet QDDProductTagController *tagController;
@property (strong, nonatomic) IBOutlet QDDLikeController *likeController;

@end
