//
//  QDDTopicViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-15.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDTopicViewController.h"

@interface QDDTopicViewController ()

@property(nonatomic,retain) VTDOMElement * commentElement;

@end

@implementation QDDTopicViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSDictionary * queryValues = [self.url queryValues];
    
    self.title = [queryValues valueForKey:@"title"];
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_dataController.dataSource setValue:[queryValues objectValueForKey:@"sid"] forKey:@"sid"];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded] && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
    
}

-(void) vtDocumentDataController:(VTDocumentDataController *)dataController element:(VTDOMElement *)element doAction:(id<IVTAction>)action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"topic"]){
        
        id topicId = [element attributeValueForKey:@"tid"];
        
        if(topicId){
            [self openUrl:[NSURL URLWithString:@"topic/topic-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:topicId forKey:@"tid"]] animated:YES];
        }
        
    }
    else if([actionName isEqualToString:@"product"]){
        
        id productId = [element attributeValueForKey:@"pid"];
        
        if(productId){
            [self openUrl:[NSURL URLWithString:@"topic/product-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:productId forKey:@"pid"]] animated:YES];
        }
        
    }
    else if([actionName isEqualToString:@"like"]){
        
        id topicId = [element attributeValueForKey:@"topicId"];
        
        if(topicId){
            [_likeController doLikeElement:element];
        }
        
    }
    else if([actionName isEqualToString:@"comment"]){
        
        id topicId = [element attributeValueForKey:@"topicId"];
        
        if(topicId){
            
            self.commentElement = element;
            
            [_commentController setTopicId:topicId];
            
            [_commentController.textView becomeFirstResponder];
            
        }
        
    }
    else if([actionName isEqualToString:@"share"]){
        
        id topicId = [element attributeValueForKey:@"topicId"];
        
        if(topicId){
            
            [_shareController setTopicId:topicId];
            
            VTDOMElement * el = [element.document elementById:@"topicImage"];
            
            if(el){
                [_shareController setImage:[el attributeValueForKey:@"src"]];
            }
            
            el = [element.document elementById:@"topicTitle"];
            
            if(el){
                [_shareController setBody:[el text]];
            }
            
            [_shareController doBeginShareAction:nil];
        }
    }
    else if([actionName isEqualToString:@"image"]){
        
        NSString * src = [element attributeValueForKey:@"src"];
        
        if(src){
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:src forKey:@"image"]] animated:YES];
            
        }
        
    }
}

-(void) commentControllerDidCommit:(QDDCommentController *) controller{
    
    [controller doCancelAction:nil];
    
    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"成功发布评论"];
    
    [alertView showDuration:1.2];
    
    if([_commentElement isKindOfClass:[VTDOMViewElement class]]){
        
        UIButton * button = (UIButton *) [(VTDOMViewElement *) _commentElement view];
        
        if([button isKindOfClass:[UIButton class]]){
            
            int count = [[button titleForState:UIControlStateNormal] intValue] +1;
            
            if(count <0 ){
                count = 0;
            }
            
            [button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
            
        }
    }
    
    self.commentElement = nil;
}

-(void) commentController:(QDDCommentController *) controller didFialError:(NSError *) error{
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];
    
    self.commentElement = nil;
}

@end
