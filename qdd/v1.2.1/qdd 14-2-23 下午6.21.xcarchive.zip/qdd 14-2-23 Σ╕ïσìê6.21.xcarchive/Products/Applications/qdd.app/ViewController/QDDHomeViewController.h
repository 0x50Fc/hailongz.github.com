//
//  QDDHomeViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-4.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDFeedController.h"

@interface QDDHomeViewController : QDDViewController<VTDocumentDataControllerDelegate>

@property(strong,nonatomic) IBOutletCollection(VTButton) NSArray * classifyButtons;
@property (strong,nonatomic) NSString * classify;
@property (strong, nonatomic) IBOutletCollection(NSObject) NSArray *classifyEnabledViews;
@property (strong, nonatomic) IBOutlet QDDFeedController *feedController;

@end
