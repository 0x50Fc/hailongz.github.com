//
//  QDDTopicDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-15.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDTopicDetailsViewController.h"

#import "QDDAPIQueryValuesTask.h"

#import "QDDTopicLikeTask.h"

#import "QDDTopicUnLikeTask.h"

@interface QDDTopicDetailsViewController ()

@property(nonatomic,retain) VTDOMElement * commentElement;

@end

@implementation QDDTopicDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    QDDAPIQueryValuesTask * task = [[QDDAPIQueryValuesTask alloc] init];
    
    [task setQueryValues:[NSMutableDictionary dictionaryWithDictionary:self.url.queryValues]];
    
    [self.context handle:@protocol(IQDDAPIQueryValuesTask) task:task priority:0];
    
    NSURL * url = [NSURL URLWithString:[self.config stringValueForKey:@"url"] queryValues:[task queryValues]];
    
    NSLog(@"%@",url);
    
    [_documentController setDocumentURL:url];

    [_documentController reloadData];
    
    [_commentController setTopicId:[[task queryValues] stringValueForKey:@"tid"]];
    
    [_shareController setTopicId:[[task queryValues] stringValueForKey:@"tid"]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(likeChangedAction:) name:QDDLikeChangedNotification object:nil];
    
}

-(void) viewDidUnload{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDLikeChangedNotification object:nil];
    
    [super viewDidUnload];
}

-(void) likeChangedAction:(NSNotification *) notification{

    [_documentController reloadElement:[_documentController.document elementById:@"likedContent"] queryValues:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) vtURLDocumentController:(VTURLDocumentController *)controller doActionElement:(VTDOMElement *)element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"product"]){
        
        id pid = [element attributeValueForKey:@"pid"];
        
        if(pid){
            
            [self openUrl:[NSURL URLWithString:@"topic-details/product-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:pid forKey:@"pid"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if([uid length]){
            
            [self openUrl:[NSURL URLWithString:@"topic-details/user-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:uid,@"uid",nick,@"nick", nil]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"share"]){
        
        [_shareController doBeginShareAction:nil];
        
    }
    else if([actionName isEqualToString:@"comment"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        id topicId = [element attributeValueForKey:@"topicId"];
        id commentId = [element attributeValueForKey:@"commentId"];
        id uid = [element attributeValueForKey:@"uid"];
        id nick = [element attributeValueForKey:@"nick"];
        
        if(topicId || commentId){
            
            if(commentId){
                [_commentController setTopicId:nil];
                [_commentController setCommentId:[commentId longLongValue]];
                [_commentController setTuid:[uid longLongValue]];
                
                [_commentController.titleLabel setText:[NSString stringWithFormat:@"回复: %@",nick]];
            }
            else {
                [_commentController setTopicId:topicId];
                [_commentController setCommentId:0];
                [_commentController setTuid:0];
                
                [_commentController.titleLabel setText:@"写评论"];
            }
            
            self.commentElement = element;
            
            [_commentController.textView becomeFirstResponder];
        }
        
    }
    else if([actionName isEqualToString:@"like"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        id topicId = [element stringValueForKey:@"topicId"];
        
        if(topicId){
            
            [_likeController doLikeElement:element];
            
        }
        
    }
    else if([actionName isEqualToString:@"image"]){
        
        NSString * src = [element attributeValueForKey:@"src"];
        
        if(src){
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image" queryValues:[NSDictionary dictionaryWithObject:src forKey:@"image"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"comment-list"]){
        
        id topicId = [element attributeValueForKey:@"topicId"];
        
        if(topicId){
            
            [self openUrl:[NSURL URLWithString:@"topic-details/comment-list" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:topicId forKey:@"topicId"]] animated:YES];
        }
        
    }
    else if([actionName isEqualToString:@"web"]){
        
        NSString * url = [element attributeValueForKey:@"url"];
        NSString * title = [element attributeValueForKey:@"title"];
        
        if(url){
            
            [self openUrl:[NSURL URLWithString:@"topic-details/browser" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:url,@"url",title,@"title", nil]] animated:YES];
            
        }
        
    }
}

-(void) commentControllerDidCommit:(QDDCommentController *) controller{
 
    [controller doCancelAction:nil];
    
    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"成功发布评论"];
    
    [alertView showDuration:1.2];
    
    [_documentController reloadElement:[_documentController.document elementById:@"commentContent"] queryValues:nil];
    
    
    if([_commentElement isKindOfClass:[VTDOMViewElement class]]){
        
        UIButton * button = (UIButton *) [(VTDOMViewElement *) _commentElement view];
        
        if([button isKindOfClass:[UIButton class]]){
           
            int count = [[button titleForState:UIControlStateNormal] intValue] +1;
            
            if(count <0 ){
                count = 0;
            }
            
            [button setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
            
        }
    }
    
    self.commentElement = nil;
}

-(void) commentController:(QDDCommentController *) controller didFialError:(NSError *) error{
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];
    
    self.commentElement = nil;
}

- (IBAction)doRefreshAction:(id)sender {
    if(![_documentController isLoading]){
        [_documentController reloadData];
    }
}

-(void) vtURLDocumentControllerWillLoading:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
}

-(void) vtURLDocumentControllerDidLoaded:(VTURLDocumentController *)controller{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
    
    VTDOMDocument * document = [controller document];
    
    VTDOMElement * element = [document elementById:@"topicImage"];
    
    if(element){
        [_shareController setImage:[element attributeValueForKey:@"src"]];
    }
    
    element = [document elementById:@"topicTitle"];
    
    if(element){
        [_shareController setBody:[element text]];
    }
    
}

-(void) vtURLDocumentController:(VTURLDocumentController *)controller didFailWithError:(NSError *)error{
    self.topNavigationItem.rightBarButtonItem = _refreshButtonItem;
}

@end
