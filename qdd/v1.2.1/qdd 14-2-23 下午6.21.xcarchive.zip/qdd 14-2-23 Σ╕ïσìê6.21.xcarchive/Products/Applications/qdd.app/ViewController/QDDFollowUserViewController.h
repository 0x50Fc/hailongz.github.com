//
//  QDDFollowUserViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-22.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDConcernController.h"

@interface QDDFollowUserViewController : QDDViewController<VTDocumentDataControllerDelegate>

@property (strong, nonatomic) IBOutlet QDDConcernController *dataController;

@end
