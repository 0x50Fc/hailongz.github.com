//
//  QDDSubjectViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDSubjectViewController.h"

@interface QDDSubjectViewController ()

@end

@implementation QDDSubjectViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIPageControl * pageControl = [_topDataController pageControl];
    
    if([pageControl respondsToSelector:@selector(setCurrentPageIndicatorTintColor:)]){
        [pageControl setCurrentPageIndicatorTintColor:[UIColor colorWithRed:242.0 / 255.0 green:108.0 / 255.0 blue:79.0 / 255.0 alpha:1.0]];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded] && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
    
    if(![_topDataController.dataSource isLoaded] && ![_topDataController.dataSource isLoading]){
        [_topDataController reloadData];
    }
}

-(void) vtContainerDataController:(VTContainerDataController *) dataController itemViewController:(VTItemViewController *) itemViewController doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"subject"]){
        
        NSString * title = [itemViewController.dataItem stringValueForKey:@"title"];
        id sid = [itemViewController.dataItem stringValueForKey:@"sid"];
        
        if(sid && title){
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/subject/topic" queryValues:[NSDictionary dictionaryWithObjectsAndKeys:sid,@"sid",title,@"title", nil]] animated:YES];
            
        }
        
    }
    
}

-(void) vtPageDataController:(VTPageDataController *) dataController itemViewController:(VTItemViewController *) itemViewController doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"topplace"]){
        
        int etype = [itemViewController.dataItem intValueForKey:@"etype"];
        id eid = [itemViewController.dataItem objectValueForKey:@"eid"];
        
        if(etype == 0 && eid){
            // topic
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/subject/topic-details" queryValues:[NSDictionary dictionaryWithObjectsAndKeys:eid,@"tid", nil]] animated:YES];
            
        }
        else if(etype == 1 && eid){
            // product
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/subject/product-details" queryValues:[NSDictionary dictionaryWithObjectsAndKeys:eid,@"pid", nil]] animated:YES];
        }
        
    }
    
}

@end
