//
//  QDDProductSearchViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-22.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductSearchViewController.h"

@interface QDDProductSearchViewController ()

@end

@implementation QDDProductSearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.searchDisplayController setActive:YES];
    
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    [self.searchDisplayController.searchBar becomeFirstResponder];
    
}

- (void) searchDisplayControllerWillEndSearch:(UISearchDisplayController *)controller{
    [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
}

- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView{
    
    [tableView setRowHeight:91];
    [_dataController setTableView:tableView];
    [tableView setDataSource:_dataController];
    [tableView setDelegate:_dataController];
    
}

- (void)searchDisplayController:(UISearchDisplayController *)controller willUnloadSearchResultsTableView:(UITableView *)tableView{
    
    [_dataController cancel];
    [_dataController setTableView:nil];
    
}

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString{
    
    [_dataController cancel];
    [_dataController.dataSource setValue:searchString forKey:@"keyword"];
    [_dataController reloadData];
    
    return YES;
}


-(void) vtTableDataController:(VTTableDataController *) dataController didSelectRowAtIndexPath:(NSIndexPath *) indexPath{
    
    id dataItem = [_dataController dataObjectByIndexPath:indexPath];
    
    id pid = [dataItem objectValueForKey:@"pid"];
    
    if(pid){
        
        [self openUrl:[NSURL URLWithString:@"product-search/product-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:pid forKey:@"pid"]] animated:YES];
    }
    
    [dataController.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(void) visableKeyboard:(CGRect) frame{
    
    CGSize size = self.view.bounds.size;
    
    UIView * v = [_dataController tableView];
    
    CGRect r = [v frame];
    
    r.size.height = size.height - r.origin.y - frame.size.height;
    
    [UIView animateWithDuration:0.3 animations:^{
        [v setFrame:r];
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = self.view.bounds.size;
    
    UIView * v = [_dataController tableView];
    
    CGRect r = [v frame];
    
    r.size.height = size.height - r.origin.y;
    
    [UIView animateWithDuration:0.3 animations:^{
        [v setFrame:r];
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

@end
