//
//  QDDCommentListViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-20.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDCommentController.h"

#import "QDDRefreshButton.h"

@interface QDDCommentListViewController : QDDViewController<VTURLDocumentControllerDelegate,QDDCommentControllerDelegate>
@property (strong, nonatomic) IBOutlet VTURLDocumentController *documentController;
@property (strong, nonatomic) IBOutlet UINavigationItem *topNavigationItem;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *loadingButtonItem;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loadingView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *refreshButtonItem;
@property (strong, nonatomic) IBOutlet QDDCommentController *commentController;
@property (strong, nonatomic) IBOutlet QDDRefreshButton *refreshButton;

@end
