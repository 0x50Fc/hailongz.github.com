//
//  QDDProductViewController.m
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDProductViewController.h"

@interface QDDProductViewController ()

@end

@implementation QDDProductViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_tagController reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded]
       && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
    
}


-(void) productTagController:(QDDProductTagController *) tagController didTagAction:(id) dataItem{
    
    if([dataItem longLongValueForKey:@"tid"]){
        
        [_dataController.dataSource setValue:[dataItem stringValueForKey:@"tag"] forKeyPath:@"tags"];
        
    }
    else{
        [_dataController.dataSource setValue:nil forKeyPath:@"tags"];
    }
    
    [_dataController cancel];
    [_dataController reloadData];
}

-(void) vtContainerDataController:(VTContainerDataController *) dataController itemViewController:(VTItemViewController *) itemViewController doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"product"]){
        
        id pid = [itemViewController.dataItem stringValueForKey:@"pid"];
        
        if(pid){
            
            [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/product/product-details" queryValues:[NSDictionary dictionaryWithObject:pid forKey:@"pid"]] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"like"]){
        
        [_likeController doLikeButton:(UIButton *) action];
        
    }
    
}

@end
