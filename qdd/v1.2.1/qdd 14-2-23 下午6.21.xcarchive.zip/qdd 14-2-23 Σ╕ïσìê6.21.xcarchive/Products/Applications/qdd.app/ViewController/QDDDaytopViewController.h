//
//  QDDDaytopViewController.h
//  qdd
//
//  Created by zhang hailong on 14-2-13.
//  Copyright (c) 2014年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDLikeController.h"

#import "QDDRefreshButton.h"


@interface QDDDaytopViewController : QDDViewController<VTPageDataControllerDelegate>

@property (strong, nonatomic) IBOutlet VTPageDataController *dataController;
@property (strong, nonatomic) IBOutlet QDDLikeController *likeController;
@property (strong, nonatomic) IBOutlet UINavigationItem *topNavigationItem;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *loadingButtonItem;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loadingView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *refreshButtonItem;
@property (strong, nonatomic) IBOutlet QDDRefreshButton * refreshButton;

-(IBAction) doRefreshAction:(id)sender;

@end
