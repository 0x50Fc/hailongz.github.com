//
//  QDDBrowserViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBrowserViewController.h"

@interface QDDBrowserViewController ()

@end

@implementation QDDBrowserViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSDictionary * queryValues = [self.url queryValues];
    
    self.title = [queryValues valueForKey:@"title"];
    
    NSString * key = [queryValues valueForKey:@"key"];
    NSString * url = [queryValues valueForKey:@"url"];
    
    if(key){
        
        NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:[self.config valueForKey:key]]];
        
        [_webView loadRequest:request];
    
    }
    else if(url){
        
        NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
        
        [_webView loadRequest:request];
        
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    if(self.title){
        self.toolItem.title = self.title;
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    self.toolItem.rightBarButtonItem = _loadingButtonItem;
    [_loadingView startAnimating];
    [_refreshButton startAnimating];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    _toolItem.rightBarButtonItem = _refreshButtonItem;
    [_refreshButton stopAnimating];
    
    if(!self.title){
        self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    }
}



@end
