/**
 *  QDDViewController.m
 *  qdd
 *
 *  Created by zhang hailong on 13-11-2.
 *  Copyright 9vteam 2013年. All rights reserved.
 */


#import "QDDViewController.h"

@interface QDDViewController ()

@end

@implementation QDDViewController

@synthesize publishView = _publishView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        if([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]){
            [self setEdgesForExtendedLayout:UIRectEdgeNone];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    
    if([item conformsToProtocol:@protocol(IVTAction)]){
        
        NSString * actionName = [(id<IVTAction>)item actionName];
        id userInfo = [(id<IVTAction>)item userInfo];
        
        if([actionName isEqualToString:@"url"]){
            if(userInfo){
                [self openUrl:[NSURL URLWithString:
                               [userInfo stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
                                     relativeToURL:self.url] animated:NO];
            }
        }
    }
    
}

-(void) dealloc{
    NSLog(@"%@ dealloc",NSStringFromClass([self class]));
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.tabBar setSelectedItem:self.selectedTabItem];
    
    NSLog(@"%@ viewWillAppear",NSStringFromClass([self class]));
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    NSLog(@"%@ viewDidAppear",NSStringFromClass([self class]));
}

-(void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];

    [_publishView setHidden:YES animated:NO];

    NSLog(@"%@ viewWillDisappear",NSStringFromClass([self class]));
}

-(void) viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    NSLog(@"%@ viewDidDisappear",NSStringFromClass([self class]));
}

-(IBAction) doAction:(id)sender{
    
    NSString * actionName = [sender actionName];
    
    if([actionName isEqualToString:@"url-auth"]){
        
        if([self.context uid] == nil){
            
            [self openUrl:[NSURL URLWithString:@"present://root/login"] animated:YES];
            
            return;
        }
        
        [self openUrl:[NSURL URLWithString:[[(id<IVTAction>)sender userInfo] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] relativeToURL:self.url] animated:YES];
    }
    else{
        [super doAction:sender];
    }
}

@end
