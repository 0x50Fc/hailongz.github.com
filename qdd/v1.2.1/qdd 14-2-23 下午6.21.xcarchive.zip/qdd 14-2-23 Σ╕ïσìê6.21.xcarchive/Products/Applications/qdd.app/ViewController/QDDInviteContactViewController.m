//
//  QDDInviteContactViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteContactViewController.h"

#import "QDDFollowTask.h"



@interface QDDInviteContactViewController ()

@end

@implementation QDDInviteContactViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![[_dataController dataSource] isLoaded]
       && ![[_dataController dataSource] isLoading]){
        
        [_dataController reloadData];
    }
}


-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"follow"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        if(uid){
            
            QDDFollowTask * task = [[QDDFollowTask alloc] init];
            
            [task setTuid:[uid longLongValue]];
            
            [self.context handle:@protocol(IQDDFollowTask) task:task priority:0];
            
            if([element isKindOfClass:[VTDOMViewElement class]]){
                
                UIButton * button = (UIButton *) [(VTDOMViewElement *) element view];
                
                if([button isKindOfClass:[UIButton class]]){
                    
                    [button setTitle:@"已关注" forState:UIControlStateNormal];
                    [button setImage:nil forState:UIControlStateNormal];
                    [button setEnabled:NO];
                    [button setAdjustsImageWhenHighlighted:NO];
                    
                }
                
            }
            
        }
        
    }
    else if([actionName isEqualToString:@"people"]){
        
        UITableViewCell * cell = (UITableViewCell *)[element.delegate superview];
        
        while(cell && ![cell isKindOfClass:[UITableViewCell class]]){
            
            cell = (UITableViewCell *) [cell superview];
        }
        
        NSIndexPath * indexPath = [dataController.tableView indexPathForCell:cell];
        
        if(indexPath){
            
            id dataItem = [dataController dataObjectByIndexPath:indexPath];
            
            NSArray * tels = [dataItem valueForKey:@"tels"];
            
            UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:@"邀请好友" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles: nil];
            
            for(NSString * tel in tels){
                [actionSheet addButtonWithTitle:tel];
            }
            
            [actionSheet setCancelButtonIndex:[actionSheet addButtonWithTitle:@"取消"]];
            
            [actionSheet showInView:self.view.window];
            
        }
        
    }
    
}


-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex != [actionSheet cancelButtonIndex]){
        
        NSString * tel = [actionSheet buttonTitleAtIndex:buttonIndex];
        
        if([MFMessageComposeViewController canSendText]){
            
            MFMessageComposeViewController * controller = [[MFMessageComposeViewController alloc] init];
        
            [controller setBody:[NSString stringWithFormat:@"我正在使用钱多多,一起来玩吧."]];
            [controller setRecipients:[NSArray arrayWithObject:tel]];
            [controller setMessageComposeDelegate:self];
            
            [self presentModalViewController:controller animated:YES];
            
        }
        else{
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"设备不支持发短信" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
    }
    
}

-(void) messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result{
    
    [controller dismissModalViewControllerAnimated:YES];
    
}


@end
