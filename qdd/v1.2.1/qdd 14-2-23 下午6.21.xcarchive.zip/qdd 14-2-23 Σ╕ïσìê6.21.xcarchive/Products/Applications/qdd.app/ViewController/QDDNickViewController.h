//
//  QDDNickViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDNickViewController : QDDViewController<UITextFieldDelegate,IVTUplinkTaskDelegate>

@property (strong, nonatomic) IBOutlet VTStatusView *statusView;
@property (strong, nonatomic) IBOutlet UITextField *nickField;


- (IBAction)doLogoutAction:(id)sender;

- (IBAction)doSubmitAction:(id)sender;

@end
