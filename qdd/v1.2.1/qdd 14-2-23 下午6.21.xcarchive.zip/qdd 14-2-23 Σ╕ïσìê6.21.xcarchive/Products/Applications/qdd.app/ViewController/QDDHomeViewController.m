//
//  QDDHomeViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-4.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDHomeViewController.h"

@interface QDDHomeViewController ()

@end

@implementation QDDHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onPublishFeedAction:) name:QDDPublishFeedNotification object:nil];
    }
    return self;
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDPublishFeedNotification object:nil];
    
}

-(void) onPublishFeedAction:(NSNotification *) notification{
    
    [self setClassify:@"new"];
    
    [_feedController reloadData];
}

- (void)viewDidLoad
{
    [self.dataOutletContainer setStatus:self.classify];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}
    
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_feedController.dataSource isLoaded] && ![_feedController.dataSource isLoading]){
        [_feedController reloadData];
    }
    else{
        [_feedController.tableView reloadData];
    }
}

-(IBAction)doAction:(id)sender{

    NSString * actionName = [sender actionName];
    
    if([actionName isEqualToString:@"classify"]){
        
        self.classify = (NSString *) [sender userInfo];
        
        [self.dataOutletContainer setStatus:_classify];
        [self.dataOutletContainer applyDataOutlet:self];
        
        [_feedController.tableView reloadData];
        [_feedController reloadData];
        
    }
    else{
        [super doAction:sender];
    }
    
}

-(void) setClassify:(NSString *)classify{
    
    _classify = classify;
    
    for(VTButton * button in _classifyButtons){
        [button setSelected:[classify isEqualToString:[button userInfo]]];
    }
    
    [_feedController.dataSource setValue:classify forKey:@"status"];
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
   
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"feed"]){
        
        NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"root:///root/fold/center/share/%@",[action userInfo]]
                             relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:[element attributeValueForKey:@"pid"] forKey:@"pid"]];
        
        [self openUrl:url animated:YES];
        
    }
    
    else if([actionName isEqualToString:@"user"]){
        
        NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [data setValue:[element attributeValueForKey:@"uid"] forKey:@"uid"];
        [data setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"root:///root/fold/center/share/%@",[action userInfo]]
                             relativeToURL:self.url queryValues:data];
        
        [self openUrl:url animated:YES];
        
    }
    else if([actionName isEqualToString:@"image"]){
    
        NSArray * images = [element valueForKey:@"images"];
        
        if(images == nil){
            images = [[element parentElement] valueForKey:@"images"];
        }
        
        if([images isKindOfClass:[NSArray class]]){
            
            NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:4];
            
            NSInteger pageIndex = [[[element parentElement] childs] indexOfObject:element];
            
            [data setObject:images forKey:@"images"];
            [data setObject:[NSString stringWithFormat:@"%d",pageIndex] forKey:@"pageIndex"];
            
            [self.context setFocusValue:data forKey:@"image"];
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image"] animated:YES];
            
        }
        
    }
    else if([actionName isEqualToString:@"comment"]){
        
        id pid = [element attributeValueForKey:@"pid"];
        
        if(pid){
        
            [self openUrl:[NSURL URLWithString:@"pop:///publish-comment"
                               queryValues:[NSDictionary dictionaryWithObject:pid forKey:@"pid"]] animated:YES];
            
        }
    }
}
  
@end
