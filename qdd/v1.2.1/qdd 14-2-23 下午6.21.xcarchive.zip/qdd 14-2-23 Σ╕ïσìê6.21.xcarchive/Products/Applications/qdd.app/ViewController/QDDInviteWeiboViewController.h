//
//  QDDInviteWeiboViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDInviteController.h"

#import "WeiboSDK.h"

@interface QDDInviteWeiboViewController : QDDViewController<WeiboSDKJSONDelegate>

@property (strong, nonatomic) IBOutlet QDDInviteController *dataController;

@end
