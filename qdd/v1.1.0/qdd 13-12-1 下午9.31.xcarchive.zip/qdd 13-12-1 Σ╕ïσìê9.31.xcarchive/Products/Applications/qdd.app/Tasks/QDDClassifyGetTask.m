//
//  QDDClassifyGetTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-22.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDClassifyGetTask.h"

@implementation QDDClassifyGetTask

@synthesize cid = _cid;
@synthesize dataObject = _dataObject;

@end
