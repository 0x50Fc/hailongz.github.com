//
//  QDDFollowsTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDFollowsTask<IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSArray * tuids;

@end

@interface QDDFollowsTask : VTUplinkTask<IQDDFollowsTask>

@end
