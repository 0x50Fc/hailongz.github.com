//
//  QDDMessageTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDMessageTask <IQDDAPITask,IVTUplinkTask>

@end

@interface QDDMessageTask : VTUplinkTask<IQDDMessageTask>

@end
