//
//  QDDConcernService.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDConcernService.h"

#import "QDDFollowTask.h"
#import "QDDUnFollowTask.h"

#import "QDDConcernTask.h"

#import "QDDConcernObject.h"

#import "QDDRefreshUserTask.h"

#import "QDDFollowsTask.h"

#import "QDDConcernTask.h"

#import "QDDUserGetTask.h"

@interface QDDConcernService()

@property(nonatomic,retain) id concernTask;
@property(nonatomic,readonly) NSMutableDictionary * concernCache;

@end

@implementation QDDConcernService

-(void) fillConcernObject:(QDDConcernObject *) dataObject data:(id) data{
    [dataObject setUid:[[data dataForKeyPath:@"uid"] longLongValue]];
    [dataObject setNick:[data dataForKeyPath:@"nick"]];
    [dataObject setLogo:[data dataForKeyPath:@"logo"]];
    [dataObject setPy:[dataObject.nick pinyinInitials]];
    [dataObject setMutual:[[data dataForKeyPath:@"mutual"] boolValue]];
}

-(NSMutableDictionary *) concernCache{
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
    
    NSMutableDictionary * cache = [dbContext valueForKey:@"concernCache"];
    
    if(cache == nil){
        cache = [NSMutableDictionary dictionaryWithCapacity:4];
        [dbContext setValue:cache forKey:@"concernCache"];
    }
    
    return cache;
}

-(void) didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
    
    [dbContext setValue:nil forKey:@"concernCache"];
    
}

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{

    if(taskType == @protocol(IQDDFollowTask)){
        
        id<IQDDFollowTask> followTask = (id<IQDDFollowTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDFollowTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[followTask tuid]] forKey:@"qdd-tuid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
    
        return YES;
    }
    else if(taskType == @protocol(IQDDFollowsTask)){
        
        id<IQDDFollowsTask> followTask = (id<IQDDFollowsTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDFollowsTask" forKey:@"taskType"];
        
        NSMutableString * uids = [NSMutableString stringWithCapacity:64];
        
        for(id uid in [followTask tuids]){
            
            if([uids length]){
                [uids appendFormat:@",%lld",[uid longLongValue]];
            }
            else{
                [uids appendFormat:@"%lld",[uid longLongValue]];
            }
        }
        
        [body addItemValue:uids forKey:@"qdd-tuids"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IQDDUnFollowTask)){
        
        id<IQDDUnFollowTask> followTask = (id<IQDDUnFollowTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDUnFollowTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[followTask tuid]] forKey:@"qdd-tuid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        

        return YES;
    }
    else if(taskType == @protocol(IQDDUserGetTask)){
        
        id<IQDDUserGetTask> userTask = (id<IQDDUserGetTask>)task;
        

        
        NSNumber * key = [NSNumber numberWithLongLong:[userTask uid]];
        
        QDDConcernObject * dataObject = [self.concernCache objectForKey:key];
        
        if(dataObject == nil){
            
            if([[(id<QDDContext>)self.context uid] longLongValue] == [userTask uid]){
                
                dataObject = [[QDDConcernObject alloc] init];
              
                dataObject.uid = [userTask uid];
                
                dataObject.nick = [(id<QDDContext>)self.context nick];
                
                dataObject.logo = [[(id<QDDContext>)self.context userInfo] valueForKey:@"logo"];
                
                [self.concernCache setObject:dataObject forKey:key];
                
            }
            else{
                VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                
                id<IVTSqliteCursor> cursor = [dbContext query:[QDDConcernObject tableClass] sql:[NSString stringWithFormat:@"WHERE uid=%lld",[userTask uid] ] data:nil];
                
                if([cursor next]){
                    
                    dataObject = [[QDDConcernObject alloc] init];
                    
                    [cursor toDataObject:dataObject];
                    
                    [self.concernCache setObject:dataObject forKey:key];
                    
                }
                
                [cursor close];
            }
        }
        
        [userTask setDataObject:dataObject];
        
        return YES;
    }
    else if(taskType == @protocol(IQDDConcernTask)){
        
        if(_concernTask){
            VTAPITask * t = [[VTAPITask alloc] init];
            [t setTask:_concernTask];
            [t setTaskType:@protocol(IQDDConcernTask)];
            [self.context cancelHandle:@protocol(IVTAPICancelTask) task:t];
            self.concernTask = nil;
        }
        
        id<IQDDConcernTask> concernTask = (id<IQDDConcernTask>) task;
        
        [concernTask setStatus:QDDConcernTaskStatusLoading];
        [concernTask setPageIndex:1];
        
        self.concernTask = concernTask;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDUserConcernTask" forKey:@"taskType"];
        
        long long version = [(id<QDDContext>)self.context concernVersion];
        
        if(version){
            [body addItemValue:[NSString stringWithFormat:@"%lld",version] forKey:@"qdd-version"];
        }
        
        [body addItemValue:[NSString stringWithFormat:@"%d",[concernTask pageIndex]] forKey:@"qdd-pageIndex"];
        
        [httpTask setBody:body];
        
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
    }
    else if(taskType == @protocol(IQDDRefreshUserTask)){
        
        id data = [(id<IQDDRefreshUserTask>)task data];
        
        long long uid = [[data dataForKeyPath:@"uid"] longLongValue];
        
        VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
     
        id<IVTSqliteCursor> cursor = [dbContext query:[QDDConcernObject tableClass] sql:[NSString stringWithFormat:@"WHERE uid=%lld",uid] data:nil];
        
        if([cursor next]){
            
            QDDConcernObject * dataObject = [[QDDConcernObject alloc] init];
            
            [self fillConcernObject:dataObject data:data];
            
            [dbContext updateObject:dataObject];
            
            [[self concernCache] setObject:dataObject forKey:[NSNumber numberWithLongLong:dataObject.uid]];
        }
        
        [cursor close];
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDFollowTask) || [respTask taskType] == @protocol(IQDDUnFollowTask) || [respTask taskType] == @protocol(IQDDFollowsTask) ){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                if([respTask taskType] == @protocol(IQDDUnFollowTask)){
                    
                    id<IQDDUnFollowTask> t = (id<IQDDUnFollowTask>) [respTask task];
                    
                    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                    
                    [dbContext.db execture:[NSString stringWithFormat:@"DELETE FROM [%@] WHERE uid=%lld",NSStringFromClass([QDDConcernObject tableClass]),[t tuid]] withData:nil];
                    
                }
                else if([respTask taskType] == @protocol(IQDDFollowTask)){
                    
                    [(id<QDDContext>)self.context setHasConcernChanged:YES];
                    
                }
                else if([respTask taskType] == @protocol(IQDDFollowsTask)){
                    
                    [(id<QDDContext>)self.context setHasConcernChanged:YES];
                    
                    [self.context handle:@protocol(IQDDConcernTask) task:[[QDDConcernTask alloc] init] priority:0];
                    
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
          
            
            return YES;
        }
        else if([respTask taskType] == @protocol(IQDDConcernTask)){
            
            id<IQDDConcernTask> concernTask = (id<IQDDConcernTask>)[respTask task];
            
            if(_concernTask == concernTask){
                self.concernTask = nil;
            }
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(!errorCode){
                
                id data = [[respTask resultsData] dataForKeyPath:@"user-concern-results"];
                
                if([data isKindOfClass:[NSDictionary class]]){
                    
                    long long version = [[data valueForKey:@"version"] intValue];
                    
                    if([(id<QDDContext>)self.context concernVersion] != version){
                        
                        VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                        
                        if([concernTask pageIndex] == 1){
                            [dbContext.db execture:[NSString stringWithFormat:@"DELETE FROM [%@]",NSStringFromClass([QDDConcernObject tableClass])] withData:nil];
                            
                            [dbContext setValue:nil forKey:@"concernCache"];
                        }
                        
                       
                        id items = [data valueForKey:@"items"];
                        
                        if(![items isKindOfClass:[NSArray class]]){
                            items = nil;
                        }
                        
                        for (id item in items) {
                            
                            QDDConcernObject * dataObject = [[QDDConcernObject alloc] init];
                            
                            [self fillConcernObject:dataObject data:item];
                            
                            [dataObject setVersion:version];
                            
                            
                            [dbContext insertObject:dataObject];
                            
                        }
                        
                        if([items count] == 0){
                            [(id<QDDContext>)self.context setConcernVersion:version];
                            [concernTask setStatus:QDDConcernTaskStatusNone];
                            [concernTask setPageIndex:0];
                        }
                        else{
                            
                            [concernTask setPageIndex:[concernTask pageIndex] + 1];
                            
                            VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
                            
                            [httpTask setTaskType:@protocol(IQDDConcernTask)];
                            [httpTask setTask:concernTask];
                            [httpTask setSource:[concernTask source]];
                            
                            [httpTask setApiKey:@"url"];
                            
                            VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
                            
                            [body addItemValue:@"config_qdd" forKey:@"config"];
                            [body addItemValue:@"QDDUserConcernTask" forKey:@"taskType"];
                            
                            long long version = [(id<QDDContext>)self.context concernVersion];
                            
                            if(version){
                                [body addItemValue:[NSString stringWithFormat:@"%lld",version] forKey:@"qdd-version"];
                            }
                            
                            [body addItemValue:[NSString stringWithFormat:@"%d",[concernTask pageIndex]] forKey:@"qdd-pageIndex"];
                            
                            [httpTask setBody:body];
                            
                            self.concernTask = concernTask;
                            
                            dispatch_async(dispatch_get_current_queue(), ^{
                               
                                [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
                                
                            });
                        }
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:QDDConcernChangedNotification object:nil];
                        
                    }
                    
                }
                
            }
          
            
            return YES;
        }
        
    }
    
    return NO;
}

-(BOOL) cancelHandle:(Protocol *)taskType task:(id<IVTTask>)task{
    
    if(taskType == @protocol(IQDDConcernTask)){
        
        if(task){
            VTAPITask * t = [[VTAPITask alloc] init];
            
            [t setTask:task];
            [t setTaskType:taskType];
            
            [self.context cancelHandle:@protocol(IVTAPICancelTask) task:t];
            
            if(task == _concernTask){
                self.concernTask = nil;
            }
        }
        else if(_concernTask){
            
            VTAPITask * t = [[VTAPITask alloc] init];
            
            [t setTask:_concernTask];
            [t setTaskType:taskType];
            
            [self.context cancelHandle:@protocol(IVTAPICancelTask) task:t];
            
            self.concernTask = nil;
        }
    }
    
    return NO;
}

-(BOOL) cancelHandleForSource:(id)source{
    
    if([_concernTask source] == source){
        

        self.concernTask = nil;
    }
    
    return NO;
}

@end
