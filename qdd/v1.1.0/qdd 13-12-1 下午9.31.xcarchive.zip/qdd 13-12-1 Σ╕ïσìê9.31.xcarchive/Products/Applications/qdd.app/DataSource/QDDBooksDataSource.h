//
//  QDDBooksDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-11-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDBooksDataSource : VTDataSource<IVTUplinkTaskDelegate>

@property(nonatomic,retain) NSDate * date;
@property(nonatomic,assign) double expendMoney;

@end
