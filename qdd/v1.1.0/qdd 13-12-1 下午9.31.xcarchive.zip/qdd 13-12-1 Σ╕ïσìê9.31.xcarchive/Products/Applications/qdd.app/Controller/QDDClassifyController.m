//
//  QDDClassifyController.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDClassifyController.h"

#import "QDDClassifyObject.h"
#import "QDDTagObject.h"

@interface QDDClassifyItemControl : UIButton

@property(nonatomic,retain) QDDClassifyObject * dataObject;

@end

@implementation QDDClassifyItemControl


@end

@interface QDDClassifyController()

@end

@implementation QDDClassifyController

- (IBAction)doPageChangedAction:(id)sender {
    
}

-(void) scrollViewDidScroll:(UIScrollView *)scrollView{
    
    [_pageControl setCurrentPage:scrollView.contentOffset.x / scrollView.bounds.size.width];
    
}

-(void) reloadData{
    
    NSMutableArray * itemViews = [NSMutableArray arrayWithCapacity:4];
    
    for(UIView * itemView in [_contentView subviews]){
        if([itemView isKindOfClass:[QDDClassifyItemControl class]]){
            [itemViews addObject:itemView];
        }
    }
    
    CGSize size = _contentView.bounds.size;
    
    CGSize innerSize = CGSizeMake(size.width - _padding.left - _padding.right, size.height - _padding.top - _padding.bottom);
    
    
    NSInteger index = 0;
    NSInteger pageSize = (int) (innerSize.width / _itemSize.width);
    CGFloat offset = innerSize.width - pageSize * _itemSize.width;
    CGFloat paddingLeft = _padding.left + offset / 2.0;
    NSInteger pageIndex = index / pageSize;
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context appDBContext];
    
    id<IVTSqliteCursor> cursor = [dbContext query:[QDDClassifyObject tableClass] sql:@"" data:nil];
    
    UIColor * highColor = [UIColor colorWithRed:240.0 / 255.0 green:161.0 / 255.0 blue:141.0 / 255.0 alpha:1.0];
    UIColor * lowColor = [UIColor whiteColor];
    
    QDDClassifyItemControl * firstItem = nil;
    
    while([cursor next]){
        
        pageIndex = index / pageSize;
        
        NSInteger i = index % pageSize;
        
        QDDClassifyObject * dataObject = [[QDDClassifyObject alloc] init];
        
        [cursor toDataObject:dataObject];
        
        QDDClassifyItemControl * itemView = index < [itemViews count] ? [itemViews objectAtIndex:index] : nil;
        
        CGRect r = CGRectMake(paddingLeft + pageIndex * size.width + i * _itemSize.width
                              , (size.height - _itemSize.height - _itemPadding.bottom - _itemPadding.top) / 2.0 + _itemPadding.top
                              , _itemSize.width - _itemPadding.left - _itemPadding.right
                              , _itemSize.height - _itemPadding.top - _itemPadding.bottom);
        
        if(itemView == nil){
            itemView = [[QDDClassifyItemControl alloc] initWithFrame:r];
            itemView.layer.cornerRadius = r.size.width / 2.0;
            itemView.layer.borderColor = highColor.CGColor;
            itemView.layer.borderWidth = 1;
            itemView.layer.masksToBounds = YES;
            
            [itemView setBackgroundColor:lowColor];
            [itemView setBackgroundImage:[UIImage imageNamed:@"btn4.png"] forState:UIControlStateSelected];
            [itemView setBackgroundImage:[UIImage imageNamed:@"btn4.png"] forState:UIControlStateHighlighted];
        
            [itemView.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
            [itemView.titleLabel setMinimumFontSize:9];
            [itemView.titleLabel setNumberOfLines:0];
            
            [itemView setTitleColor:highColor forState:UIControlStateNormal];
            [itemView setTitleColor:lowColor forState:UIControlStateHighlighted];
            [itemView setTitleColor:lowColor forState:UIControlStateSelected];
            
            [itemView setEnabled:YES];
            
            [itemView addTarget:self action:@selector(itemViewAction:) forControlEvents:UIControlEventTouchUpInside];
            
            [_contentView addSubview:itemView];
        }
        else{
            [itemView setFrame:r];
        }
        
        if(firstItem == nil){
            firstItem = itemView;
        }
        
        [itemView setDataObject:dataObject];
        
        [itemView setTitle:dataObject.title forState:UIControlStateNormal];

        index ++;
    }
    
    [cursor close];
    
    pageIndex = index % pageSize == 0 ? index / pageSize : index / pageSize + 1;
    
    [_contentView setContentSize:CGSizeMake(pageIndex * size.width, 0)];
    [_pageControl setNumberOfPages:pageIndex];
    [_pageControl setCurrentPage:[_contentView contentOffset].x / size.width];
    
    while (index < [itemViews count]) {
        
        [[itemViews objectAtIndex:index] removeFromSuperview];
        
        index ++;
    }
    
    
}

-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    
    [self reloadData];
}


-(void) itemViewAction:(QDDClassifyItemControl *) itemView{
    
    [itemView setSelected:![itemView isSelected]];

}

-(NSArray *) selectedClassifyObjects{
    
    NSMutableArray * classifyObjects = [NSMutableArray arrayWithCapacity:4];
    
    for(QDDClassifyItemControl * itemView in [_contentView subviews]){
        if([itemView isKindOfClass:[QDDClassifyItemControl class]]){
            
            if([itemView isSelected]){
                [classifyObjects addObject:itemView.dataObject];
            }
        }
    }
    
    return classifyObjects;
    
}

@end
