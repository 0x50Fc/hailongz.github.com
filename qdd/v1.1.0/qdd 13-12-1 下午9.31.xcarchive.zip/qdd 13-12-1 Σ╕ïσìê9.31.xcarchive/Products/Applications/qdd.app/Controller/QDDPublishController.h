//
//  QDDPublishController.h
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "QDDClassifyController.h"
#import "QDDTagController.h"
#import "QDDKeyboardView.h"

@interface QDDPublishController : VTController<VTKeyboardControllerDelegate,UITextViewDelegate,UIActionSheetDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,IVTUplinkTaskDelegate,UITextFieldDelegate,QDDKeyboardViewDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *contentView;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;
@property (strong, nonatomic) IBOutlet VTKeyboardController *keyboardController;
@property (strong, nonatomic) IBOutlet UITextView *bodyTextView;
@property (strong, nonatomic) IBOutletCollection(VTImageView) NSArray * imageViews;
@property (strong,nonatomic) IBOutlet QDDClassifyController * classifyController;
@property (strong, nonatomic) IBOutlet UITextField *payMoneyField;
@property (strong, nonatomic) IBOutlet UITextField *expendMoneyField;
@property (strong, nonatomic) IBOutlet QDDKeyboardView * keyboardView;
@property (strong, nonatomic) IBOutlet QDDTagController * tagController;
@property (strong, nonatomic) IBOutlet UIButton * weiboButton;
@property (strong, nonatomic) IBOutlet UIButton * qqButton;
@property (strong, nonatomic) IBOutlet UIButton * weixinButton;

-(IBAction) imageAction:(id)sender;

- (IBAction)publishAction:(id)sender;

-(IBAction) doWeiboAction:(id)sender;

-(IBAction) doQQAction:(id)sender;

-(IBAction) doWeixinAction:(id)sender;

@end


@protocol QDDPublishControllerDelegate

@optional

-(void) publishController:(QDDPublishController *) controller didFailWithError:(NSError *) error;

-(void) publishController:(QDDPublishController *) controller didSuccessResults:(id) results;

@end