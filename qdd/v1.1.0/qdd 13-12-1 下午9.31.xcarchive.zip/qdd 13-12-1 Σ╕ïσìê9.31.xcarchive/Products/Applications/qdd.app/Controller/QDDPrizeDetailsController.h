//
//  QDDPrizeDetailsController.h
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDPrizeDetailsController : VTDocumentController<VTDataSourceDelegate>

@property(nonatomic,retain) IBOutlet id dataSource;
@property(nonatomic,retain) IBOutlet VTStatusView * statusView;

-(void) cancel;

@end

@protocol QDDPrizeDetailsControllerDelegate <VTDocumentControllerDelegate>

@optional

-(void) prizeDetailsControllerDidContentChanged:(QDDPrizeDetailsController *) detailsController;

@end