//
//  QDDPrizeSearchController.m
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeSearchController.h"

@implementation QDDPrizeSearchController

-(VTItemViewController *) vtContainerView:(VTContainerView *)containerView itemViewAtIndex:(NSInteger)index frame:(CGRect)frame{
    
    if(index == 0){
        self.itemViewNib = @"QDDPrizeItemViewController";
    }
    else {
        self.itemViewNib = @"QDDPrizeItemViewController2";
    }
    
    VTItemViewController * itemViewController = [super vtContainerView:containerView itemViewAtIndex:index frame:frame];
    
    return itemViewController;
}

-(CGSize) vtContainerLayout:(VTContainerLayout *)containerLayout itemSizeAtIndex:(NSInteger)index{
    
    if(index == 0){
        return CGSizeMake(containerLayout.size.width, 214);
    }
    
    return CGSizeMake(containerLayout.size.width / 2.0, 120);
}

@end
