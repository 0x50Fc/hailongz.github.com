//
//  QDDFeedDocumentController.m
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFeedDocumentController.h"

#import "QDDUnLikeTask.h"
#import "QDDLikeTask.h"

#import "QDDClassifyGetTask.h"

@interface QDDFeedDocumentController()

@property(nonatomic,retain) NSString * likeUserHTMLContent;

@end

@implementation QDDFeedDocumentController

@synthesize likeUserHTMLContent = _likeUserHTMLContent;

+(void) document:(VTDOMDocument *) document willLoadDataObject:(id)dataObject context:(id) context{
    
    VTDOMElement * element = [document elementById:@"images"];
    
    if(element && [element valueForKey:@"images"] == nil){
        
        [element setValue:[dataObject dataForKeyPath:@"images"] forKey:@"images"];
        
    }
    
    element = [document elementById:@"tags"];
    
    if(element){
        
        NSInteger index = 0;
        
        id cids = [dataObject dataForKeyPath:@"cids"];
        
        QDDClassifyGetTask * t = [[QDDClassifyGetTask alloc] init];
        
        for (id cid in cids) {
            
            [t setCid:[cid longLongValue]];
            
            [context handle:@protocol(IQDDClassifyGetTask) task:t priority:0];
            
            QDDClassifyObject * dataObject  = [t dataObject];
            
            if(dataObject){
                
                VTDOMImageElement * image = [[VTDOMImageElement alloc] init];
                
                [image setSrc:@"ico33.png"];
                [image setAttributeValue:@"auto" forKey:@"width"];
                [image setAttributeValue:@"auto" forKey:@"height"];
                [image setAttributeValue:@"tag-image" forKey:@"class"];
                
                [element addElement:image];
                
                VTDOMLabelElement * label = [[VTDOMLabelElement alloc] init];
                
                [label setText:dataObject.title];
                [label setAttributeValue:@"auto" forKey:@"width"];
                [label setAttributeValue:@"auto" forKey:@"height"];
                [label setAttributeValue:@"tag-label" forKey:@"class"];
                
                [element addElement:label];
                
                index ++;
                
                if(index >=6){
                    break;
                }

            }
            
        }
        
        if(index < 6){
            
            id tags = [dataObject dataForKeyPath:@"tags"];
            
            for (id tag in tags) {
                
                NSString * text = [tag isKindOfClass:[NSString class]] ? tag : [tag dataForKeyPath:@"tag"];
                
                VTDOMImageElement * image = [[VTDOMImageElement alloc] init];
                
                [image setSrc:@"ico33.png"];
                [image setAttributeValue:@"auto" forKey:@"width"];
                [image setAttributeValue:@"auto" forKey:@"height"];
                [image setAttributeValue:@"tag-image" forKey:@"class"];
                
                [element addElement:image];
                
                VTDOMLabelElement * label = [[VTDOMLabelElement alloc] init];
                
                [label setText:text];
                [label setAttributeValue:@"auto" forKey:@"width"];
                [label setAttributeValue:@"auto" forKey:@"height"];
                [label setAttributeValue:@"tag-label" forKey:@"class"];
                
                [element addElement:label];
                
                index ++;
                
                if(index >=6){
                    break;
                }
            }
        
        }
        
        if([[element childs] count] == 0){
            [element setAttributeValue:@"0" forKey:@"height"];
        }
    }
    
    element = [document elementById:@"liked-img"];
    
    if(element){
        
        if([[dataObject valueForKey:@"liked"] boolValue]){
            [element setAttributeValue:@"ico40.png" forKey:@"src"];
        }
        else{
            [element setAttributeValue:@"ico36.png" forKey:@"src"];
        }
    }
    
    element = [document elementById:@"money"];
    
    if(element ){
        
        double payMoney = [[dataObject dataForKeyPath:@"payMoney"] doubleValue];
        double expendMoney = [[dataObject dataForKeyPath:@"expendMoney"] doubleValue];
        
        if(payMoney){
            
            VTDOMLabelElement * label = [[VTDOMLabelElement alloc] init];
            
            [label setText:@"省¥"];
            [label setAttributeValue:@"auto" forKey:@"width"];
            [label setAttributeValue:@"auto" forKey:@"height"];
            [label setAttributeValue:@"money-title" forKey:@"class"];
            
            [element addElement:label];
            
            label = [[VTDOMLabelElement alloc] init];
            
            NSNumberFormatter *numFormat = [[NSNumberFormatter alloc] init];
            
            [numFormat setPositiveFormat:@"###,##0.##"];
            
            [label setText:[numFormat stringFromNumber:[NSNumber numberWithDouble:payMoney - expendMoney]]];
            [label setAttributeValue:@"auto" forKey:@"width"];
            [label setAttributeValue:@"auto" forKey:@"height"];
            [label setAttributeValue:@"money-number" forKey:@"class"];
            
            [element addElement:label];
            
        }
        
    }

    
}

+(void) document:(VTDOMDocument *) document setLiked:(BOOL) liked dataItem:(id) dataItem context:(id) context{
    
    VTDOMElement * element = [document elementById:@"liked-img"];
    
    if(element){
        
        if(liked){
            [element performSelector:@selector(setSrc:) withObject:@"ico40.png"];
        }
        else{
            [element performSelector:@selector(setSrc:) withObject:@"ico36.png"];
        }
        
        [context handle:@protocol(IVTLocalImageTask) task:(id<IVTLocalImageTask>)element priority:0];
        
        [element setNeedDisplay];
    }
    
    element = [document elementById:@"liked-label"];
    
    if(element){
        
        [element setText:[NSString stringWithFormat:@"%@",[dataItem valueForKey:@"likedCount"]]];
        
        [element setNeedDisplay];
    }

}

+(void) documentUpdateCommentCount:(VTDOMDocument *) document dataItem:(id) dataItem{
    
    VTDOMElement * element = [document elementById:@"comment-label"];
    
    if(element){
        
        [element setText:[NSString stringWithFormat:@"%@",[dataItem valueForKey:@"commentCount"]]];
        
        [element setNeedDisplay];
    }

}


-(id) init{
    if((self = [super init])){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(likeChangedAction:) name:QDDLikeChangedNotification object:nil];
        
    }
    return self;
}

-(void) dealloc{
    
    [_topLikeDataSource setDelegate:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDLikeChangedNotification object:nil];
    
}

-(void) likeChangedAction:(NSNotification *) notification{
    
    if(![_topLikeDataSource isLoading]){
        [_topLikeDataSource reloadData];
    }
}

-(void) documentWillLoad{
    [super documentWillLoad];
    
    [QDDFeedDocumentController document:self.document willLoadDataObject:self.dataItem context:self.context];
    
}

-(void) onActionElement:(VTDOMElement *) element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"like"]){
    
        BOOL liked = [[self.dataItem valueForKey:@"liked"] boolValue];
        
        if(liked){
            
            QDDUnLikeTask * task = [[QDDUnLikeTask alloc] init];
            
            [task setPid:[[self.dataItem valueForKey:@"pid"] longLongValue]];
            
            [self.context handle:@protocol(IQDDUnLikeTask) task:task priority:0];
            
            [self.dataItem setValue:[NSNumber numberWithInt:[[self.dataItem valueForKey:@"likedCount"] intValue] -1] forKey:@"likedCount"];
            
            
        }
        else{
            
            QDDLikeTask * task = [[QDDLikeTask alloc] init];
            
            [task setPid:[[self.dataItem valueForKey:@"pid"] longLongValue]];
            
            [self.context handle:@protocol(IQDDLikeTask) task:task priority:0];
            
            [self.dataItem setValue:[NSNumber numberWithInt:[[self.dataItem valueForKey:@"likedCount"] intValue] +1] forKey:@"likedCount"];
        }
        
        [self.dataItem setValue:[NSNumber numberWithBool:!liked] forKey:@"liked"];
        
        [QDDFeedDocumentController document:self.document setLiked:!liked dataItem:self.dataItem context:self.context];
        
    }
    [super onActionElement:element];
}

-(void) reloadLikeContent{
 
    VTDOMElement * likeContent = [self.document elementById:@"likeContent"];
    VTDOMElement * likeUserContent = [self.document elementById:@"likeUserContent"];
    
    if(likeContent && likeUserContent){
        
        if([self.topLikeDataSource count] == 0){
            [likeContent setAttributeValue:@"0" forKey:@"height"];
        }
        else {
            
            for (VTDOMElement * el in [NSArray arrayWithArray:[likeUserContent childs]]) {
                [el removeFromParentElement];
            }
            
            VTDOMParse * parse = [[VTDOMParse alloc] init];
            
            NSInteger index = 0;
            
            for(id dataItem in [_topLikeDataSource dataObjects]){
                
                [parse parseHTML:[self.likeUserHTMLContent htmlStringByDOMSource:dataItem] toElement:likeUserContent];
                
                index ++;
                if(index ==5){
                    break;
                }
            }
        
            
            [likeContent setAttributeValue:@"62" forKey:@"height"];
        }
        
        if([self.delegate respondsToSelector:@selector(feedDocumentControllerDidContentSizeChanged:)]){
            [self.delegate feedDocumentControllerDidContentSizeChanged:self];
        }
    }
    
}

-(void) vtDataSourceWillLoading:(VTDataSource *) dataSource{
    if(_topLikeDataSource == dataSource){
        
    }
}

-(void) vtDataSourceDidLoadedFromCache:(VTDataSource *) dataSource timestamp:(NSDate *) timestamp{
    if(_topLikeDataSource == dataSource){
        
        [self reloadLikeContent];
    }
}

-(void) vtDataSourceDidLoaded:(VTDataSource *) dataSource{
    if(_topLikeDataSource == dataSource){
        
        [self reloadLikeContent];
    }
}

-(void) vtDataSource:(VTDataSource *) dataSource didFitalError:(NSError *) error{
    if(_topLikeDataSource == dataSource){
        
    }
}

-(void) vtDataSourceDidContentChanged:(VTDataSource *) dataSource{
    if(_topLikeDataSource == dataSource){
        
        [self reloadLikeContent];
    }
}

-(void) reloadData{
    [super reloadData];
    
    [self.topLikeDataSource reloadData];
}

-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    [_topLikeDataSource setContext:context];
}

-(NSString *) likeUserHTMLContent{
    if(_likeUserHTMLContent == nil){
        _likeUserHTMLContent = [[NSString alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"like_user" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    }
    return _likeUserHTMLContent;
}

-(void) addCommentCount{
    [self.dataItem setValue:[NSNumber numberWithInt:[[self.dataItem valueForKey:@"commentCount"] intValue] +1 ] forKey:@"commentCount"];
    [QDDFeedDocumentController documentUpdateCommentCount:self.document dataItem:self.dataItem];
}

@end
