//
//  QDDBooksEditController.m
//  qdd
//
//  Created by zhang hailong on 13-11-16.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksEditController.h"

#import "QDDBooksCreateTask.h"

@interface QDDBooksEditController(){
    
}

@property(nonatomic,assign) CGRect focusRect;

@end

@implementation QDDBooksEditController

@synthesize focusRect = _focusRect;

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
    
    if(_moneyField == textField){
        _moneyField.inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
        [_moneyField reloadInputViews];
        _keyboardView.keyInput = _moneyField;
    }
    
    return YES;
}

-(void) textFieldDidBeginEditing:(UITextField *)textField{
    
    if(textField == _remarkField){
        self.focusRect = [_contentView convertRect:textField.frame fromView:textField.superview];
    }
    
}

-(BOOL) keyboardView:(QDDKeyboardView *)keyboardView inputKey:(NSString *)key{
    
    if(_keyboardView.keyInput == nil){
        _keyboardView.keyInput = _moneyField;
    }
    
    if(![_moneyField isFirstResponder]){
        [_moneyField becomeFirstResponder];
    }
    
    if([key isEqualToString:@"ok"]){
        [_moneyField resignFirstResponder];
        return NO;
    }
    else if([key isEqualToString:@"<-"]){
        [[keyboardView keyInput] deleteBackward];
        return NO;
    }
    else if([key isEqualToString:@"clear"]){
        [(UITextField *)[keyboardView keyInput] setText:@""];
        return NO;
    }
    
    return YES;
}



-(void) dealloc{
    
    [_keyboardView setDelegate:nil];
    [_keyboardView setKeyInput:nil];
    
}

-(void) visableKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - frame.size.height - r.origin.y)];
        
    } completion:^(BOOL finished) {
        
        if(!CGRectEqualToRect(_focusRect, CGRectZero)){
            
            [_contentView setContentOffset:CGPointMake(0, _contentView.contentSize.height - _contentView.bounds.size.height - _focusRect.size.height) animated:YES];
            
            
            _focusRect = CGRectZero;
        }
        
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - r.origin.y)];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}


-(IBAction) doSubmitAction:(id)sender{
    
    double expendMoney = [[_moneyField text] doubleValue];
    
    if(expendMoney == 0.0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入金额" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        
        return;
    }
    
    [_statusView setStatus:@"loading"];
    [_statusView setUserInteractionEnabled:NO];

    
    QDDBooksCreateTask * task = [[QDDBooksCreateTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setPayMoney:expendMoney];
    [task setExpendMoney:expendMoney];
    [task setRemark:_remarkField.text];
    [task setClassifyObjects:_classifyController.selectedClassifyObjects];
    
    CLLocation * location = [(id<QDDContext>)self.context location];
    
    [task setLatitude:location.coordinate.latitude];
    [task setLongitude:location.coordinate.longitude];
    
    [self.context handle:@protocol(IQDDBooksCreateTask) task:task priority:0];
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDBooksCreateTask)){
        
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
        
        if([self.delegate respondsToSelector:@selector(booksEditController:didFailWithError:)]){
            [self.delegate booksEditController:self didFailWithError:error];
        }
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDBooksCreateTask)){
        
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
        
        if([self.delegate respondsToSelector:@selector(booksEditController:didSuccessResults:)]){
            [self.delegate booksEditController:self didSuccessResults:results];
        }

        
    }
    
}

@end
