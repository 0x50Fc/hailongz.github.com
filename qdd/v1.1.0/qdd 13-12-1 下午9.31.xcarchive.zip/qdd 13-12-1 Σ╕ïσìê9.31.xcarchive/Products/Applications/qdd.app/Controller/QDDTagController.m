//
//  QDDTagController.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDTagController.h"

#import "QDDTagObject.h"

@interface QDDTagItemControl : UIButton

@property(nonatomic,retain) QDDTagObject * dataObject;

@end

@implementation QDDTagItemControl


@end

@interface QDDTagController()

-(void) reloadData;

@end


@implementation QDDTagController

-(void) reloadData{
 
    NSMutableArray * itemViews = [NSMutableArray arrayWithCapacity:4];
    
    for(UIView * itemView in [_contentView subviews]){
        if([itemView isKindOfClass:[QDDTagItemControl class]]){
            [itemViews addObject:itemView];
        }
    }
    
    NSInteger index = 0;
    
    CGSize size = _contentView.bounds.size;
    
    CGSize itemSize = CGSizeMake(0, 24);
    CGPoint p = CGPointMake(0, (size.height - itemSize.height) / 2.0);
    
    
    UIFont * titleFont = [UIFont systemFontOfSize:12];
    
    UIColor * highColor = [UIColor colorWithRed:240.0 / 255.0 green:161.0 / 255.0 blue:141.0 / 255.0 alpha:1.0];
    UIColor * focusColor = [UIColor colorWithRed:241.0 / 255.0 green:97.0 / 255.0 blue:60.0 / 255.0 alpha:1.0];
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context appDBContext];
    
    id<IVTSqliteCursor> cursor = [dbContext query:[QDDTagObject tableClass] sql:@"" data:nil];
  
    while([cursor next]){
    
        QDDTagObject * dataObject  = [[QDDTagObject alloc] init];
    
        [cursor toDataObject:dataObject];
    
        NSString * title = [dataObject tag];
        
        itemSize = [title sizeWithFont:titleFont];
        
        itemSize.width += 40;
        itemSize.height = 24;
        
        CGRect r = CGRectMake(p.x, p.y, itemSize.width, itemSize.height);
        
        QDDTagItemControl * itemView = index < [itemViews count] ? [itemViews objectAtIndex:index] : nil;
        
        if(itemView == nil){
            
            itemView = [[QDDTagItemControl alloc] initWithFrame:r];
            [itemView.titleLabel setFont:titleFont];
            [itemView setTitleColor:highColor forState:UIControlStateNormal];
            [itemView setTitleColor:focusColor forState:UIControlStateHighlighted];
            [itemView setTitleColor:focusColor forState:UIControlStateSelected];
            [itemView setImage:[UIImage imageNamed:@"ico33.png"] forState:UIControlStateNormal];
            [itemView setImage:[UIImage imageNamed:@"ico34.png"] forState:UIControlStateHighlighted];
            [itemView setImage:[UIImage imageNamed:@"ico34.png"] forState:UIControlStateSelected];
            [itemView setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 5)];
            
            [itemView addTarget:self action:@selector(itemViewAction:) forControlEvents:UIControlEventTouchUpInside];
            
            [_contentView addSubview:itemView];
        }
        else{
            [itemView setFrame:r];
        }
        
        [itemView setTitle:title forState:UIControlStateNormal];
        [itemView setDataObject:dataObject];
        
        p.x += itemSize.width;
        
        index ++;
    }
    
    while(index < [itemViews count]){
        [[itemViews objectAtIndex:index] removeFromSuperview];
        index ++;
    }
    
    [_contentView setContentSize:CGSizeMake(p.x, 0)];
    
}

-(NSArray *) selectedDataObjects{
    
    NSMutableArray * tagDataObjects = [NSMutableArray arrayWithCapacity:4];
    
    for(QDDTagItemControl * itemView in [_contentView subviews]){
        
        if([itemView isKindOfClass:[QDDTagItemControl class]]){
            if([itemView isSelected]){
                [tagDataObjects addObject:itemView.dataObject];
            }
        }
    }
    
    return tagDataObjects;

}

-(void) itemViewAction:(id) itemView{
    
    [itemView setSelected:![itemView isSelected]];
    
}

-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    
    [self reloadData];
}


@end
