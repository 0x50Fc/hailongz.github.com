//
//  QDDSessionViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDSessionViewController.h"

#import "QDDMessageSendTask.h"

@interface QDDSessionViewController ()

@end

@implementation QDDSessionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    NSDictionary * queryValues = [self.url queryValues];
    
    NSString * nick = [queryValues valueForKey:@"nick"];
    
    if(nick){
        self.title = nick;
    }
    else{
        self.title = @"会话";
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UITapGestureRecognizer * tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureRecognizerAction:)];
    
    [tapGestureRecognizer setNumberOfTapsRequired:1];
    [tapGestureRecognizer setNumberOfTouchesRequired:1];
    
    [self.view addGestureRecognizer:tapGestureRecognizer];
    
    [_sessionController.dataSource setValue:[queryValues valueForKey:@"uid"] forKey:@"sessionId"];
    
    [_sessionController reloadData];
}

-(void) tapGestureRecognizerAction:(UITapGestureRecognizer *)tapGestureRecognizer{
    [_bodyField resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doSendAction:(id)sender {
    
    NSString * body = [[_bodyField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([body length]){
        
       
        NSDictionary * queryValues = [self.url queryValues];
        
        id uid = [queryValues valueForKey:@"uid"];
        
        if(uid){
            
            [_statusView setStatus:@"sending"];
            [_statusView setUserInteractionEnabled:NO];
            
            QDDMessageSendTask * task = [[QDDMessageSendTask alloc] init];
            
            [task setUid:[uid longLongValue]];
            [task setBody:body];
            [task setSource:self];
            [task setDelegate:self];
            
            [self.context handle:@protocol(IQDDMessageSendTask) task:task priority:0];
            
        }
        
    }
    
    [_bodyField resignFirstResponder];
}

- (IBAction)doUserAction:(id)sender {
    
    [self openUrl:[NSURL URLWithString:@"session/user-details" relativeToURL:self.url queryValues:self.url.queryValues] animated:YES];
    
}


-(void) visableKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - frame.size.height - r.origin.y)];
        
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - r.origin.y)];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(IBAction) doCancelInputAction:(id)sender{
    
    [_bodyField resignFirstResponder];
       
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDMessageSendTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
    }
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDMessageSendTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        [_bodyField setText:@""];
        
    }
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [self doSendAction:textField];
    
    return YES;
}


@end
