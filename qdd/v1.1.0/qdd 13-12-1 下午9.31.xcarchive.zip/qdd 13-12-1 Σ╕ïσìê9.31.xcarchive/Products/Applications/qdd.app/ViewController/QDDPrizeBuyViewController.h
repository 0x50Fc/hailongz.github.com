//
//  QDDPrizeBuyViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDPrizeBuyViewController : QDDViewController<VTKeyboardControllerDelegate,UITextFieldDelegate,IVTUplinkTaskDelegate,UIAlertViewDelegate>

@property(nonatomic,retain) id dataItem;
@property (strong, nonatomic) IBOutlet UIScrollView *contentView;
@property (strong, nonatomic) IBOutlet UITextField *addressField;
@property (strong, nonatomic) IBOutlet UITextField *postCodeField;
@property (strong, nonatomic) IBOutlet UITextField *nameField;
@property (strong, nonatomic) IBOutlet UITextField *phoneField;
@property (strong, nonatomic) IBOutlet UITextField *otherField;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;

-(IBAction) doCancelInputAction:(id)sender;

-(IBAction) doSubmitAction:(id)sender;

@end
