//
//  QDDInviteViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-25.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDInviteViewController : QDDViewController<UITextFieldDelegate,VTDocumentDataControllerDelegate>

@property (strong, nonatomic) IBOutlet UITextField *textField;

@property (strong, nonatomic) IBOutlet VTDocumentDataController *dataController;
@property (strong, nonatomic) IBOutlet UIView *contentView;

-(IBAction) doSearchAction:(id)sender;

@end
