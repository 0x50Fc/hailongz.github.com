//
//  QDDPrizeBuyViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeBuyViewController.h"

#import "QDDPrizeBuyTask.h"

#import "QDDCoinTask.h"

@interface QDDPrizeBuyViewController ()

@end

@implementation QDDPrizeBuyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [self.context handle:@protocol(IQDDCoinTask) task:[[QDDCoinTask alloc] init] priority:0];
    
    self.dataItem = [self.context focusValueForKey:@"prize"];
    
    long long coin = [(id<QDDContext>)self.context integral] - [[_dataItem valueForKey:@"salePrice"] longLongValue];
    
    if(coin <0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"您的积分不足，无法兑换奖品" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView setTag:100];
        [alertView show];
        
    }
    
    [_dataItem setValue:[NSNumber numberWithLongLong:coin] forKey:@"coin"];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self downloadImagesForView:self.view];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) visableKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - frame.size.height - r.origin.y)];
        
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, r.origin.y
                                          , r.size.width, size.height - r.origin.y)];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(IBAction) doCancelInputAction:(id)sender{
    
    [_addressField resignFirstResponder];
    [_postCodeField resignFirstResponder];
    [_nameField resignFirstResponder];
    [_phoneField resignFirstResponder];
    [_otherField resignFirstResponder];
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(_addressField == textField){
        [_postCodeField becomeFirstResponder];
    }
    else if(_postCodeField == textField){
        [_nameField becomeFirstResponder];
    }
    else if(_nameField == textField){
        [_phoneField becomeFirstResponder];
    }
    else if(_phoneField == textField){
        [_otherField becomeFirstResponder];
    }
    else if(_otherField ==textField){
        [_otherField resignFirstResponder];
    }
    
    return YES;
}

-(void) delayScrollToTop:(UITextField *) textField{
    
    CGRect r = [_contentView convertRect:[textField frame] fromView:textField.superview];
    
    CGFloat top = r.origin.y + r.size.height + 60 - _contentView.bounds.size.height;
    
    if(top <0){
        top = 0;
    }
    
    [_contentView setContentOffset:CGPointMake(0, top) animated:YES];
}

-(void) textFieldDidBeginEditing:(UITextField *)textField{
    
    [self performSelector:@selector(delayScrollToTop:) withObject:textField afterDelay:0.1];
}

-(void) textFieldDidEndEditing:(UITextField *)textField{
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayScrollToTop:) object:textField];
    
}

-(IBAction) doSubmitAction:(id)sender{
    
    [self doCancelInputAction:sender];
    
    NSString * address = [[_addressField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * postCode =[[_postCodeField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * name = [[_nameField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * phone = [[_phoneField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * other = [[_otherField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([address length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入收货地址" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if([postCode length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入邮编" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if([name length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入收货人" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if([phone length] == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入电话" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDPrizeBuyTask * task = [[QDDPrizeBuyTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setProductId:[[self.dataItem valueForKey:@"pid"] longLongValue]];
    [task setAddress:address];
    [task setPostCode:postCode];
    [task setName:name];
    [task setPhone:phone];
    [task setOther:other];
    
    [self.context handle:@protocol(IQDDPrizeBuyTask) task:task priority:0];
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDPrizeBuyTask)){
        
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        
        [alertView show];
        
        if([error code] == QDD_ERROR_PRIZE_PURCHASED){
            [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
        }
        
    }
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDPrizeBuyTask)){
        
        VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"成功兑换奖品"];
        
        [alertView showDuration:1.2];
        
        [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
    }
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag == 100){
        [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
    }
}

@end
