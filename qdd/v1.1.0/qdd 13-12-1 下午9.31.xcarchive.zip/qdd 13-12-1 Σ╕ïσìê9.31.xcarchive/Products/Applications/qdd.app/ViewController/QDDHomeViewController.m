//
//  QDDHomeViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-4.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDHomeViewController.h"

@interface QDDHomeViewController ()

    @property(nonatomic,readonly,getter = isClassifyViewAnimating) BOOL classifyViewAnimating;
    
    -(void) visableClassifyView:(BOOL) animated;
    
    -(void) hiddenClassifyView:(BOOL) animated;
    
@end

@implementation QDDHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [self.dataOutletContainer setStatus:self.classify];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}
    
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_feedController.dataSource isLoaded] && ![_feedController.dataSource isLoading]){
        [_feedController reloadData];
    }
    else{
        [_feedController.tableView reloadData];
    }
}

- (IBAction)doClassifyHiddenAction:(id)sender {
    [self hiddenClassifyView:YES];
}
    
- (IBAction)doClassifyChangeAction:(id)sender {
    
    if(_classifyViewAnimating){
        return;
    }
    
    if([_classifyView isHidden]){
        [self visableClassifyView:YES];
    }
    else{
        [self hiddenClassifyView:YES];
    }
}
    
-(void) visableClassifyView:(BOOL) animated{
    
    if(_classifyViewAnimating){
        return;
    }
    
    [_classifyButton setSelected:YES];
    [_classifyButton setImage:[UIImage imageNamed:@"ico11.png"] forState:UIControlStateNormal];
    
    for(NSObject * ctl in _classifyEnabledViews){
        if([ctl respondsToSelector:@selector(setEnabled:)]){
            [(UIControl *)ctl setEnabled:NO];
        }
    }
    
    if(animated){
        
        _classifyViewAnimating = YES;
        
        [_classifyView setAlpha:0.0];
        [_classifyView setHidden:NO];
        
        CGRect r = [_classifyContentView frame];
        
        r.size.height = 0;
        
        [_classifyContentView setFrame:r];
        
        r.size.height = _classifyContentView.contentSize.height;

        [UIView animateWithDuration:0.3 animations:^{
            
            [_classifyView setAlpha:1.0];
            
            [_classifyContentView setFrame:r];
            
        } completion:^(BOOL finished) {
            
            _classifyViewAnimating = NO;
        }];
        
    }
    else{
        [_classifyView setAlpha:1.0];
        [_classifyView setHidden:NO];
    }
    
}

-(void) hiddenClassifyView:(BOOL) animated{
    
    if(_classifyViewAnimating){
        return;
    }
    
    [_classifyButton setSelected:NO];
    [_classifyButton setImage:[UIImage imageNamed:@"ico10.png"] forState:UIControlStateNormal];
    
    for(NSObject * ctl in _classifyEnabledViews){
        if([ctl respondsToSelector:@selector(setEnabled:)]){
            [(UIControl *)ctl setEnabled:YES];
        }
    }
    
    if(animated){
        
        _classifyViewAnimating = YES;
        
        [UIView animateWithDuration:0.3 animations:^{
            
            [_classifyView setAlpha:0.0];
            
            CGRect r = [_classifyContentView frame];
            
            r.size.height = 0;
            
            [_classifyContentView setFrame:r];
            
        } completion:^(BOOL finished) {
            [_classifyView setHidden:YES];
            _classifyViewAnimating = NO;
        }];
        
        
    }
    else{
        [_classifyView setHidden:YES];
    }
}
    
-(IBAction)doAction:(id)sender{

    NSString * actionName = [sender actionName];
    
    if([actionName isEqualToString:@"classify"]){
        
        self.classify = (NSString *) [sender userInfo];
        
        [self.dataOutletContainer setStatus:_classify];
        [self.dataOutletContainer applyDataOutlet:self];
        
        [self hiddenClassifyView:YES];
        
        [_feedController.tableView reloadData];
        [_feedController reloadData];
        
    }
    else{
        [super doAction:sender];
    }
    
}

-(void) setClassify:(NSString *)classify{
    
    _classify = classify;
    
    if([_classify isEqualToString:@"near"]){
        [_classifyButton setTitle:@"附近的" forState:UIControlStateNormal];
    }
    else if([_classify isEqualToString:@"follow"]){
        [_classifyButton setTitle:@"关注的妈妈" forState:UIControlStateNormal];
    }
    else if([_classify isEqualToString:@"friends"]){
        [_classifyButton setTitle:@"好友妈妈" forState:UIControlStateNormal];
    }
    else{
        [_classifyButton setTitle:@"钱多多" forState:UIControlStateNormal];
    }
    
    [_feedController.dataSource setValue:classify forKey:@"status"];
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
   
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"feed"]){
        
        NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"root:///root/fold/center/home/%@",[action userInfo]]
                             relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:[element attributeValueForKey:@"pid"] forKey:@"pid"]];
        
        [self openUrl:url animated:YES];
        
    }
    
    else if([actionName isEqualToString:@"user"]){
        
        NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [data setValue:[element attributeValueForKey:@"uid"] forKey:@"uid"];
        [data setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"root:///root/fold/center/home/%@",[action userInfo]]
                             relativeToURL:self.url queryValues:data];
        
        [self openUrl:url animated:YES];
        
    }
    else if([actionName isEqualToString:@"image"]){
    
        NSArray * images = [element valueForKey:@"images"];
        
        if([images isKindOfClass:[NSArray class]]){
            
            NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:4];
            
            [data setObject:images forKey:@"images"];
            [data setObject:[element attributeValueForKey:@"pageIndex"] forKey:@"pageIndex"];
            
            [self.context setFocusValue:data forKey:@"image"];
            
            [self openUrl:[NSURL URLWithString:@"pop://root/image"] animated:YES];
            
        }
        
    }
}
  
@end
