//
//  QDDMoreViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDMoreViewController : QDDViewController

@property (strong, nonatomic) IBOutlet VTTableSource *tableSource;

@end
