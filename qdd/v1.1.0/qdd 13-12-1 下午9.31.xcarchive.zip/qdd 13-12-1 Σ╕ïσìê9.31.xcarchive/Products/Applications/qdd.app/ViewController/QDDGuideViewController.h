//
//  QDDGuideViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDGuideViewController : QDDViewController<UIScrollViewDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *contentView;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;

@end
