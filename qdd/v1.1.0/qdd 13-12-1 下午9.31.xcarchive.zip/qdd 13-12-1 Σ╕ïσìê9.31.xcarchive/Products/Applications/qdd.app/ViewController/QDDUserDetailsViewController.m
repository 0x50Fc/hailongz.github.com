//
//  QDDUserDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserDetailsViewController.h"

#import "QDDFollowTask.h"
#import "QDDUnFollowTask.h"

#import "QDDUpdateUserTask.h"

@interface QDDUserDetailsViewController ()

@end

@implementation QDDUserDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSDictionary * queryValues = [self.url queryValues];
   
    self.title = [queryValues valueForKey:@"nick"];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_statusView setStatus:@"loading"];
    
    [_feedController.dataSource setValue:[queryValues valueForKey:@"uid"] forKey:@"uid"];
    [_detailsController.dataSource setValue:[queryValues valueForKey:@"uid"] forKey:@"uid"];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_feedController.dataSource isLoaded]
       && ![_feedController.dataSource isLoading]){
       
        [_feedController reloadData];
    }
}

-(void) vtDataControllerWillLoading:(VTDataController *)controller{
    if(controller == _feedController){
        [_detailsController reloadData];
    }
}

-(void) vtDataControllerDidLoaded:(VTDataController *)controller{
    [_statusView setStatus:nil];
}

-(void) vtDataController:(VTDataController *)controller didFitalError:(NSError *)error{
    [_statusView setStatus:nil];
}

-(void) refreshFollowButton{
    
    id dataItem = [_detailsController dataItem];
    
        if([[dataItem valueForKey:@"uid"] longLongValue] != [[(id<QDDContext>)self.context uid] longLongValue]){
        
        BOOL isFollow = [[dataItem valueForKey:@"isFollow"] boolValue];
        
        if(isFollow){
            [_followButton setImage:nil forState:UIControlStateNormal];
            [_followButton setTitle:@"已关注" forState:UIControlStateNormal];
        }
        else {
            [_followButton setImage:[UIImage imageNamed:@"ico61.png"] forState:UIControlStateNormal];
            [_followButton setTitle:@"关注" forState:UIControlStateNormal];
        }
        
        [_followButton setHidden:NO];
    }
    else{
        [_followButton setHidden:YES];
    }
}

-(void) userDetailsControllerDidContentSizeChanged:(QDDUserDetailsController *) controller{
    
    CGSize size = [controller contentSize];
    
    CGRect r = [_detailsTableViewCell frame];
    
    r.size.height = size.height - 20;
    
    [_detailsTableViewCell setFrame:r];
    
    [_feedController.tableView reloadData];
   
    [self refreshFollowButton];
    
    [_statusView setStatus:nil];
}


- (IBAction)onFollowAction:(id)sender {
   
    id dataItem = [_detailsController dataItem];
    BOOL isFollow = [[dataItem valueForKey:@"isFollow"] boolValue];
    
    if(isFollow){
        
        QDDUnFollowTask * task = [[QDDUnFollowTask alloc] init];
        
        [task setTuid:[[dataItem valueForKey:@"uid"] longLongValue]];
        
        [self.context handle:@protocol(IQDDUnFollowTask) task:task priority:0];
        
        _detailsController.fansCount --;
        
    }
    
    else{
        QDDFollowTask * task = [[QDDFollowTask alloc] init];
        
        [task setTuid:[[dataItem valueForKey:@"uid"] longLongValue]];
        
        [self.context handle:@protocol(IQDDFollowTask) task:task priority:0];
        
        _detailsController.fansCount ++;
    }
    
    [dataItem setValue:[NSNumber numberWithBool:!isFollow] forKey:@"isFollow"];
    
    [self refreshFollowButton];
}


-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"feed"]){
        
        NSURL * url = [NSURL URLWithString:@"user-details/feed-details"
                             relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:[element attributeValueForKey:@"pid"] forKey:@"pid"]];
        
        [self openUrl:url animated:YES];
        
    }
    
    else if([actionName isEqualToString:@"user"]){
        
   
        
    }
    
}

-(void) vtDocumentController:(VTDocumentController *)controller doActionElement:(VTDOMElement *)element{
    
    NSString * actionName= [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"bg"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        if([uid longLongValue] == [[(id<QDDContext>)self.context uid] longLongValue]){
            
            if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
                
                [self.context waitResultsData:^(id resultsData) {
                    
                    if([resultsData isEqualToString:@"camera"]){
                        
                        UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
                        
                        [imagePickerController setDelegate:self];
                        //[imagePickerController setAllowsEditing:YES];
                        [imagePickerController setSourceType:UIImagePickerControllerSourceTypeCamera];
                        
                        id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
                        
                        [rootViewController presentModalViewController:imagePickerController animated:YES];
                    }
                    else if([resultsData isEqualToString:@"library"]){
                        
                        UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
                        
                        [imagePickerController setDelegate:self];
                        //[imagePickerController setAllowsEditing:YES];
                        [imagePickerController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                        
                        id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
                        
                        [rootViewController presentModalViewController:imagePickerController animated:YES];
                    }
                    
                }];
                
                NSString * url = @"pop:///image-picker?title=更换背景";
                
                [self openUrl:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ] animated:YES];
                
            }
            else{
                
                UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
                
                [imagePickerController setDelegate:self];
                //[imagePickerController setAllowsEditing:YES];
                [imagePickerController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                
                id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
                
                [rootViewController presentModalViewController:imagePickerController animated:YES];
            }
            
        }
        
    }
    
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissModalViewControllerAnimated:YES];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage * image = [info valueForKey:UIImagePickerControllerEditedImage];
    
    if(image == nil){
        image = [info valueForKey:UIImagePickerControllerOriginalImage];
    }
   
    [_detailsController udpateBGImage:image];
    
    [_statusView setStatus:@"uploading"];
    [_statusView setUserInteractionEnabled:NO];
    
    QDDUpdateUserTask * task = [[QDDUpdateUserTask alloc] init];
    
    [task setDelegate:self];
    [task setSource:self];
    [task setBgImage:image];
    
    [self.context handle:@protocol(IQDDUpdateUserTask) task:task priority:0];
    
    [picker dismissModalViewControllerAnimated:YES];
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) uplinkTask;
        
        [_detailsController.dataItem setValue:[userTask bgImageUri] forKey:@"bgImage"];
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"保存成功"];
        
        [alertView showDuration:1.2];
        
    }
    
}

@end
