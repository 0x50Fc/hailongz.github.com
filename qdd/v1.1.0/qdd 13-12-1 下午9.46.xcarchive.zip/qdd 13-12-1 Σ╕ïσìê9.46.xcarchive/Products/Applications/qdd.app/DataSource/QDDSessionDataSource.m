//
//  QDDSessionDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDSessionDataSource.h"

#import "QDDMessageObject.h"

#import "QDDUserGetTask.h"

@implementation QDDSessionDataSource

@synthesize sessionId = _sessionId;

-(id) init{
    if((self = [super init])){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(messageChangedAction:) name:QDDMessageChangedNotification object:nil];
        
    }
    return self;
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDMessageChangedNotification object:nil];
    
}

-(void) loadDataObjects{
    
    
    long long uid = [[(id<QDDContext>)self.context uid] longLongValue];
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
    
    [[self dataObjects] removeAllObjects];
    
    id<IVTSqliteCursor> cursor = [dbContext query:[QDDMessageObject tableClass] sql:[NSString stringWithFormat:@"WHERE (uid=%lld AND tuid=%lld) OR (uid=%lld) ORDER BY mid DESC",uid,_sessionId,_sessionId] data:nil];
    
    while([cursor next]){
        
        NSMutableDictionary * dataItem = [NSMutableDictionary dictionaryWithCapacity:4];
        
        QDDMessageObject * dataObject = [[QDDMessageObject alloc] init];
        
        [cursor toDataObject:dataObject];
        
        [dataItem setValue:dataObject forKey:@"dataObject"];
        
        [dataItem setValue:[[NSDate dateWithTimeIntervalSince1970:dataObject.timestamp] QDDFormatString] forKey:@"timestamp"];
        
        QDDUserGetTask * task = [[QDDUserGetTask alloc] init];
        
        [task setUid:dataObject.uid];
        
        [self.context handle:@protocol(IQDDUserGetTask) task:task priority:0];
        
        if([task dataObject]){
            [dataItem setObject:[task dataObject] forKey:@"user"];
        }
        
        [[self dataObjects] insertObject:dataItem atIndex:0];
    }
    
    [cursor close];
    
    
}

-(void) messageChangedAction:(NSNotification *) notification{
    
    [self loadDataObjects];
    
    if(([self.delegate respondsToSelector:@selector(vtDataSourceDidContentChanged:)])){
        [self.delegate vtDataSourceDidContentChanged:self];
    }
}

-(BOOL) hasMoreData{
    return NO;
}

-(void) reloadData{
    [super reloadData];
    
    [self loadDataObjects];
    
    if([self.delegate respondsToSelector:@selector(vtDataSourceDidLoaded:)]){
        [self.delegate vtDataSourceDidLoaded:self];
    }
    
}


@end
