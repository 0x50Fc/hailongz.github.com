//
//  QDDUserService.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserService.h"

#import "QDDUpdateUserTask.h"

#import "QDDImageUploadTask.h"

@interface QDDUserImageUploadTask : QDDImageUploadTask

@property(nonatomic,retain) id task;
@property(nonatomic,assign) Protocol * taskType;
@property(nonatomic,retain) NSString * key;

@end

@implementation QDDUserImageUploadTask


@end

@implementation QDDUserService

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) task;
        
        if([userTask logo] == nil && [userTask logoImage]){
            
            QDDUserImageUploadTask * imageTask = [[QDDUserImageUploadTask alloc] init];
            
            [imageTask setImage:[userTask logoImage]];
            [imageTask setMaxWidth:160];
            [imageTask setTask:task];
            [imageTask setTaskType:taskType];
            [imageTask setSource:[task source]];
            [imageTask setDelegate:self];
            [imageTask setKey:@"logo"];
            
            [self.context handle:@protocol(IQDDImageUploadTask) task:imageTask priority:0];
            
        }
        else if([userTask bgImageUri] == nil && [userTask bgImage]){
            
            QDDUserImageUploadTask * imageTask = [[QDDUserImageUploadTask alloc] init];
            
            [imageTask setImage:[userTask bgImage]];
            [imageTask setMaxWidth:640];
            [imageTask setTask:task];
            [imageTask setTaskType:taskType];
            [imageTask setSource:[task source]];
            [imageTask setDelegate:self];
            [imageTask setKey:@"bgImageUri"];
            
            [self.context handle:@protocol(IQDDImageUploadTask) task:imageTask priority:0];
            
        }
        else{
            
            VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
            
            [httpTask setTaskType:taskType];
            [httpTask setTask:task];
            [httpTask setSource:[task source]];
            
            [httpTask setApiKey:@"url"];
            
            VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
            
            [body addItemValue:@"config_qdd" forKey:@"config"];
            [body addItemValue:@"QDDUpdateUserTask" forKey:@"taskType"];
            
            NSMutableString * updateKeys = [NSMutableString stringWithCapacity:128];
            
            if([userTask nick]){
                [body addItemValue:[userTask nick] forKey:@"qdd-nick"];
                [updateKeys appendString:@"nick,"];
            }
            
            if([userTask age]){
            
                [body addItemValue:[NSString stringWithFormat:@"%d",[userTask age]] forKey:@"qdd-age"];
                [updateKeys appendString:@"age,"];
            }
            
            if([userTask logo]){
                [body addItemValue:[userTask logo] forKey:@"qdd-logo"];
                [updateKeys appendString:@"logo,"];
            }
            
            if([userTask logo]){
                [body addItemValue:[userTask constellation] forKey:@"qdd-constellation"];
                [updateKeys appendString:@"constellation,"];
            }
            
            if([userTask job]){
                [body addItemValue:[userTask job] forKey:@"qdd-job"];
                [updateKeys appendString:@"job,"];
            }
            
            if([userTask city]){
                [body addItemValue:[userTask city] forKey:@"qdd-city"];
                [updateKeys appendString:@"city,"];
            }
            
            if([userTask bgImageUri]){
                [body addItemValue:[userTask bgImageUri] forKey:@"qdd-bgImage"];
                [updateKeys appendString:@"bgImage,"];
            }
            
            [body addItemValue:updateKeys forKey:@"qdd-updateKeys"];
            
            [httpTask setBody:body];
            
            [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
            
        }
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IVTUplinkTask> uplinkTask = (id<IVTUplinkTask>)[respTask task];
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(error == nil){
                    error = @"";
                }
                
                [self vtUplinkTask:uplinkTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
                
            }
            else{
                
                id user = [[respTask resultsData] dataForKeyPath:@"user-results"];
                
                if(user){
                    [(id<QDDContext>)self.context setNick:[user dataForKeyPath:@"nick"]];
                    [(id<QDDContext>)self.context setUserInfo:user];
                }
                
                [self vtUplinkTask:uplinkTask didSuccessResults:[respTask resultsData]
                       forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
        
    }
    
    return NO;
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDUserImageUploadTask * imageTask = (QDDUserImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) [imageTask task];
            
            [self vtUploadTask:userTask didFailWithError:error forTaskType:@protocol(IQDDUpdateUserTask)];
            
        }
 
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDUserImageUploadTask * imageTask = (QDDUserImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) [imageTask task];
            
            [(id)userTask setValue:[results valueForKey:@"uri"] forKey:[imageTask key]];
       
            if([(id)userTask valueForKey:[imageTask key]] == nil){
                
                [self vtUploadTask:userTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:0 userInfo:[NSDictionary dictionaryWithObject:@"上传图片失败" forKey:NSLocalizedDescriptionKey]] forTaskType:@protocol(IQDDUpdateUserTask) ];

            }
            else {
                
                [self handle:@protocol(IQDDUpdateUserTask) task:userTask priority:0];
                
            }
            
        }
        
    }
    
}

@end
