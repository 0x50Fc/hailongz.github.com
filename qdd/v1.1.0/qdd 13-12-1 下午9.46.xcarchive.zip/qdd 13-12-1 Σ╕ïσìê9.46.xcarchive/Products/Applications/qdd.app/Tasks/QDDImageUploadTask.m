//
//  QDDImageUploadTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDImageUploadTask.h"

@implementation QDDImageUploadTask

@synthesize image = _image;
@synthesize maxWidth = _maxWidth;
@synthesize imageSize = _imageSize;
@synthesize resultsData = _resultsData;
@synthesize task = _task;
@synthesize taskType = _taskType;

@end
