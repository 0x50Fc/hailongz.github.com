//
//  QDDUpdateUserTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDUpdateUserTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * nick;
@property(nonatomic,retain) NSString * logo;
@property(nonatomic,retain) UIImage * logoImage;
@property(nonatomic,assign) NSInteger age;
@property(nonatomic,retain) NSArray * classifyObjects;
@property(nonatomic,retain) NSString * constellation;
@property(nonatomic,retain) NSString * job;
@property(nonatomic,retain) NSString * city;
@property(nonatomic,retain) NSString * bgImageUri;
@property(nonatomic,retain) UIImage * bgImage;

@end

@interface QDDUpdateUserTask : VTUplinkTask<IQDDUpdateUserTask>

@end
