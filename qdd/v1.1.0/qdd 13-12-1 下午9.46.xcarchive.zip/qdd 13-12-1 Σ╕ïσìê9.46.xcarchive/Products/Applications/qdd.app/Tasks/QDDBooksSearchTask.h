//
//  QDDBooksSearchTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDBooksSearchTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) NSTimeInterval startTime;
@property(nonatomic,assign) NSTimeInterval endTime;

@end

@interface QDDBooksSearchTask : VTUplinkTask<IQDDBooksSearchTask>

@end
