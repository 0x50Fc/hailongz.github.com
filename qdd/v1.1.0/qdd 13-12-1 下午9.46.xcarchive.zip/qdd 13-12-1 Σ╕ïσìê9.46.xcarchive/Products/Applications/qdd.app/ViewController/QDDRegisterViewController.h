//
//  QDDRegisterViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"


@interface QDDRegisterViewController : QDDViewController<IVTUplinkTaskDelegate,UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *accountField;
@property (strong, nonatomic) IBOutlet UITextField *passwordField;
@property (strong, nonatomic) IBOutlet UITextField *nickField;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;

- (IBAction)doCommitAction:(id)sender;

-(IBAction) doCancelInputAction:(id)sender;

@end
