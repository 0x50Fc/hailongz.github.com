//
//  QDDSessionController.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDSessionController.h"

@implementation QDDSessionController

-(NSString *) htmlContentByIndexPath:(NSIndexPath *)indexPath{
    
    id dataItem = [self dataObjectForIndexPath:indexPath];
    
    long long uid = [[(id<QDDContext>)self.context uid] longLongValue];
    
    if([[dataItem dataForKeyPath:@"dataObject.uid"] longLongValue] == uid){
        self.html = @"msg_right.html";
    }
    else{
        self.html = @"msg_left.html";
    }
    
    return [super htmlContentByIndexPath:indexPath];
}

@end
