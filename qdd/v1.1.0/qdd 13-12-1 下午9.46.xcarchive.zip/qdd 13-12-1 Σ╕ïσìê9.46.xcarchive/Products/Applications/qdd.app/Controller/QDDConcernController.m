//
//  QDDConcernController.m
//  qdd
//
//  Created by zhang hailong on 13-11-25.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDConcernController.h"

#import "QDDUnFollowTask.h"

@implementation QDDConcernController

-(id) dataObjectByIndexPath:(NSIndexPath *) indexPath;{
    return [(QDDConcernDataSource *)self.dataSource dataObjectAtIndexPath:indexPath];
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return [[(QDDConcernDataSource *)self.dataSource sections] count];
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[[[(QDDConcernDataSource *) self.dataSource sections] objectAtIndex:section] dataObjects] count];
}

-(UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView * v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 22)];
    
    [v setBackgroundColor:[UIColor colorWithRed:247.0 / 255 green:227.0 / 255 blue:219.0 / 255 alpha:1.0]];
    
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 22)];
    
    [label setFont:[UIFont boldSystemFontOfSize:12]];
    [label setTextColor:[UIColor colorWithRed:242.0/255 green:108.0/255 blue:79.0/255 alpha:1.0]];
    [label setBackgroundColor:[UIColor clearColor]];
    [label setAutoresizingMask:UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleRightMargin];
    
    QDDConcernDataSourceSection * s = [[(QDDConcernDataSource *) self.dataSource sections] objectAtIndex:section];
    
    [label setText:[s py]];
    
    [v addSubview:label];
    
    return v;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    VTDOMDocument * document = [self documentByIndexPath:indexPath];
    
    return [[document rootElement] frame].size.height;
}

-(NSArray *) sectionIndexTitlesForTableView:(UITableView *)tableView{
    
    if([[(QDDConcernDataSource *) self.dataSource sections] count] < 10){
        return nil;
    }
    
    NSMutableArray * titles = [NSMutableArray arrayWithCapacity:4];
    
    for(QDDConcernDataSourceSection * section in [(QDDConcernDataSource *) self.dataSource sections]){
        
        [titles addObject:[section py]];
        
    }
    
    return titles;
    
}


-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString * identifier = self.reusableCellIdentifier;
    
    if(identifier == nil){
        identifier = @"Document";
    }
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if(cell == nil){
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        
        [cell setBackgroundColor:[UIColor clearColor]];
        [cell.contentView setBackgroundColor:[UIColor clearColor]];
        
        CGSize size = cell.contentView.bounds.size;
        
        VTDOMView * documentView = [[VTDOMView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        
        [documentView setBackgroundColor:[UIColor clearColor]];
        [documentView setDelegate:self];
        [documentView setAllowAutoLayout:NO];
        [documentView setTag:100];
        [documentView setAutoresizingMask:UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth];
        
        [cell.contentView addSubview:documentView];
        
    }
    
    VTDOMView * documentView = (VTDOMView *) [cell.contentView viewWithTag:100];
    
    VTDOMDocument * document = [self documentByIndexPath:indexPath];
    
    [documentView setElement:[document rootElement]];
    
    [self loadImagesForView:documentView];
    
    dispatch_async(dispatch_get_current_queue(), ^{
        [self downloadImagesForView:documentView];
    });
    
    if([document rootElement]){
        
        [self loadImagesForElement:[document rootElement]];
        
        dispatch_async(dispatch_get_current_queue(), ^{
            [self downloadImagesForElement:[document rootElement]];
        });
        
    }
    
    return cell;
}

-(BOOL) tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

-(UITableViewCellEditingStyle) tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}

-(void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    id dataItem = [self dataObjectByIndexPath:indexPath];
    
    long long uid = [[dataItem dataForKeyPath:@"dataObject.uid"] longLongValue];
    
    if(uid){
        
        QDDConcernDataSourceSection * section = [[(QDDConcernDataSource *) self.dataSource sections] objectAtIndex:indexPath.section];
        
        [[section dataObjects] removeObjectAtIndex:indexPath.row];
        
        if([[section dataObjects] count] == 0){
            
            [[(QDDConcernDataSource *) self.dataSource sections] removeObjectAtIndex:indexPath.section];
            
            [tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationRight];
            
        }
        else{
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationRight];
        }
        
        dispatch_async(dispatch_get_current_queue(), ^{
           
            QDDUnFollowTask * task = [[QDDUnFollowTask alloc] init];
            
            [task setTuid:uid];
            
            [self.context handle:@protocol(IQDDUnFollowTask) task:task priority:0];
            
        });
    }
    
}

@end
