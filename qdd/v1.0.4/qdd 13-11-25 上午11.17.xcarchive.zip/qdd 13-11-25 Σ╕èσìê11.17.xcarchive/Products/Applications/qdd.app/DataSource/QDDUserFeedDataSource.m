//
//  QDDUserFeedDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserFeedDataSource.h"

@implementation QDDUserFeedDataSource

@synthesize uid = _uid;

-(void) setUid:(long long)uid{
    _uid = uid;
    [self.queryValues setValue:[NSString stringWithFormat:@"%lld",uid] forKey:@"uid"];
}


-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    for(id dataItem in [self dataObjects]){
        
        if([dataItem valueForKey:@"fmtCreateTime"] == nil){
            NSDate * date = [NSDate dateWithTimeIntervalSince1970:[[dataItem dataForKeyPath:@"createTime"] doubleValue]];
            
            [dataItem setValue:[date QDDFormatString] forKey:@"fmtCreateTime"];
        }
        
        if([dataItem valueForKey:@"fmtDistance"] == nil){
            double latitude = [[dataItem dataForKeyPath:@"latitude"] doubleValue];
            double longitude = [[dataItem dataForKeyPath:@"longitude"] doubleValue];
            
            if(latitude && longitude){
                double dis = [(id<QDDContext>)self.context distance:latitude longitude:longitude];
                if(dis >=0 ){
                    
                    if(dis <1){
                        dis = 1;
                    }
                    
                    [dataItem setValue:[NSNumber numberWithDouble:dis] forKey:@"distance"];
                    
                    if(dis < 1000.0){
                        [dataItem setValue:[NSString stringWithFormat:@"%d米",(int) (dis)] forKey:@"fmtDistance"];
                    }
                    else{
                        [dataItem setValue:[NSString stringWithFormat:@"%d公里",(int) (dis / 1000)] forKey:@"fmtDistance"];
                    }
                }
            }
        }
        
        if([dataItem valueForKey:@"html"] == nil){
            
            NSString * body = [dataItem valueForKey:@"body"];
            
            [dataItem setValue:[body stringByReplacingOccurrencesOfString:@" " withString:@"&nbsp;"] forKey:@"html"];
            
        }
    }

}

@end
