//
//  QDDMyViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMyViewController.h"

#import "QDDUpdateUserTask.h"

@interface QDDMyViewController ()

@end

@implementation QDDMyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.context handle:@protocol(IVTImageTask) task:_imageView priority:0];
}

-(void) dealloc{
    [self.context cancelHandle:@protocol(IVTImageTask) task:_imageView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doLogoAction:(id)sender {
    
    [_nickTextField resignFirstResponder];
    
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        
        [self.context waitResultsData:^(id resultsData) {
            
            if([resultsData isEqualToString:@"camera"]){
                
                UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
                
                [imagePickerController setDelegate:self];
                [imagePickerController setAllowsEditing:YES];
                [imagePickerController setSourceType:UIImagePickerControllerSourceTypeCamera];
                
                id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
                
                [rootViewController presentModalViewController:imagePickerController animated:YES];
            }
            else if([resultsData isEqualToString:@"library"]){
                
                UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
                
                [imagePickerController setDelegate:self];
                [imagePickerController setAllowsEditing:YES];
                [imagePickerController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                
                id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
                
                [rootViewController presentModalViewController:imagePickerController animated:YES];
            }
            
        }];
        
        NSString * url = @"pop:///image-picker?title=更换头像";
        
        [self openUrl:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ] animated:YES];
        
    }
    else{
        
        UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
        
        [imagePickerController setDelegate:self];
        [imagePickerController setAllowsEditing:YES];
        [imagePickerController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
        
        id rootViewController =[(id<QDDContext>)self.context topPresentViewController];
        
        [rootViewController presentModalViewController:imagePickerController animated:YES];
    }
    
}

- (IBAction)doSaveAction:(id)sender {
    
    NSString * nick = [[_nickTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSInteger len = [nick textLength];
    
    if(len == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入昵称" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if(len < 4 ){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"昵称至少4个字符,或2个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if(len > 24 ){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"昵称最多24个字符,或12个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDUpdateUserTask * task = [[QDDUpdateUserTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setNick:nick];
    [task setLogoImage:_imageView.image];
    
    [self.context handle:@protocol(IQDDUpdateUserTask) task:task priority:0];
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissModalViewControllerAnimated:YES];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage * image = [info valueForKey:UIImagePickerControllerEditedImage];
    
    if(image == nil){
        image = [info valueForKey:UIImagePickerControllerOriginalImage];
    }
    
    [self.context cancelHandle:@protocol(IVTImageTask) task:_imageView];
    
    [_imageView setImage:image];
    
    [picker dismissModalViewControllerAnimated:YES];
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
   
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"保存成功"];
        
        [alertView showDuration:1.2];
    
    }

}

@end
