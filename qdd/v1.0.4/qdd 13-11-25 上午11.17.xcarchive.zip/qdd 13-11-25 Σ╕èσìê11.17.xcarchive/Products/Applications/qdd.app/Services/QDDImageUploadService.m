//
//  QDDImageUploadService.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDImageUploadService.h"

#import "QDDImageUploadTask.h"

@interface QDDImageUploadHttpTask : VTHttpTask

@property(nonatomic,retain) id task;
@property(nonatomic,assign) Protocol * taskType;

@end

@implementation QDDImageUploadHttpTask



@end

@implementation QDDImageUploadService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        id<IQDDImageUploadTask> upTask = (id<IQDDImageUploadTask>) task;
        
        UIImage * image = [upTask image];
        
        CGSize size = image.size;
        
        if(size.width > [upTask maxWidth]){
         
            size = CGSizeMake([upTask maxWidth], size.height / size.width * [upTask maxWidth]);
            
            UIGraphicsBeginImageContext(size);
            
            [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
            
            image = UIGraphicsGetImageFromCurrentImageContext();
            
            UIGraphicsEndImageContext();
        }
        
        [upTask setImageSize:size];
        
        NSData * data = UIImageJPEGRepresentation(image, 0.8);
        
        QDDImageUploadHttpTask * httpTask = [[QDDImageUploadHttpTask alloc] init];
        
        NSURL * url = [NSURL URLWithString:[self.config valueForKey:@"url"]];
        
        NSLog(@"%@",url);
        
        NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:120];
        
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemBytes:data contentType:@"image/jpg" forKey:@"uri"];
        
        [request setHTTPBody:[body bytesBody]];
        [request setHTTPMethod:@"POST"];
        
        [request addValue:[body contentType] forHTTPHeaderField:@"Content-Type"];
        
        [httpTask setRequest:request];
        
        [httpTask setResponseType:VTHttpTaskResponseTypeJSON];
        
        [httpTask setTask:task];
        
        [httpTask setTaskType:taskType];
        
        [httpTask setSource:[task source]];
        
        [httpTask setDelegate:self];
        
        [self.context handle:@protocol(IVTHttpUploadTask) task:httpTask priority:0];
        
        return YES;
    }
    
    return NO;
}

-(void) vtHttpTask:(id) httpTask didFailError:(NSError *) error{
    
    if([httpTask taskType] == @protocol(IQDDImageUploadTask)){
        
        id<IQDDImageUploadTask> upTask = [httpTask task];
        
        [upTask setResultsData:nil];
        
        [self vtUplinkTask:upTask didFailWithError:error forTaskType:[httpTask taskType]];
        
    }
    
}

-(void) vtHttpTaskDidLoaded:(id) httpTask{
    
    if([httpTask taskType] == @protocol(IQDDImageUploadTask)){
        
        id<IQDDImageUploadTask> upTask = [httpTask task];
        
        [upTask setResultsData:[httpTask responseBody]];
        
        NSLog(@"%@",[httpTask responseBody]);
        
        [self vtUplinkTask:upTask didSuccessResults:[httpTask responseBody] forTaskType:[httpTask taskType]];
        
    }
}

@end
