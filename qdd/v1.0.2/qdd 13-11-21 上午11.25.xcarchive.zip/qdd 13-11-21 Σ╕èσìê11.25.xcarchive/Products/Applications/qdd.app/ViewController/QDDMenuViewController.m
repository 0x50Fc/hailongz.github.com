//
//  QDDMenuViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-4.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMenuViewController.h"

@interface QDDMenuViewController ()

@end

@implementation QDDMenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userInfoChangedAction:) name:QDDUserInfoChangedNotification object:nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [self.context handle:@protocol(IVTImageTask) task:_imageView priority:0];
    
}

-(void) dealloc{
    
    [self.context cancelHandle:@protocol(IVTImageTask) task:_imageView];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDUserInfoChangedNotification object:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)logoutAction:(id)sender {
    
    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"注销" otherButtonTitles: nil];
    
    [actionSheet showInView:self.view.window];
  
}
    
-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){
        [(id<QDDContext>)self.context logout:YES];
    }
}

-(void) userInfoChangedAction:(NSNotification *) notification{
    
    [self.context cancelHandle:@protocol(IVTImageTask) task:_imageView];
    
    [self.dataOutletContainer applyDataOutlet:self];
    
    [self.context handle:@protocol(IVTImageTask) task:_imageView priority:0];
    
}
    
@end
