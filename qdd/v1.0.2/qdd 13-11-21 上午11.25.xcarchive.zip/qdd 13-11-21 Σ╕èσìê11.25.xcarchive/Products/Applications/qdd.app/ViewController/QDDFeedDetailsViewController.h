//
//  QDDFeedDetailsViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDFeedDocumentController.h"
#import "QDDCommentListController.h"

@interface QDDFeedDetailsViewController : QDDViewController<VTDocumentDataControllerDelegate,VTDocumentControllerDelegate,QDDFeedDocumentControllerDelegate>

@property (strong, nonatomic) IBOutlet QDDCommentListController *commentListController;
@property (strong, nonatomic) IBOutlet QDDFeedDocumentController *documentController;
@property (strong, nonatomic) IBOutlet VTTableViewCell *detailsTableViewCell;

-(IBAction) doCommentAction:(id)sender;

@end
