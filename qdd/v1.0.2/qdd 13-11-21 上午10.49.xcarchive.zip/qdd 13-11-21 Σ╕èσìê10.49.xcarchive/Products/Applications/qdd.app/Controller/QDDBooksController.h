//
//  QDDBooksController.h
//  qdd
//
//  Created by zhang hailong on 13-11-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDBooksController : VTTableDataController

@property(nonatomic,retain) IBOutlet UILabel * dateLabel;
@property(nonatomic,retain) IBOutlet UIButton * prevButton;
@property(nonatomic,retain) IBOutlet UIButton * nextButton;
@property(nonatomic,retain) IBOutlet UILabel * expendMoneyLabel;

-(IBAction) doNextMonthAction:(id)sender;

-(IBAction) doPrevMonthAction:(id)sender;

@end
