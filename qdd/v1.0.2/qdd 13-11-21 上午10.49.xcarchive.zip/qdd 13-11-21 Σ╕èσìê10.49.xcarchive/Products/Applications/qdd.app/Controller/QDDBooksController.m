//
//  QDDBooksController.m
//  qdd
//
//  Created by zhang hailong on 13-11-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksController.h"

@implementation QDDBooksController

-(void) awakeFromNib{
    [super awakeFromNib];
    
    [self refreshState];
}

-(void) refreshState{

    NSDate * date = [self.dataSource valueForKey:@"date"];
    
    if(date == nil){
        date = [NSDate date];
    }
    
    NSCalendar * calendar = [NSCalendar currentCalendar];

    NSDateComponents * dateComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:date];
    
    NSDateComponents * nowComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:[NSDate date]];
    
    
    if(dateComponents.year == nowComponents.year && dateComponents.month == nowComponents.month){
        [_nextButton setEnabled:NO];
    }
    else{
        [_nextButton setEnabled:YES];
    }
    
    [_dateLabel setText:[NSString stringWithFormat:@"%d年%02d月",dateComponents.year,dateComponents.month]];
    
    NSNumberFormatter * formatter = [[NSNumberFormatter alloc] init];
    
    [formatter setPositiveFormat:@"¥ ###,###.##"];
    
    [_expendMoneyLabel setText:[formatter stringFromNumber:[self.dataSource valueForKey:@"expendMoney"]]];
    
}

-(IBAction) doNextMonthAction:(id)sender{
    
    NSDate * date = [self.dataSource valueForKey:@"date"];
    
    if(date == nil){
        date = [NSDate date];
    }
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    NSDateComponents * dateComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:date];
    
    if(dateComponents.month + 1 > 12){
        dateComponents.year= dateComponents.year +1;
        dateComponents.month = 1;
    }
    else{
        dateComponents.month = dateComponents.month + 1;
    }
    
    dateComponents.day = 1;
    
    [self.dataSource setValue:[calendar dateFromComponents:dateComponents] forKey:@"date"];
    
    [self.dataSource refreshData];
    
    [self.tableView setContentOffset:CGPointZero animated:NO];
    
    [self refreshState];
}

-(IBAction) doPrevMonthAction:(id)sender{
    
    NSDate * date = [self.dataSource valueForKey:@"date"];
    
    if(date == nil){
        date = [NSDate date];
    }
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    NSDateComponents * dateComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:date];
    
    if(dateComponents.month - 1 < 1){
        dateComponents.year= dateComponents.year -1;
        dateComponents.month = 12;
    }
    else{
        dateComponents.month = dateComponents.month - 1;
    }
    
    dateComponents.day = 1;
    
    [self.dataSource setValue:[calendar dateFromComponents:dateComponents] forKey:@"date"];
    
    [self.dataSource refreshData];
    
    [self.tableView setContentOffset:CGPointZero animated:NO];
    
    [self refreshState];
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row < [self.headerCells count]){
        return [[self.headerCells objectAtIndex:indexPath.row] frame].size.height;
    }
    
    if(indexPath.row >= [self.dataSource count] + [self.headerCells count]){
        return [[self.footerCells objectAtIndex:indexPath.row
                 - [self.dataSource count] - [self.headerCells count]] frame].size.height;
    }
    
    id data = [self.dataSource dataObjectAtIndex:indexPath.row - [self.headerCells count]];
    
    if([data valueForKey:@"day"] == nil){
        return 35;
    }
    else if([data valueForKey:@"data"] == nil){
        return 26;
    }
    
    return tableView.rowHeight;
    
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if(indexPath.row < [self.headerCells count]){
        return [self.headerCells objectAtIndex:indexPath.row];
    }
    
    if(indexPath.row >= [self.dataSource count] + [self.headerCells count]){
        return [self.footerCells objectAtIndex:indexPath.row
                - [self.dataSource count] - [self.headerCells count]];
    }
    
    id data = [self.dataSource dataObjectAtIndex:indexPath.row - [self.headerCells count]];
    
    NSString * itemViewNib = self.itemViewNib;
    
    if([data valueForKey:@"day"] == nil){
        itemViewNib = @"QDDBooksNullItemViewController";
    }
    else if([data valueForKey:@"data"] == nil){
        itemViewNib = @"QDDBooksDayItemViewController";
    }
    
    NSString * identifier = itemViewNib;

    if(identifier == nil){
        identifier = @"Cell";
    }
    
   
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if(cell == nil){
        
        cell = (UITableViewCell *) [VTTableViewCell tableViewCellWithNibName:itemViewNib bundle:self.itemViewBundle];
        
        [cell setValue:identifier forKey:@"reuseIdentifier"];
        
        if([cell isKindOfClass:[VTTableViewCell class]]){
            [(VTTableViewCell *) cell setController:self];
            [(VTTableViewCell *) cell setDelegate:self];
        }
    }
  
    if([cell isKindOfClass:[VTTableViewCell class]]){
        [(VTTableViewCell *) cell setContext:self.context];
        [(VTTableViewCell *) cell setDataItem:data];
    }
    
    
    return cell;
}

-(void) vtDataSourceDidContentChanged:(VTDataSource *)dataSource{
    [super vtDataSourceDidContentChanged:dataSource];
    [self refreshState];
}

-(void) vtDataSourceDidLoaded:(VTDataSource *)dataSource{
    [super vtDataSourceDidLoaded:dataSource];
    [self refreshState];
}

@end
