//
//  QDDPublishTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDPublishTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * body;
@property(nonatomic,retain) NSArray * images;
@property(nonatomic,retain) NSArray * tagObjects;
@property(nonatomic,retain) NSArray * classifyObjects;
@property(nonatomic,assign) double payMoney;
@property(nonatomic,assign) double expendMoney;
@property(nonatomic,assign) double latitude;
@property(nonatomic,assign) double longitude;
@property(nonatomic,assign) BOOL toWeibo;
@property(nonatomic,assign) BOOL toQQ;

@end

@interface QDDPublishTask : VTUplinkTask<IQDDPublishTask>

@end
