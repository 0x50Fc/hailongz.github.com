//
//  QDDWeiboBindTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-19.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDWeiboBindTask.h"

@implementation QDDWeiboBindTask

@synthesize expires_in = _expires_in;
@synthesize token = _token;

@end
