//
//  QDDUnFollowTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDUnFollowTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) long long tuid;

@end

@interface QDDUnFollowTask : VTUplinkTask<IQDDUnFollowTask>

@end
