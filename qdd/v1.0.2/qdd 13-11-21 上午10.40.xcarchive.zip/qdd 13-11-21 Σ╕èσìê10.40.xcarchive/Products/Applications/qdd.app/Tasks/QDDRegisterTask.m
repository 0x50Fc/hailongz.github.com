//
//  QDDRegisterTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDRegisterTask.h"

@implementation QDDRegisterTask

@synthesize account = _account;
@synthesize password = _password;
@synthesize nick = _nick;

@end
