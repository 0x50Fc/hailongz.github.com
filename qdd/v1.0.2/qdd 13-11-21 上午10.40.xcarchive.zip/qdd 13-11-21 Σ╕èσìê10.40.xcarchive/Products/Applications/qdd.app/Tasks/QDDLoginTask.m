//
//  QDDLoginTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDLoginTask.h"

@implementation QDDLoginTask

@synthesize account = _account;
@synthesize password = _password;

@end
