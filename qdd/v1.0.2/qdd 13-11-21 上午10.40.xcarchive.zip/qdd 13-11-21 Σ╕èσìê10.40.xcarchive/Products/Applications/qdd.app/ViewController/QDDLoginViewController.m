//
//  QDDLoginViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDLoginViewController.h"

#import "QDDLoginTask.h"

@interface QDDLoginViewController ()

@end

@implementation QDDLoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)loginAction:(id)sender {
    
    
    NSString * account = [_accountField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * password = _passwordField.text;
    
    if([account length] ==0){

        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入登录名" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if([password length] ==0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入密码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDLoginTask * task = [[QDDLoginTask alloc] init];
    
    [task setAccount:account];
    [task setPassword:password];
    [task setSource:self];
    [task setDelegate:self];
    
    [self.context handle:@protocol(IQDDLoginTask) task:task priority:0];

}
    
- (IBAction)weiboLoginAction:(id)sender {
    
    
    [(id<QDDContext>)self.context weiboLogin];
    
}
    
- (IBAction)qqLoginAction:(id)sender {
    
    [(id<QDDContext>)self.context qqLogin];
    
}
    
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == _accountField){
        [_passwordField becomeFirstResponder];
    }
    else if(textField == _passwordField){
        [_passwordField resignFirstResponder];
    }
    
    return YES;
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDLoginTask)){
        
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
        
        [(id<QDDContext>)self.context toRootViewController:YES];
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDLoginTask)){
        
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
    
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
}

@end
