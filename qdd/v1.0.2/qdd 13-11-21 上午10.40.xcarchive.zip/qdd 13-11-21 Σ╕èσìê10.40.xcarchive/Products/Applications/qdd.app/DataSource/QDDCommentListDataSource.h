//
//  QDDCommentListDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPageDataSource.h"

@interface QDDCommentListDataSource : QDDPageDataSource

@end
