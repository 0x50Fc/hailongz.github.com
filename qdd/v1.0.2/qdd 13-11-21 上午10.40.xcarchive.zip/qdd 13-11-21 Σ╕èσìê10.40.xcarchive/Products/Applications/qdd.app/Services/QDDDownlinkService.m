//
//  QDDDownlinkService.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDDownlinkService.h"

#import "IQDDDownlinkTask.h"

@implementation QDDDownlinkService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDDownlinkTask)){
        
        id<IQDDDownlinkTask> downTask = (id<IQDDDownlinkTask>)task;
        
        if([downTask isAllowCached] && ![downTask isSkipCached] && [downTask vtDownlinkPageTaskPageIndex] ==1){
            [self vtDownlinkTaskDidLoadedFromCache:downTask forTaskType:taskType];
        }
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        
        [body addItemValue:[downTask taskType] forKey:@"taskType"];
        
        NSDictionary * queryValues =[downTask queryValues];
        
        for (NSString * key in queryValues) {
            
            [body addItemValue:[queryValues valueForKey:key] forKey:[NSString stringWithFormat:@"qdd-%@",key]];
            
        }
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDDownlinkTask)){
            
            id<IQDDDownlinkTask> downTask = (id<IQDDDownlinkTask>)[respTask task];
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode || ![[respTask resultsData] isKindOfClass:[NSDictionary class]]){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(error == nil){
                    error = @"";
                }

                [self vtDownlinkTask:downTask didFitalError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType] ];
                
            }
            else{
                
                [self vtDownlinkTask:downTask didResponse:[respTask resultsData] isCache:[downTask isAllowCached] && [downTask vtDownlinkPageTaskPageIndex] ==1 forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

-(BOOL) cancelHandle:(Protocol *)taskType task:(id<IVTTask>)task{
    
    if(taskType == @protocol(IQDDDownlinkTask)){
        
        VTAPITask * t = [[VTAPITask alloc] init];
        
        [t setTask:task];
        [t setTaskType:taskType];
        
        [self.context handle:@protocol(IVTAPICancelTask) task:t priority:0];
        
        return YES;
    }
    
    return NO;
}

-(NSString *) dataKey:(id<IVTDownlinkTask>) task forTaskType:(Protocol *) taskType{
    if(taskType == @protocol(IQDDDownlinkTask)){
        
        id<IQDDDownlinkTask> downTask = (id<IQDDDownlinkTask>)task;
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        
        [body addItemValue:[downTask taskType] forKey:@"taskType"];
        
        NSDictionary * queryValues =[downTask queryValues];
        
        for (NSString * key in queryValues) {
            
            [body addItemValue:[queryValues valueForKey:key] forKey:[NSString stringWithFormat:@"qdd-%@",key]];
            
        }
        
        return [[body bytesBody] vtMD5String];
    }
    return [super dataKey:task forTaskType:taskType];
}

@end
