//
//  QDDFeedDocumentController.h
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDFeedDocumentController : VTDocumentController<VTDataSourceDelegate>

@property(nonatomic,retain) IBOutlet VTDataSource * topLikeDataSource;

+(void) document:(VTDOMDocument *) document willLoadDataObject:(id)dataObject;

+(void) document:(VTDOMDocument *) document setLiked:(BOOL) liked dataItem:(id) dataItem context:(id) context;

@end

@protocol QDDFeedDocumentControllerDelegate <VTDocumentControllerDelegate>

@optional

-(void) feedDocumentControllerDidContentSizeChanged:(QDDFeedDocumentController *) controller;

@end