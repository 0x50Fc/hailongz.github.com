//
//  QDDUserDetailsDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserDetailsDataSource.h"

#import "QDDRefreshUserTask.h"

@implementation QDDUserDetailsDataSource

@synthesize uid = _uid;

-(void) setUid:(long long)uid{
    _uid = uid;
    [self.queryValues setValue:[NSString stringWithFormat:@"%lld",uid] forKeyPath:@"uid"];
}

-(void) vtDownlinkTaskDidLoaded:(id)data forTaskType:(Protocol *)taskType{
    [super vtDownlinkTaskDidLoaded:data forTaskType:taskType];
    
    id d = [data dataForKeyPath:self.dataKey];
    
    if([d isKindOfClass:[NSDictionary class]]){
        
        QDDRefreshUserTask * t = [[QDDRefreshUserTask alloc] init];
        
        [t setData:d];
        
        [self.context handle:@protocol(IQDDRefreshUserTask) task:t priority:0];
        
    }
}

@end
