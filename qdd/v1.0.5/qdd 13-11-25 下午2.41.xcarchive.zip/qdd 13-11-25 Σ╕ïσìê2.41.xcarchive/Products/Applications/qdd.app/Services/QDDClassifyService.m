//
//  QDDClassifyService.m
//  qdd
//
//  Created by zhang hailong on 13-11-8.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDClassifyService.h"

#import "QDDClassifyTask.h"

#import "QDDClassifyObject.h"
#import "QDDTagObject.h"

#import "QDDClassifyGetTask.h"

@interface QDDClassifyService()

@property(nonatomic,retain) NSMutableDictionary * dataObjects;

@end

@implementation QDDClassifyService

-(NSMutableDictionary *) dataObjects{
    if(_dataObjects == nil){
        _dataObjects = [[NSMutableDictionary alloc] initWithCapacity:4];
    }
    return _dataObjects;
}

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDClassifyTask)){
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDClassifyTask" forKey:@"taskType"];
        [body addItemValue:@"10" forKey:@"qdd-top"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IQDDClassifyGetTask)){
        
        id<IQDDClassifyGetTask> classifyTask = (id<IQDDClassifyGetTask>) task;
        
        NSString * key = [NSString stringWithFormat:@"%lld",[classifyTask cid]];
        
        QDDClassifyObject * dataObject = [self.dataObjects objectForKey:key];
        
        if(dataObject == nil){
            
            VTDBContext * dbContext = [(id<QDDContext>)self.context appDBContext];
            
            id<IVTSqliteCursor> cursor = [dbContext query:[QDDClassifyObject tableClass] sql:[NSString stringWithFormat:@"cid=%lld",[classifyTask cid]] data:nil];
            
            if([cursor next]){
                
                dataObject = [[QDDClassifyObject alloc] init];
                
                [cursor toDataObject:dataObject];
                
                [self.dataObjects setObject:dataObject forKey:key];
                
            }
            
            [cursor close];
        }
        
        [classifyTask setDataObject:dataObject];
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDClassifyTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode == 0){
                
                id data =[[respTask resultsData] dataForKeyPath:@"classify-results"];
                
                if([data isKindOfClass:[NSArray class]]){
                    
                    VTDBContext * dbContext = [(id<QDDContext>)self.context appDBContext];
                    
                    [[self dataObjects] removeAllObjects];
                    
                    id<IVTSqliteCursor> cursor = [dbContext query:[QDDClassifyObject tableClass] sql:@" ORDER BY cid ASC" data:nil];
                    
                    NSMutableDictionary * dataObjects = [NSMutableDictionary dictionaryWithCapacity:4];
                    
                    while([cursor next]){
                        
                        QDDClassifyObject * dataObject = [[QDDClassifyObject alloc] init];
                        
                        [cursor toDataObject:dataObject];
                        
                        NSString * key =[NSString stringWithFormat:@"%lld",dataObject.cid];
                        
                        if([dataObjects objectForKey:key]){
                            [dbContext deleteObject:dataObject];
                        }
                        else{
                            [dataObjects setObject:dataObject forKey:key];
                        }
                        
                    }
                    
                    [cursor close];
                    
                    for (id item in data) {
                        
                        long long cid = [[item dataForKeyPath:@"cid"] longLongValue];
                        
                        if(cid){
                            
                            NSString * key =[NSString stringWithFormat:@"%lld",cid];
                            
                            QDDClassifyObject * dataObject = [dataObjects objectForKey:key];
                            
                            if(dataObject){
                                dataObject.title = [item dataForKeyPath:@"title"];
                                [dbContext updateObject:dataObject];
                            }
                            else{
                                dataObject = [[QDDClassifyObject alloc] init];
                                dataObject.cid = cid;
                                dataObject.title = [item dataForKeyPath:@"title"];
                                dataObject.timestamp = [[NSDate date] timeIntervalSince1970];
                                [dbContext insertObject:dataObject];
                            }
                            
                            [self.dataObjects setObject:dataObject forKey:key];
                            
                            [dataObjects removeObjectForKey:key];
                            
                        }
                        
                    }
                    
                    for(QDDClassifyObject * dataObject in [dataObjects allValues]){
                        [dbContext deleteObject:dataObject];
                    }
                    
    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDClassifyChangedNotification object:nil];
                    
                }
                
                data =[[respTask resultsData] dataForKeyPath:@"tag-results"];
                
                if([data isKindOfClass:[NSArray class]]){

                    VTDBContext * dbContext = [(id<QDDContext>)self.context appDBContext];
                    
                    id<IVTSqliteCursor> cursor = [dbContext query:[QDDTagObject tableClass] sql:@" ORDER BY tid ASC" data:nil];
                    
                    NSMutableDictionary * dataObjects = [NSMutableDictionary dictionaryWithCapacity:4];
                    
                    while([cursor next]){
                        
                        QDDTagObject * dataObject = [[QDDTagObject alloc] init];
                        
                        [cursor toDataObject:dataObject];
                        
                        NSString * key = dataObject.tag;
                        
                        if([dataObjects objectForKey:key]){
                            [dbContext deleteObject:dataObject];
                        }
                        else{
                            [dataObjects setObject:dataObject forKey:key];
                        }
                        
                    }
                    
                    [cursor close];
                    
                    for (id item in data) {
                        
                        NSString * tag = [item dataForKeyPath:@"tag"];
                        
                        QDDTagObject * dataObject = [dataObjects objectForKey:tag];
                        
                        if(dataObject){
                            dataObject.tid = [[item dataForKeyPath:@"tid"] longLongValue];
                            [dbContext updateObject:dataObject];
                        }
                        else{
                            dataObject = [[QDDTagObject alloc] init];
                            dataObject.tid = [[item dataForKeyPath:@"tid"] longLongValue];
                            dataObject.tag = tag;
                            dataObject.timestamp = [[NSDate date] timeIntervalSince1970];
                            [dbContext insertObject:dataObject];
                        }
                        
                        
                        [dataObjects removeObjectForKey:tag];
                        
                    }

                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDClassifyChangedNotification object:nil];
                    
                }
                
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

@end
