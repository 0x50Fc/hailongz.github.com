//
//  QDDAPIService.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDAPIService.h"

#import <objc/runtime.h>

#import "IQDDAPITask.h"

@implementation QDDAPIService

    
-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IVTAPIWillRequestTask)){
        
        id<IVTAPIWillRequestTask> reqTask = (id<IVTAPIWillRequestTask>)task;
        
        if(protocol_conformsToProtocol([reqTask taskType], @protocol(IQDDAPITask)) ){
            
            VTHttpFormBody * body = [reqTask body];
            
            if(body){
                
                NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
                
                id did = [userDefaults valueForKey:@"device-did"];
                
                if(did == nil){
                    
                    UIDevice * device = [UIDevice currentDevice];
                    
                    [body addItemValue:[device vtUniqueIdentifier] forKey:@"device-unique"];
                    [body addItemValue:@"1" forKey:@"device-type"];
                    [body addItemValue:[device name] forKey:@"device-name"];
                    [body addItemValue:[device systemName] forKey:@"device-systemName"];
                    [body addItemValue:[device systemVersion] forKey:@"device-systemVersion"];
                    [body addItemValue:[device model] forKey:@"device-model"];
                    
                }
                else{
                    [body addItemValue:[NSString stringWithFormat:@"%@",did] forKey:@"device-did"];
                }
                
                id uid = [(id<QDDContext>)self.context uid];
                
                if(uid){
                    [body addItemValue:[NSString stringWithFormat:@"%@",uid] forKey:@"auth-uid"];
                }
                
                id token = [(id<QDDContext>)self.context token];
                
                if(token){
                    [body addItemValue:[NSString stringWithFormat:@"%@",token] forKey:@"auth-token"];
                }
                
                id deviceToken = [(id<QDDContext>)self.context deviceToken];
                
                if(deviceToken){
                    [body addItemValue:[NSString stringWithFormat:@"%@",deviceToken] forKey:@"device-token"];
                }
                
                NSData * bytes = [body bytesBody];
                
                NSLog(@"%@",[body contentType]);
                NSLog(@"%@",[[NSString alloc] initWithData:bytes encoding:NSUTF8StringEncoding]);
            }
        }
        
    }
    
    if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if(protocol_conformsToProtocol([respTask taskType], @protocol(IQDDAPITask)) ){
            
            NSLog(@"%@",[respTask resultsData]);
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode == 0){
                
                id did = [[respTask resultsData] dataForKeyPath:@"device-did"];
                
                if(did){
                    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
                    [userDefaults setValue:did forKey:@"device-did"];
                    [userDefaults synchronize];
                }
                
                id timestamp = [[respTask resultsData] dataForKeyPath:@"timestamp"];
                
                if(timestamp){
                    [(id<QDDContext>)self.context setTimestamp:[timestamp doubleValue]];
                }
                
                if([(id<QDDContext>)self.context uid]){
                    id token = [[respTask resultsData] dataForKeyPath:@"auth-token"];
                    if(token && ![token isEqualToString:[(id<QDDContext>)self.context token]]){
                        [(id<QDDContext>)self.context setToken:token];
                    }
                }
            }
            
            
        }
        
    }
    
    
    return NO;
}
    
@end
