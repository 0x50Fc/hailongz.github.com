//
//  QDDUserService.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserService.h"

#import "QDDUpdateUserTask.h"

#import "QDDImageUploadTask.h"

@interface QDDUserImageUploadTask : QDDImageUploadTask

@property(nonatomic,retain) id task;
@property(nonatomic,assign) Protocol * taskType;

@end

@implementation QDDUserImageUploadTask


@end

@implementation QDDUserService

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) task;
        
        if([userTask logo] == nil && [userTask logoImage]){
            
            QDDUserImageUploadTask * imageTask = [[QDDUserImageUploadTask alloc] init];
            
            [imageTask setImage:[userTask logoImage]];
            [imageTask setMaxWidth:160];
            [imageTask setTask:task];
            [imageTask setTaskType:taskType];
            [imageTask setSource:[task source]];
            [imageTask setDelegate:self];
            
            [self.context handle:@protocol(IQDDImageUploadTask) task:imageTask priority:0];
            
        }
        else{
            
            VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
            
            [httpTask setTaskType:taskType];
            [httpTask setTask:task];
            [httpTask setSource:[task source]];
            
            [httpTask setApiKey:@"url"];
            
            VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
            
            [body addItemValue:@"config_qdd" forKey:@"config"];
            [body addItemValue:@"QDDUpdateUserTask" forKey:@"taskType"];
            
            [body addItemValue:[userTask nick] forKey:@"qdd-nick"];
            [body addItemValue:[NSString stringWithFormat:@"%d",[userTask age]] forKey:@"qdd-age"];
            [body addItemValue:[userTask logo] forKey:@"qdd-logo"];
            [body addItemValue:[userTask constellation] forKey:@"qdd-constellation"];
            [body addItemValue:[userTask job] forKey:@"qdd-job"];
            [body addItemValue:[userTask city] forKey:@"qdd-city"];
            
            [httpTask setBody:body];
            
            [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
            
        }
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IVTUplinkTask> uplinkTask = (id<IVTUplinkTask>)[respTask task];
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(error == nil){
                    error = @"";
                }
                
                [self vtUplinkTask:uplinkTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
                
            }
            else{
                
                id user = [[respTask resultsData] dataForKeyPath:@"user-results"];
                
                if(user){
                    [(id<QDDContext>)self.context setNick:[user dataForKeyPath:@"nick"]];
                    [(id<QDDContext>)self.context setUserInfo:user];
                }
                
                [self vtUplinkTask:uplinkTask didSuccessResults:[respTask resultsData]
                       forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
        
    }
    
    return NO;
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDUserImageUploadTask * imageTask = (QDDUserImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) [imageTask task];
            
            [self vtUploadTask:userTask didFailWithError:error forTaskType:@protocol(IQDDUpdateUserTask)];
            
        }
 
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDUserImageUploadTask * imageTask = (QDDUserImageUploadTask *) uplinkTask;
        
        if([imageTask taskType] == @protocol(IQDDUpdateUserTask)){
            
            id<IQDDUpdateUserTask> userTask = (id<IQDDUpdateUserTask>) [imageTask task];
            
            [userTask setLogo:[results valueForKey:@"uri"]];
            
            if([userTask logo] == nil){
                
                [self vtUploadTask:userTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:0 userInfo:[NSDictionary dictionaryWithObject:@"上传头像失败" forKey:NSLocalizedDescriptionKey]] forTaskType:@protocol(IQDDUpdateUserTask) ];

            }
            else {
                
                [self handle:@protocol(IQDDUpdateUserTask) task:userTask priority:0];
                
            }
            
        }
        
    }
    
}

@end
