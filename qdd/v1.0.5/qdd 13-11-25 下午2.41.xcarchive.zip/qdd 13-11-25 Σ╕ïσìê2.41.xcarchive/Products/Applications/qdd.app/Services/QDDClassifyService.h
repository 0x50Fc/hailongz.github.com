//
//  QDDClassifyService.h
//  qdd
//
//  Created by zhang hailong on 13-11-8.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDClassifyService : VTUplinkService

@end
