//
//  QDDUnFollowTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUnFollowTask.h"

@implementation QDDUnFollowTask

@synthesize tuid = _tuid;

@end
