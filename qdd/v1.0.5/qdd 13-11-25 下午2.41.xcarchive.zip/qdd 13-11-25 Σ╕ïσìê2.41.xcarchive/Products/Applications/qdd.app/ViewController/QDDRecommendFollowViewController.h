//
//  QDDRecommendFollowViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDRecommendFollowViewController : QDDViewController
@property (strong, nonatomic) IBOutlet VTTableDataController *dataController;

@end
