//
//  QDDUnLikeTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-13.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDUnLikeTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) long long pid;

@end

@interface QDDUnLikeTask : VTUplinkTask<IQDDUnLikeTask>

@property(nonatomic,retain) NSIndexPath * indexPath;

@end
