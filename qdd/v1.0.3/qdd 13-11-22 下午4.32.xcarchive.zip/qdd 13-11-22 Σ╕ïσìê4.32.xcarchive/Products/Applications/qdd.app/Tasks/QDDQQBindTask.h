//
//  QDDQQBindTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-19.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"


@protocol IQDDQQBindTask <IQDDAPITask,IVTUplinkTaskDelegate>

@property(nonatomic,retain) NSString * token;
@property(nonatomic,assign) NSTimeInterval expires_in;

@end

@interface QDDQQBindTask : VTUplinkTask<IQDDQQBindTask>

@end
