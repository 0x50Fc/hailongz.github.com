//
//  QDDWeiboLoginTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDWeiboLoginTask <IQDDAPITask,IVTUplinkTaskDelegate>

@property(nonatomic,retain) NSString * token;
@property(nonatomic,assign) NSTimeInterval expires_in;

@end

@interface QDDWeiboLoginTask : VTUplinkTask<IQDDWeiboLoginTask>

@end
