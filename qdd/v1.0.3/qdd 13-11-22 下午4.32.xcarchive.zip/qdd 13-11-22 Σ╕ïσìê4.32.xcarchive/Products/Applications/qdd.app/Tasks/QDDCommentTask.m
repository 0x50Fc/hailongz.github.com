//
//  QDDCommentTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDCommentTask.h"

@implementation QDDCommentTask

@synthesize body = _body;
@synthesize publishId = _publishId;
@synthesize commentId = _commentId;

@end
