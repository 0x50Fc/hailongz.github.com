//
//  QDDFeedDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFeedDetailsViewController.h"

@interface QDDFeedDetailsViewController ()

@end

@implementation QDDFeedDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSDictionary * queryValues = [self.url queryValues];
    
    id dataItem = [self.context focusValueForKey:@"feed"];
    
    [dataItem removeObjectForKey:@"__document__"];
    [_documentController setDataItem:dataItem];
    [_documentController setAllowAutoHeight:YES];
    
    [_documentController.topLikeDataSource setValue:[queryValues valueForKey:@"pid"] forKey:@"pid"];
    
    [_documentController reloadData];
    
    CGSize size = [_documentController contentSize];
    
    CGRect r = [_detailsTableViewCell frame];
    
    r.size.height = size.height - 20;
    
    [_detailsTableViewCell setFrame:r];
    
    [_commentListController.dataSource setValue:[queryValues valueForKey:@"pid"] forKey:@"pid"];
    
    [_commentListController reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction) doCommentAction:(id)sender{
    
    [self.context waitResultsData:^(id resultsData) {
        
        if([resultsData boolValue]){
            [_documentController addCommentCount];
            [_commentListController reloadData];
        }
    }];
    
    [self openUrl:[NSURL URLWithString:@"pop:///publish-comment"
                           queryValues:self.url.queryValues] animated:YES];
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"reply"]){
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:4];
        
        [queryValues setValue:[element attributeValueForKey:@"cid"] forKey:@"cid"];
        [queryValues setValue:[NSString stringWithFormat:@"回复: %@",[element attributeValueForKey:@"nick"]] forKey:@"title"];
        
        [self openUrl:[NSURL URLWithString:@"pop:///publish-comment"
                               queryValues:queryValues] animated:YES];
    }
    else if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [queryValues setValue:uid forKey:@"uid"];
        
        [self openUrl:[NSURL URLWithString:@"feed-details/user-details" relativeToURL:self.url queryValues:queryValues] animated:YES];
        
    }
    
}

-(void) vtDocumentController:(VTDocumentController *) controller doActionElement:(VTDOMElement *) element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [queryValues setValue:uid forKey:@"uid"];
        
        [self openUrl:[NSURL URLWithString:@"feed-details/user-details" relativeToURL:self.url queryValues:queryValues] animated:YES];
        
    }

    
}

-(void) feedDocumentControllerDidContentSizeChanged:(QDDFeedDocumentController *) controller{
    
    [controller documentLayout];
    
    CGSize size = [_documentController contentSize];
    
    CGRect r = [_detailsTableViewCell frame];
    
    r.size.height = size.height - 20;
    
    [_detailsTableViewCell setFrame:r];

    [_commentListController.tableView reloadData];
}

@end
