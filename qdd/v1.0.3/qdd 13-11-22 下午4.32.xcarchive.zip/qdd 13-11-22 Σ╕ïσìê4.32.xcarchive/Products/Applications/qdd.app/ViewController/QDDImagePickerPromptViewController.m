//
//  QDDImagePickerPromptViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDImagePickerPromptViewController.h"

#import "QDDKeyButton.h"

@interface QDDImagePickerPromptViewController ()

@end

@implementation QDDImagePickerPromptViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doKeyAction:(id)sender {
    
    NSString * inputKey = [(QDDKeyButton *)sender inputKey];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [(id)self.context setResultsData:inputKey];
    });
    
    
    [[VTPopWindow topPopWindow] closeAnimated:NO];
    
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.view.alpha = 0.0f;
    
    [UIView animateWithDuration:0.3 animations:^{
        
        self.view.alpha = 1.0f;
        
        CGRect r = [_contentView frame];
        r.origin.y = self.view.bounds.size.height - r.size.height;
        [_contentView setFrame:r];
        
    }];
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

    
}

@end
