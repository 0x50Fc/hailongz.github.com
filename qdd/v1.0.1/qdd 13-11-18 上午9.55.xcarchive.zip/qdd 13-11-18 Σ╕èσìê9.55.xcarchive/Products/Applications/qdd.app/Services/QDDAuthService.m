//
//  QDDAuthService.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDAuthService.h"

#import "QDDAuthTask.h"

#import "QDDRegisterTask.h"

#import "QDDLoginTask.h"

#import "QDDWeiboLoginTask.h"

#import "QDDQQLoginTask.h"

#import "QDDLogoutTask.h"

@implementation QDDAuthService

    
-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDAuthTask)){

        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDLoginTask" forKey:@"taskType"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IQDDRegisterTask)){
        
        id<IQDDRegisterTask> regTask = (id<IQDDRegisterTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDRegisterTask" forKey:@"taskType"];
        
        [body addItemValue:[regTask account] forKey:@"qdd-account"];
        [body addItemValue:[regTask password] forKey:@"qdd-password"];
        [body addItemValue:[regTask nick] forKey:@"qdd-nick"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];

        
        return YES;
    }
    else if(taskType == @protocol(IQDDWeiboLoginTask)){

        id<IQDDWeiboLoginTask> loginTask = (id<IQDDWeiboLoginTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDWeiboLoginTask" forKey:@"taskType"];
        
        [body addItemValue:[loginTask token] forKey:@"qdd-token"];
        [body addItemValue:[NSString stringWithFormat:@"%d",(int)[loginTask expires_in]] forKey:@"qdd-expires_in"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        

        return YES;
    }
    else if(taskType == @protocol(IQDDQQLoginTask)){
        
        id<IQDDQQLoginTask> loginTask = (id<IQDDQQLoginTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDQQLoginTask" forKey:@"taskType"];
        
        [body addItemValue:[loginTask token] forKey:@"qdd-token"];
        [body addItemValue:[NSString stringWithFormat:@"%d",(int)[loginTask expires_in]] forKey:@"qdd-expires_in"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        
        return YES;
    }
    else if(taskType == @protocol(IQDDLoginTask)){
        
        id<IQDDLoginTask> loginTask = (id<IQDDLoginTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDLoginTask" forKey:@"taskType"];
        
        [body addItemValue:[loginTask account] forKey:@"auth-account"];
        [body addItemValue:[loginTask password] forKey:@"auth-password"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        
        return YES;
    }
    else if(taskType == @protocol(IQDDLogoutTask)){
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"AppAuthRemoveTask" forKey:@"taskType"];
 
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDRegisterTask)
           || [respTask taskType] == @protocol(IQDDLoginTask)
           || [respTask taskType] == @protocol(IQDDAuthTask)
           || [respTask taskType] == @protocol(IQDDWeiboLoginTask)
           || [respTask taskType] == @protocol(IQDDQQLoginTask)
           ){
            
            id<IVTUplinkTask> uplinkTask = (id<IVTUplinkTask>)[respTask task];
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(error == nil){
                    error = @"";
                }
                
                [self vtUplinkTask:uplinkTask didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
                 
            }
            else{
                
                id uid = [[respTask resultsData] dataForKeyPath:@"auth"];
                
                NSString * token = [[respTask resultsData] dataForKeyPath:@"auth-token"];
                
                if(uid && token){

                    [(id<QDDContext>)self.context setAccount:[[respTask resultsData] dataForKeyPath:@"user.account"]];
                    [(id<QDDContext>)self.context setNick:[[respTask resultsData] dataForKeyPath:@"user.nick"]];
                    [(id<QDDContext>)self.context setUserInfo:[[respTask resultsData] dataForKeyPath:@"user"]];
                    
                    [(id<QDDContext>)self.context setWeiboToken:[[respTask resultsData] dataForKeyPath:@"auth-bind.weibo.token"]];
                    [(id<QDDContext>)self.context setQqToken:[[respTask resultsData] dataForKeyPath:@"auth-bind.qq.token"]];
                    
                    [(id<QDDContext>)self.context setAuth:uid token:token];
                    
                }
                
                [self vtUplinkTask:uplinkTask didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        else if([respTask taskType] == @protocol(IQDDLogoutTask)){
            
        
            
            return YES;
        }
        
    }

    return NO;
}
    
@end
