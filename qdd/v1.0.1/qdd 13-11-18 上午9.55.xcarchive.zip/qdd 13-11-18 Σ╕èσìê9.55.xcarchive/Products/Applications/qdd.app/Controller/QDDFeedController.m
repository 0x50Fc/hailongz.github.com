//
//  QDDFeedController.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFeedController.h"

#import "QDDLikeTask.h"
#import "QDDUnLikeTask.h"

#import <vTeam/VTDOMElement+Render.h>

@implementation QDDFeedController


-(void) document:(VTDOMDocument *) document willLoadDataObject:(id)dataObject{
    
    VTDOMElement * element = [document elementById:@"images"];
    
    if(element && [element valueForKey:@"images"] == nil){
        
        [element setValue:[dataObject dataForKeyPath:@"images"] forKey:@"images"];
        
    }
    
    element = [document elementById:@"tags"];
    
    if(element && [element valueForKey:@"tags"] == nil){
        
        id tags = [dataObject dataForKeyPath:@"tags"];
        
        NSInteger index = 0;
    
        for (id tag in tags) {
            
            NSString * text = [tag isKindOfClass:[NSString class]] ? tag : [tag dataForKeyPath:@"tag"];
            
            VTDOMImageElement * image = [[VTDOMImageElement alloc] init];
            
            [image setSrc:@"ico33.png"];
            [image setAttributeValue:@"auto" forKey:@"width"];
            [image setAttributeValue:@"auto" forKey:@"height"];
            [image setAttributeValue:@"tag-image" forKey:@"class"];
            
            [element addElement:image];
            
            VTDOMLabelElement * label = [[VTDOMLabelElement alloc] init];
            
            [label setText:text];
            [label setAttributeValue:@"auto" forKey:@"width"];
            [label setAttributeValue:@"auto" forKey:@"height"];
            [label setAttributeValue:@"tag-label" forKey:@"class"];
            
            [element addElement:label];
            
            index ++;
            
            if(index >=6){
                break;
            }
        }

       
        
        [element setValue:tags forKey:@"tags"];
        
    }
    
    element = [document elementById:@"liked-img"];
    
    if(element && [element valueForKey:@"liked"] == nil){
        
        if([[dataObject valueForKey:@"liked"] boolValue]){
            [element setAttributeValue:@"ico40.png" forKey:@"src"];
        }
        else{
            [element setAttributeValue:@"ico36.png" forKey:@"src"];
        }
        
        
        [element setValue:@"liked" forKey:@"liked"];
    }
    
    element = [document elementById:@"money"];
    
    if(element ){
       
        double payMoney = [[dataObject dataForKeyPath:@"payMoney"] doubleValue];
        double expendMoney = [[dataObject dataForKeyPath:@"expendMoney"] doubleValue];
        
        if(payMoney){
            
            VTDOMLabelElement * label = [[VTDOMLabelElement alloc] init];
            
            [label setText:@"省¥"];
            [label setAttributeValue:@"auto" forKey:@"width"];
            [label setAttributeValue:@"auto" forKey:@"height"];
            [label setAttributeValue:@"money-title" forKey:@"class"];
            
            [element addElement:label];

            label = [[VTDOMLabelElement alloc] init];
            
            NSNumberFormatter *numFormat = [[NSNumberFormatter alloc] init];
            
            [numFormat setPositiveFormat:@"###,##0.##"];
            
            [label setText:[numFormat stringFromNumber:[NSNumber numberWithDouble:payMoney - expendMoney]]];
            [label setAttributeValue:@"auto" forKey:@"width"];
            [label setAttributeValue:@"auto" forKey:@"height"];
            [label setAttributeValue:@"money-number" forKey:@"class"];
            
            [element addElement:label];
            
        }
       
    }

}

-(void) vtDOMView:(VTDOMView *)view doActionElement:(VTDOMElement *)element{
    
    if([element conformsToProtocol:@protocol(IVTAction)]) {
        
        NSString * actionName = [(id<IVTAction>)element actionName];
        
        if([actionName isEqualToString:@"like"]){
            
            UITableViewCell * cell = (UITableViewCell *) [view superview];
            
            while(cell && ![cell isKindOfClass:[UITableViewCell class]]){
                
                cell = (UITableViewCell *) [cell superview];
            }
            
            NSIndexPath * indexPath = [self.tableView indexPathForCell:cell];
            
            if(indexPath){
                
                id dataItem = [self dataObjectByIndexPath:indexPath];
                
                BOOL liked = [[dataItem valueForKey:@"liked"] boolValue];
                
                if(liked){
                    
                    QDDUnLikeTask * task = [[QDDUnLikeTask alloc] init];
                    
                    [task setIndexPath:indexPath];
                    [task setPid:[[dataItem valueForKey:@"pid"] longLongValue]];
                    
                    [self.context handle:@protocol(IQDDUnLikeTask) task:task priority:0];
                    
                    [dataItem setValue:[NSNumber numberWithInt:[[dataItem valueForKey:@"likedCount"] intValue] -1] forKey:@"likedCount"];
                }
                else{
                    
                    QDDLikeTask * task = [[QDDLikeTask alloc] init];
                    
                    [task setIndexPath:indexPath];
                    [task setPid:[[dataItem valueForKey:@"pid"] longLongValue]];
                    
                    [self.context handle:@protocol(IQDDLikeTask) task:task priority:0];
                    
                    [dataItem setValue:[NSNumber numberWithInt:[[dataItem valueForKey:@"likedCount"] intValue] +1] forKey:@"likedCount"];
                }
                
                [dataItem setValue:[NSNumber numberWithBool:!liked] forKey:@"liked"];
   
                VTDOMDocument * document = [self documentByIndexPath:indexPath];
                
                VTDOMElement * element = [document elementById:@"liked-img"];
                
                if(element){

                    if(!liked){
                        [element performSelector:@selector(setSrc:) withObject:@"ico40.png"];
                    }
                    else{
                        [element performSelector:@selector(setSrc:) withObject:@"ico36.png"];
                    }
                    
                    [self.context handle:@protocol(IVTLocalImageTask) task:(id<IVTLocalImageTask>)element priority:0];
                    
                    [element setNeedDisplay];
                }
                
                element = [document elementById:@"liked-label"];
                
                if(element){
                    
                    [element setText:[NSString stringWithFormat:@"%@",[dataItem valueForKey:@"likedCount"]]];
                    
                    [element setNeedDisplay];
                }
                
            }
        }
        
    }
    
    [super vtDOMView:view doActionElement:element];
}

@end
