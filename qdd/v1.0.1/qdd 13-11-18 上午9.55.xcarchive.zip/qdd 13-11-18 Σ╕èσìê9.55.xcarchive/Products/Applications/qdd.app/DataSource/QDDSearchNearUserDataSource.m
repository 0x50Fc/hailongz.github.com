//
//  QDDSearchNearUserDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDSearchNearUserDataSource.h"

@implementation QDDSearchNearUserDataSource

@synthesize location = _location;

-(double) latitude{
    return [[self.queryValues valueForKey:@"latitude"] doubleValue];
}

-(void) setLatitude:(double)latitude{
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",latitude] forKey:@"latitude"];
}

-(double) longitude{
    return [[self.queryValues valueForKey:@"longitude"] doubleValue];
}

-(void) setLongitude:(double)longitude{
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",longitude] forKey:@"longitude"];
}

-(void) setLocation:(CLLocation *)location{
    
    _location = location;
    
    self.latitude = _location.coordinate.latitude;
    self.longitude = _location.coordinate.longitude;
    
}

@end
