//
//  QDDMenuViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-4.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDMenuViewController : QDDViewController<UIActionSheetDelegate>
@property (strong, nonatomic) IBOutlet VTImageView *imageView;
    
- (IBAction)logoutAction:(id)sender;

@end
