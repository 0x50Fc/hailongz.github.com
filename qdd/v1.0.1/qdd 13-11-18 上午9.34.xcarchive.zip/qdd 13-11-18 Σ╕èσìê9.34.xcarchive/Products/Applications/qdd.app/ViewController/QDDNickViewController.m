//
//  QDDNickViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDNickViewController.h"

#import "QDDUpdateUserTask.h"

@interface QDDNickViewController ()

@end

@implementation QDDNickViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIPanGestureRecognizer * panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureRecognizerAction:)];
    
    [self.view addGestureRecognizer:panGestureRecognizer];
    
    NSString * title = [[(id<QDDContext>)self.context userInfo] dataForKeyPath:@"title"];
    
    if(![title hasPrefix:@"#"]){
        [_nickField setText:title];
    }
}

-(void) panGestureRecognizerAction:(UIPanGestureRecognizer *) gestureRecognizer{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doLogoutAction:(id)sender {
    
    [(id<QDDContext>)self.context logout:YES];
    
}

- (IBAction)doSubmitAction:(id)sender {
    
    NSString * nick = [[_nickField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSInteger len = [nick textLength];
    
    if(len == 0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入昵称" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if(len < 4 ){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"昵称至少4个字符,或2个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    if(len > 24 ){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"昵称最多24个字符,或12个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
        
        return;
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDUpdateUserTask * task = [[QDDUpdateUserTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setNick:nick];
    
    [self.context handle:@protocol(IQDDUpdateUserTask) task:task priority:0];

}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == _nickField){
        
        [self performSelector:@selector(doSubmitAction:) withObject:textField afterDelay:0.0];
    }
    
    return YES;
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        
        [alertView show];
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    
    if(taskType == @protocol(IQDDUpdateUserTask)){
        
        [_statusView setStatus:nil];
        [_statusView setUserInteractionEnabled:YES];
        
        [(id<QDDContext>)self.context toRootViewController:YES];
        
    }
    
}

@end
