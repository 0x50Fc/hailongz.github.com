//
//  QDDMyViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDMyViewController : QDDViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,IVTUplinkTaskDelegate>
@property (strong, nonatomic) IBOutlet VTImageView *imageView;
@property (strong, nonatomic) IBOutlet UITextField * nickTextField;
@property(strong,nonatomic) IBOutlet VTStatusView * statusView;

- (IBAction)doLogoAction:(id)sender;

- (IBAction)doSaveAction:(id)sender;

@end
