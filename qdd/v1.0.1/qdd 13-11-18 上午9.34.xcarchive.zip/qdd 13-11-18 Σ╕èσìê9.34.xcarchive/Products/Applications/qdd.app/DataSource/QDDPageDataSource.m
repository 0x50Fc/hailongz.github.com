//
//  QDDPageDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPageDataSource.h"

@implementation QDDPageDataSource

@synthesize queryValues = _queryValues;
@synthesize allowCached = _allowCached;
@synthesize taskType = _taskType;

-(NSMutableDictionary *) queryValues{
    if(_queryValues == nil){
        _queryValues = [[NSMutableDictionary alloc] init];
    }
    return _queryValues;
}

-(void) setPageIndex:(NSInteger)pageIndex{
    [super setPageIndex:pageIndex];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageIndex] forKey:@"pageIndex"];
}

-(void) setPageSize:(NSInteger)pageSize{
    [super setPageSize:pageSize];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
}

-(void) dealloc{
    
    [self.context cancelHandle:@protocol(IQDDDownlinkTask) task:self];
    
}

-(void) reloadData{
    [super reloadData];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
    
}

-(void) loadMoreData{
    [super loadMoreData];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
}

-(void) cancel{
    [super cancel];
    
    [self.context cancelHandle:@protocol(IQDDDownlinkTask) task:self];
}


@end
