//
//  QDDPageDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDDownlinkTask.h"

@interface QDDPageDataSource : VTPageDataSource<IQDDDownlinkTask>

@property(nonatomic,retain) NSString * taskType;

@end
