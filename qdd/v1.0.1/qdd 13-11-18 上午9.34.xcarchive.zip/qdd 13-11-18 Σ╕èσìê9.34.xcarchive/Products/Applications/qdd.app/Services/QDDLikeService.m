//
//  QDDLikeService.m
//  qdd
//
//  Created by zhang hailong on 13-11-13.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDLikeService.h"

#import "QDDLikeTask.h"
#import "QDDUnLikeTask.h"

@implementation QDDLikeService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(@protocol(IQDDLikeTask) == taskType){
        
        id<IQDDLikeTask> likeTask = (id<IQDDLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[likeTask pid]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDUnLikeTask) == taskType){
        
        id<IQDDUnLikeTask> likeTask = (id<IQDDUnLikeTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDUnLikeTask" forKey:@"taskType"];
        [body addItemValue:[NSString stringWithFormat:@"%lld",[likeTask pid]] forKey:@"qdd-pid"];
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IVTAPIResponseTask) == taskType){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDLikeTask) || [respTask taskType] == @protocol(IQDDUnLikeTask)){
            
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

@end
