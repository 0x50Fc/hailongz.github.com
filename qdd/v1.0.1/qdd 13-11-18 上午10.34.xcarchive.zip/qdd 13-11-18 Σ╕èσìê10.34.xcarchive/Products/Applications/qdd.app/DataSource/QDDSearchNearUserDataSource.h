//
//  QDDSearchNearUserDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPageDataSource.h"

@interface QDDSearchNearUserDataSource : QDDPageDataSource

@property(nonatomic,retain) CLLocation * location;
@property(nonatomic,assign) double latitude;
@property(nonatomic,assign) double longitude;

@end
