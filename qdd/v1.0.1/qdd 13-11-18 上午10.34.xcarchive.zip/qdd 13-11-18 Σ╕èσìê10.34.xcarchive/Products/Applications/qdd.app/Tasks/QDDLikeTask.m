//
//  QDDLikeTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-13.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDLikeTask.h"

@implementation QDDLikeTask

@synthesize pid = _pid;
@synthesize indexPath = _indexPath;

@end
