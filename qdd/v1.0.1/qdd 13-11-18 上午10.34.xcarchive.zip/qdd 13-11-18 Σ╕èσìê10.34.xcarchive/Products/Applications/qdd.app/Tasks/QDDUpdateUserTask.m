//
//  QDDUpdateUserTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-10.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUpdateUserTask.h"

@implementation QDDUpdateUserTask

@synthesize nick = _nick;
@synthesize logo = _logo;
@synthesize logoImage = _logoImage;
@synthesize age = _age;
@synthesize classifyObjects = _classifyObjects;
@synthesize constellation = _constellation;
@synthesize job = _job;
@synthesize city = _city;
@end
