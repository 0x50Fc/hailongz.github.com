//
//  QDDRegisterViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDRegisterViewController.h"

#import "QDDRegisterTask.h"

@interface QDDRegisterViewController ()

@end

@implementation QDDRegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)doCommitAction:(id)sender {
    
    NSString * account = [[_accountField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString * password = [_passwordField text];
    
    NSString * nick = [[_nickField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([account length] == 0){
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入登录名" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    if([password length] <6 ){
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"密码最少6位" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    if([nick textLength] <4 || [nick textLength] > 24){
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"昵称应在4~24个字符间" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    QDDRegisterTask * task = [[QDDRegisterTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    [task setAccount:account];
    [task setPassword:password];
    [task setNick:nick];
    
    [self.context handle:@protocol(IQDDRegisterTask) task:task priority:0];
    
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == _accountField){
        
        [_passwordField becomeFirstResponder];
    }
    else if(textField == _passwordField){
        
        [_nickField becomeFirstResponder];
    }
    else if(textField == _nickField){
        
        [textField resignFirstResponder];
    }
    
    return YES;
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    [_statusView setUserInteractionEnabled:YES];
    [_statusView setStatus:nil];
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];
    
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    [_statusView setUserInteractionEnabled:YES];
    [_statusView setStatus:nil];
    
    [self openUrl:[NSURL URLWithString:[NSString stringWithFormat:@"%@/recommend-follow",self.alias] relativeToURL:self.url] animated:YES];
}

@end
