//
//  QDDPublishFeedViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishFeedViewController.h"

@interface QDDPublishFeedViewController ()

@end

@implementation QDDPublishFeedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) publishController:(QDDPublishController *) controller didFailWithError:(NSError *) error{
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];
    
}

-(void) publishController:(QDDPublishController *) controller didSuccessResults:(id) results{
    
    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"发布成功"];
    
    [alertView showDuration:1.2];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:QDDPublishFeedNotification object:nil];
    
    [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
    
}


@end
