//
//  QDDBindViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBindViewController.h"

@interface QDDBindViewController ()

@end

@implementation QDDBindViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadData) name:QDDBindChangedNotification object:nil];
    
    [self reloadData];
}

-(void) viewDidUnload{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDBindChangedNotification object:nil];
    
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDBindChangedNotification object:nil];
    
}

-(void) reloadData{
    
    NSMutableArray * bindCells = [NSMutableArray arrayWithCapacity:2];
    NSMutableArray * unbindCells = [NSMutableArray arrayWithCapacity:2];
    
    id<QDDContext> ctx = (id<QDDContext>)self.context;
    
    if([ctx weiboToken]){
        
        [bindCells addObject:_bindWeiboCell];
        
        [_enabledWeiboButton setEnabled:[ctx disabledWeibo]];
        [_disabledWeiboButton setEnabled:![ctx disabledWeibo]];
        
    }
    else{
        [unbindCells addObject:_unbindWeiboCell];
    }
    
    if([ctx qqToken]){
        
        [bindCells addObject:_bindQQCell];
        
        [_enabledQQButton setEnabled:[ctx disabledQQ]];
        [_disabledQQButton setEnabled:![ctx disabledQQ]];
        
    }
    else{
        [unbindCells addObject:_unbindQQCell];
    }
    
    NSMutableArray * sections = [NSMutableArray arrayWithCapacity:2];
    
    if([bindCells count]){
        
        VTTableSection * section = [[VTTableSection alloc] init];
        
        [section setView:_bindView];
        
        [section setCells:bindCells];
        
        [sections addObject:section];
        
    }
 
    if([unbindCells count]){
        
        VTTableSection * section = [[VTTableSection alloc] init];
        
        [section setView:_unbindView];
        
        [section setCells:unbindCells];
        
        [sections addObject:section];
        
    }
    
    [_tableSource setSections:sections];
    
    [_tableView reloadData];
}

- (IBAction)onEnabledAction:(id)sender {
    
    id<QDDContext> ctx = (id<QDDContext>)self.context;
    
    if(_enabledWeiboButton == sender){
        [ctx setDisabledWeibo:NO];
    }
    else if(_disabledWeiboButton == sender){
        [ctx setDisabledWeibo:YES];
    }
    else if(_enabledQQButton == sender){
        [ctx setDisabledQQ:NO];
    }
    else if(_disabledQQButton == sender){
        [ctx setDisabledQQ:YES];
    }
    
    [self reloadData];
}

- (IBAction)bindWeiboAction:(id)sender {
    
    [(id<QDDContext>)self.context weiboLogin];
    
}

- (IBAction)bindQQAction:(id)sender {
    
    [(id<QDDContext>)self.context qqLogin];
    
}

@end
