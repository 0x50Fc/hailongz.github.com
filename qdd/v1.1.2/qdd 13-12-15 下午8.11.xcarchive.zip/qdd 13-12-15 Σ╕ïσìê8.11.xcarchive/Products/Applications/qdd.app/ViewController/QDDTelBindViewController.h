//
//  QDDTelBindViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDTelBindViewController : QDDViewController<UITextFieldDelegate,IVTUplinkTaskDelegate>

@property (strong, nonatomic) IBOutlet UITextField *telField;
@property (strong, nonatomic) IBOutlet UITextField *verifyField;
@property (strong, nonatomic) IBOutlet UIButton *verifyButton;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;

- (IBAction)doVerifyAction:(id)sender;
- (IBAction)doSubmitAction:(id)sender;

@end
