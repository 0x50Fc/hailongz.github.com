//
//  QDDInviteViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-25.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteViewController.h"

#import "QDDFollowTask.h"

@interface QDDInviteViewController ()

@end

@implementation QDDInviteViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [self.context waitResultsData:nil];
    
}
-(void) textFieldDidBeginEditing:(UITextField *)textField{
    
    if(_textField == textField){
        [_contentView setHidden:NO animated:YES];
    }
}

-(void) textFieldDidEndEditing:(UITextField *)textField{
    
    if(_textField == textField){
        
        NSString * keyword = [[_textField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        if([keyword length]){
            [_contentView setHidden:NO animated:YES];
        }
        else{
            [_contentView setHidden:YES animated:YES];
        }
        
    }
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == _textField){
        
        [_textField resignFirstResponder];
        
        [self doSearchAction:nil];
        
    }
    
    return YES;
}

-(IBAction) doSearchAction:(id)sender{
    
    NSString * keyword = [[_textField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([keyword length]){
        [_contentView setHidden:NO animated:YES];
        
        [_dataController cancel];
        [_dataController.dataSource setValue:keyword forKey:@"keyword"];
        
        [_dataController reloadData];
        
    }
    else{
        [_contentView setHidden:YES animated:YES];
        [_textField resignFirstResponder];
    }
    
}

- (IBAction)doContactAction:(id)sender {
    
    if([(id<QDDContext>)self.context tel]){
        
        [self openUrl:[NSURL URLWithString:@"invite/invite-contact"
                             relativeToURL:self.url] animated:YES];
        
    }
    else{
        
        [self.context waitResultsData:^(id resultsData) {
            [self openUrl:[NSURL URLWithString:@"invite/invite-contact"
                                 relativeToURL:self.url] animated:YES];
        }];
        
        [self openUrl:[NSURL URLWithString:@"invite/tel-bind"
                             relativeToURL:self.url] animated:YES];
    }
    
}

- (IBAction)doWeiboAction:(id)sender {
    
    if([(id<QDDContext>) self.context weiboToken]){
        
        [self openUrl:[NSURL URLWithString:@"invite/invite-weibo"
                             relativeToURL:self.url] animated:YES];
        
    }
    else{
        
        [self.context waitResultsData:^(id resultsData) {
        
            [self openUrl:[NSURL URLWithString:@"invite/invite-weibo"
                                 relativeToURL:self.url] animated:YES];
            
        }];
        
        [(id<QDDContext>) self.context weiboLogin];
    }
}

- (IBAction)doQQAction:(id)sender {
    
    if([(id<QDDContext>) self.context qqToken]){
        
        [self openUrl:[NSURL URLWithString:@"invite/invite-qq"
                             relativeToURL:self.url] animated:YES];
        
    }
    else{
        
        [self.context waitResultsData:^(id resultsData) {
            
            [self openUrl:[NSURL URLWithString:@"invite/invite-qq"
                                 relativeToURL:self.url] animated:YES];
            
        }];
        
        [(id<QDDContext>) self.context qqLogin];
    }
    
}


-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"follow"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        if(uid){
            
            QDDFollowTask * task = [[QDDFollowTask alloc] init];
            
            [task setTuid:[uid longLongValue]];
            
            [self.context handle:@protocol(IQDDFollowTask) task:task priority:0];
            
            if([element isKindOfClass:[VTDOMViewElement class]]){
                
                UIButton * button = (UIButton *) [(VTDOMViewElement *) element view];
                
                if([button isKindOfClass:[UIButton class]]){
                    
                    [button setHidden:YES];
                    [element setAttributeValue:@"1" forKey:@"hidden"];
                    
                    VTDOMElement * el = [element.document elementById:@"followLabel"];
                    
                    if(el){
                        [el setAttributeValue:@"1" forKey:@"visable"];
                        [el setNeedDisplay];
                    }
                    
                    UITableViewCell * cell = (UITableViewCell *) [button superview];
                    
                    while(cell && ![cell isKindOfClass:[UITableViewCell class]]){
                        
                        cell = (UITableViewCell *) [cell superview];
                    }
                    
                    NSIndexPath * indexPath = [dataController.tableView indexPathForCell:cell];
                    
                    if(indexPath){
                        
                        id dataItem = [dataController dataObjectByIndexPath:indexPath];
                        
                        [dataItem setValue:@"1" forKey:@"isFollow"];
                        
                    }
                    
                }
                
            }
            
        }
        
    }
    else if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        NSString * nick = [element attributeValueForKey:@"nick"];
        
        if(uid && nick){
            
            [self openUrl:[NSURL URLWithString:@"invite/user-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObjectsAndKeys:uid,@"uid",nick,@"nick", nil]] animated:YES];
            
        }
        
    }
    
}

@end
