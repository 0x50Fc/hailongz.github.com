//
//  QDDMessageViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDMessageViewController : QDDViewController<VTDocumentDataControllerDelegate>

@property (strong, nonatomic) IBOutlet VTDocumentDataController *dataController;

- (IBAction)doCreateAction:(id)sender;

@end
