//
//  QDDMessageViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMessageViewController.h"

@interface QDDMessageViewController ()

@end

@implementation QDDMessageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![_dataController.dataSource isLoaded]
       && ![_dataController.dataSource isLoading]){
        [_dataController reloadData];
    }
}

- (IBAction)doCreateAction:(id)sender {

    [self.context waitResultsData:^(id resultsData) {
        
        [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/message/session" relativeToURL:self.url queryValues:resultsData ] animated:YES];
        
    }];
    
    [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/message/user-selector" relativeToURL:self.url] animated:YES];
    
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"session"]){
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [queryValues setValue:[element attributeValueForKey:@"uid"] forKey:@"uid"];
        [queryValues setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/message/session" relativeToURL:self.url queryValues:queryValues ] animated:YES];
        
    }
    
}

@end
