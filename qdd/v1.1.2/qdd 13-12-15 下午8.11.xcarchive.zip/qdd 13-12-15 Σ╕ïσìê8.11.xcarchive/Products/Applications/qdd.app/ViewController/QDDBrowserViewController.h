//
//  QDDBrowserViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDBrowserViewController : QDDViewController<UIWebViewDelegate>

@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) IBOutlet UINavigationItem *toolItem;

@end
