//
//  QDDInviteContactViewController.h
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

#import "QDDInviteController.h"

#import <MessageUI/MessageUI.h>

@interface QDDInviteContactViewController : QDDViewController<UIActionSheetDelegate,MFMessageComposeViewControllerDelegate>

@property (strong, nonatomic) IBOutlet QDDInviteController *dataController;

@end
