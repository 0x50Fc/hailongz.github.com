//
//  QDDPublishCommentViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishCommentViewController.h"

#import "QDDCommentTask.h"

@interface QDDPublishCommentViewController ()

@end

@implementation QDDPublishCommentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSDictionary * queryValues = [self.url queryValues];
    
    NSString * title = [queryValues valueForKey:@"title"];
    
    if(title){
        [_titleLabel setText:title];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    [_textField becomeFirstResponder];
}

-(void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_keyboardController setDelegate:nil];
    
}

-(void) visableKeyboard:(CGRect) frame{
    
    if([[_contentView.layer animationKeys] count]){
        return;
    }
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, size.height - r.size.height - frame.size.height
                                          , r.size.width, r.size.height)];
        
    }];
    
}

-(void) hiddenKeyboard:(CGRect) frame{
    
    CGSize size = [[_contentView superview] bounds].size;
    
    CGRect r = [_contentView frame];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        [_contentView setFrame:CGRectMake(r.origin.x, size.height - r.size.height
                                          , r.size.width, r.size.height)];
        
    }];
    
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willShowFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller willHideFrame:(CGRect) frame{
    [self hiddenKeyboard:frame];
}

-(void) vtKeyboardController:(VTKeyboardController * )controller didChangedFrame:(CGRect) frame{
    [self visableKeyboard:frame];
}


- (IBAction)onSendAction:(id)sender {
    
    NSString * body = [_textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([body length] ==0){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入内容" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        
        return;
    }
    
    if([body textLength] > 140){
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"内容最长140个字符\n1个中文占两个字符" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        
        return;
    }
    
    NSDictionary * queryValues = [self.url queryValues];
    
    QDDCommentTask * task = [[QDDCommentTask alloc] init];
    
    [task setPublishId:[[queryValues valueForKey:@"pid"] longLongValue]];
    [task setCommentId:[[queryValues valueForKey:@"cid"] longLongValue]];
    [task setBody:body];
    [task setSource:self];
    [task setDelegate:self];
    
    [_statusView setUserInteractionEnabled:NO];
    [_statusView setStatus:@"loading"];
    
    [self.context handle:@protocol(IQDDCommentTask) task:task priority:0];
    
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{

    if(taskType == @protocol(IQDDCommentTask)){
        [_statusView setUserInteractionEnabled:YES];
        [_statusView setStatus:nil];
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
}

-(void) vtUploadTask:(id<IVTUplinkTask>)uplinkTask didSuccessResults:(id)results forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDCommentTask)){
        
        VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"发送成功"];
        
        [alertView showDuration:1.0];
        
        [[VTPopWindow topPopWindow] closeAnimated:YES];
        
        [self.context setResultsData:[NSNumber numberWithBool:YES]];
        
    }
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [self onSendAction:nil];
    
    return YES;
}

@end
