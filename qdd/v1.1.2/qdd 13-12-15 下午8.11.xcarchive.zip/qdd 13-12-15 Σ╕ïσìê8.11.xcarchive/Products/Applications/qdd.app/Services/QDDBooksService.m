//
//  QDDBooksService.m
//  qdd
//
//  Created by zhang hailong on 13-11-16.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksService.h"

#import "QDDBooksCreateTask.h"

#import "QDDClassifyObject.h"

#import "QDDBooksSearchTask.h"

#import "QDDBooksObject.h"

@implementation QDDBooksService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(@protocol(IQDDBooksCreateTask) == taskType){
        
        id<IQDDBooksCreateTask> booksTask = (id<IQDDBooksCreateTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDBooksCreateTask" forKey:@"taskType"];
        
        [body addItemValue:[NSString stringWithFormat:@"%lf",[booksTask payMoney]] forKey:@"qdd-payMoney"];
        [body addItemValue:[NSString stringWithFormat:@"%lf",[booksTask expendMoney]] forKey:@"qdd-expendMoney"];
        [body addItemValue:[NSString stringWithFormat:@"%lf",[booksTask latitude]] forKey:@"qdd-latitude"];
        [body addItemValue:[NSString stringWithFormat:@"%lf",[booksTask longitude]] forKey:@"qdd-longitude"];
        [body addItemValue:[booksTask shopTitle] forKey:@"qdd-shopTitle"];
        [body addItemValue:[booksTask shopAddress] forKey:@"qdd-shopAddress"];
        [body addItemValue:[booksTask remark] forKey:@"qdd-remark"];
        
        
        NSMutableString * cids = [NSMutableString stringWithCapacity:100];
        
        for(QDDClassifyObject * tagObject in [booksTask classifyObjects]){
            
            if([cids length]){
                [cids appendFormat:@",%lld",tagObject.cid];
            }
            else{
                [cids appendFormat:@"%lld",tagObject.cid];
            }
            
        }
        
        [body addItemValue:cids forKey:@"qdd-cids"];
        

        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(@protocol(IQDDBooksSearchTask) == taskType){
        
        id<IQDDBooksSearchTask> booksTask = (id<IQDDBooksSearchTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDBooksSearchTask" forKey:@"taskType"];
        
        [body addItemValue:[NSString stringWithFormat:@"%d",(int) [booksTask startTime]] forKey:@"qdd-startTime"];
        [body addItemValue:[NSString stringWithFormat:@"%d",(int) [booksTask endTime]] forKey:@"qdd-endTime"];
        
        
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        
        return YES;
    }
    else if(@protocol(IVTAPIResponseTask) == taskType){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDBooksCreateTask) ){
            
//            id<IQDDBooksCreateTask> booksTask = (id<IQDDBooksCreateTask>) [respTask task];
        
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                
                id data = [[respTask resultsData] dataForKeyPath:@"books-create-results"];
                
                if([data isKindOfClass:[NSDictionary class]]){
                    
                    QDDBooksObject * dataObject = [[QDDBooksObject alloc] init];
                    
                    [dataObject setBid:[[data valueForKey:@"bid"] longLongValue]];
                    
                    [self data:data toBooksObject:dataObject];
                    
                    [dbContext insertObject:dataObject];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDBooksChangedNotification object:nil];
                    
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        else if([respTask taskType] == @protocol(IQDDBooksSearchTask) ){
            
            id<IQDDBooksSearchTask> booksTask = (id<IQDDBooksSearchTask>) [respTask task];
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                id items = [[respTask resultsData] dataForKeyPath:@"books-search-results"];
                
                if([items isKindOfClass:[NSArray class]]){
                    
                    NSMutableDictionary * dataObjects = [NSMutableDictionary dictionaryWithCapacity:4];
                    
                    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
                    
                    id<IVTSqliteCursor> cursor = [dbContext query:[QDDBooksObject tableClass] sql:[NSString stringWithFormat:@"WHERE [timestamp] >= %d AND [timestamp] <= %d",(int)[booksTask startTime],(int)[booksTask endTime]] data:nil];
                    
                    while([cursor next]){
                        
                        QDDBooksObject * dataObject = [[QDDBooksObject alloc] init];
                        
                        [cursor toDataObject:dataObject];
                        
                        NSNumber * key = [NSNumber numberWithLongLong:[dataObject bid]];
                        
                        if([dataObjects objectForKey:key]){
                            [dbContext deleteObject:dataObject];
                        }
                        else{
                            [dataObjects setObject:dataObject forKey:key];
                        }
                    }
                    
                    [cursor close];
                    
                    
                    for (id item in items) {
                        
                        long long bid = [[item dataForKeyPath:@"bid"] longLongValue];
                        
                        if(bid){
                            
                            NSNumber * key = [NSNumber numberWithLongLong:bid];
                            
                            QDDBooksObject * dataObject = [dataObjects objectForKey:key];
                            
                            if(dataObject == nil){
                                dataObject = [[QDDBooksObject alloc] init];
                                [dataObject setBid:bid];
                                [self data:item toBooksObject:dataObject];
                                [dbContext insertObject:dataObject];
                            }
                            else{
                                [self data:item toBooksObject:dataObject];
                                [dbContext updateObject:dataObject];
                                [dataObjects removeObjectForKey:key];
                            }
                            
                        }
                        
                    }
                    
                    for(QDDBooksObject * dataObject in [dataObjects allValues]){
                        [dbContext deleteObject:dataObject];
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDBooksChangedNotification object:nil];
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

-(void) data:(id) data toBooksObject:(QDDBooksObject *) booksObject{
    
    [booksObject setPayMoney:[[data valueForKey:@"payMoney"] doubleValue]];
    [booksObject setExpendMoney:[[data valueForKey:@"expendMoney"] doubleValue]];
    [booksObject setLatitude:[[data valueForKey:@"latitude"] doubleValue]];
    [booksObject setLongitude:[[data valueForKey:@"longitude"] doubleValue]];
    [booksObject setShopTitle:[data dataForKeyPath:@"body.title"]];
    [booksObject setShopAddress:[data dataForKeyPath:@"body.address"]];
    [booksObject setRemark:[data dataForKeyPath:@"body.remark"]];
    [booksObject setCids:[data dataForKeyPath:@"cids"]];
    
    [booksObject setTimestamp:[[data valueForKey:@"createTime"] intValue]];
}

@end
