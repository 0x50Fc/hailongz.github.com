//
//  QDDLogoutTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-14.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDLogoutTask <IQDDAPITask,IVTUplinkTask>


@end

@interface QDDLogoutTask : VTUplinkTask<IQDDLogoutTask>

@end
