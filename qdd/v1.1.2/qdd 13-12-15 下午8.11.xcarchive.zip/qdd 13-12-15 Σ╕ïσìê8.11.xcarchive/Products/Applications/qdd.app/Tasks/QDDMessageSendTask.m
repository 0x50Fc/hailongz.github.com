//
//  QDDMessageSendTask.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDMessageSendTask.h"

@implementation QDDMessageSendTask

@synthesize uid = _uid;
@synthesize body = _body;
@synthesize image = _image;
@synthesize imageUri = _imageUri;

@end
