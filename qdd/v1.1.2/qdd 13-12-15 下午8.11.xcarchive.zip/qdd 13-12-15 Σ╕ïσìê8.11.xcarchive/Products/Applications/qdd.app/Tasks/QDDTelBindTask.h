//
//  QDDTelBindTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDTelBindTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * tel;
@property(nonatomic,retain) NSString * telVerify;

@end

@interface QDDTelBindTask : VTUplinkTask<IQDDTelBindTask>

@end
