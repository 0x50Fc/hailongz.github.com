//
//  QDDFeedDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDFeedDataSource.h"

@implementation QDDFeedDataSource

@synthesize queryValues = _queryValues;
@synthesize allowCached = _allowCached;
@synthesize taskType = _taskType;

-(NSString *) classify{
    return [self status];
}
    
-(void) setClassify:(NSString *)classify{
    [self setStatus:classify];
}

-(BOOL) isMutual{
    return [[self.queryValues valueForKey:@"mutual"] boolValue];
}

-(void) setMutual:(BOOL)mutual{
    if(mutual){
        [self.queryValues setValue:[NSString stringWithFormat:@"1"] forKey:@"mutual"];
    }
    else{
        [self.queryValues removeObjectForKey:@"mutual"];
    }
}

-(NSMutableDictionary *) queryValues{
    if(_queryValues == nil){
        _queryValues = [[NSMutableDictionary alloc] init];
    }
    return _queryValues;
}

-(void) setPageIndex:(NSInteger)pageIndex{
    [super setPageIndex:pageIndex];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageIndex] forKey:@"pageIndex"];
}

-(void) setPageSize:(NSInteger)pageSize{
    [super setPageSize:pageSize];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
}

-(void) dealloc{
    
    [self.context cancelHandle:@protocol(IQDDDownlinkTask) task:self];
    
}

-(void) reloadData{
    [super reloadData];
    
    [self.queryValues setValue:[(id<QDDContext>)self.context uid] forKey:@"selfuid"];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
    
}

-(void) loadMoreData{
    [super loadMoreData];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
}

-(void) cancel{
    [super cancel];
    
    [self.context cancelHandle:@protocol(IQDDDownlinkTask) task:self];
}

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    for(id dataItem in [self dataObjects]){
        
        if([dataItem valueForKey:@"fmtCreateTime"] == nil){
            NSDate * date = [NSDate dateWithTimeIntervalSince1970:[[dataItem dataForKeyPath:@"createTime"] doubleValue]];
            
            [dataItem setValue:[date QDDFormatString] forKey:@"fmtCreateTime"];
        }
        
        if([dataItem valueForKey:@"fmtDistance"] == nil){
            double latitude = [[dataItem dataForKeyPath:@"latitude"] doubleValue];
            double longitude = [[dataItem dataForKeyPath:@"longitude"] doubleValue];
            
            if(latitude && longitude){
                double dis = [(id<QDDContext>)self.context distance:latitude longitude:longitude];
                if(dis >=0 ){
                    
                    if(dis <1){
                        dis = 1;
                    }
                    
                    [dataItem setValue:[NSNumber numberWithDouble:dis] forKey:@"distance"];
                    
                    if(dis < 1000.0){
                        [dataItem setValue:[NSString stringWithFormat:@"%d米",(int) (dis)] forKey:@"fmtDistance"];
                    }
                    else{
                        [dataItem setValue:[NSString stringWithFormat:@"%d公里",(int) (dis / 1000)] forKey:@"fmtDistance"];
                    }
                }
            }
        }
        
        if([dataItem valueForKey:@"html"] == nil){
            
            NSString * body = [dataItem valueForKey:@"body"];
            
            [dataItem setValue:[body htmlEncodeString] forKey:@"html"];
            
        }
    }
}

@end
