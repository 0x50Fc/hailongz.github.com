//
//  QDDConcernDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-25.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDConcernDataSource.h"

#import "QDDConcernObject.h"

@implementation QDDConcernDataSourceSection


@end

@implementation QDDConcernDataSource


-(id) init{
    if((self = [super init])){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dbChangedAction:) name:QDDConcernChangedNotification object:nil];
        
    }
    return self;
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDConcernChangedNotification object:nil];
    
}

-(void) dbChangedAction:(NSNotification *) notification{
    
    [self reloadDataObject];
    
    if([self.delegate respondsToSelector:@selector(vtDataSourceDidContentChanged:)]){
        [self.delegate vtDataSourceDidContentChanged:self];
    }
    
}

-(void) reloadDataObject{
    

    QDDConcernDataSourceSection * defaultSection = [[QDDConcernDataSourceSection alloc] init];
    
    [defaultSection setPy:@"#"];
    [defaultSection setDataObjects:[NSMutableArray arrayWithCapacity:4]];
    
    NSMutableDictionary * sectionMap = [NSMutableDictionary dictionaryWithCapacity:4];
    
    NSMutableArray * sections = [NSMutableArray arrayWithCapacity:4];
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
    
    NSString * sql = nil;
    
    if([self isMutual]){
        sql = [NSString stringWithFormat:@"WHERE mutual==1 ORDER BY py ASC,nick ASC"];
    }
    else{
        sql = @"ORDER BY py ASC,nick ASC";
    }
    
    id<IVTSqliteCursor> cursor = [dbContext query:[QDDConcernObject tableClass] sql:sql data:nil];
    
    while ([cursor next]) {
        
        QDDConcernObject * dataObject = [[QDDConcernObject alloc] init];
        
        NSMutableDictionary * dataItem = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [dataItem setObject:dataObject forKey:@"dataObject"];
        
        [cursor toDataObject:dataObject];
        
        NSString * py = [dataObject.py uppercaseString];
        
        if([py length]){
            
            unichar uc = [py characterAtIndex:0];
            
            if((uc >= '0' && uc <='9') || (uc >='A' && uc <='Z')){
                
                py = [NSString stringWithCharacters:&uc length:1];
                
                QDDConcernDataSourceSection * section = [sectionMap objectForKey:py];
                
                if(section == nil){
                    section = [[QDDConcernDataSourceSection alloc] init];
                    [section setPy:py];
                    [section setDataObjects:[NSMutableArray arrayWithCapacity:4]];
                    [sectionMap setObject:section forKey:py];
                    
                    [sections addObject:section];
                    
                }
                
                [section.dataObjects addObject:dataItem];
                
            }
            else{
                [[defaultSection dataObjects] addObject:dataItem];
            }
        }
        else{
            [[defaultSection dataObjects] addObject:dataItem];
        }
        
        
    }
    
    [cursor close];
    
    if([[defaultSection dataObjects] count]){
        [sections addObject:defaultSection];
    }
 
    
    self.sections = sections;
}

-(void) reloadData{
    
    [self reloadDataObject];

    if([self.delegate respondsToSelector:@selector(vtDataSourceDidLoaded:)]){
        [self.delegate vtDataSourceDidLoaded:self];
    }
    
    self.loaded = YES;
}

-(BOOL) hasMoreData{
    return NO;
}

-(id) dataObjectAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section < [_sections count]){
        QDDConcernDataSourceSection * section = [_sections objectAtIndex:indexPath.section];
        if(indexPath.row < [[section dataObjects] count]){
            return [[section dataObjects] objectAtIndex:indexPath.row];
        }
    }
    return nil;
}

-(BOOL) isEmpty{
    return [_sections count] ==0;
}

@end
