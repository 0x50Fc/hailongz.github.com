//
//  QDDInviteQQDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-12-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteDataSource.h"

@interface QDDInviteQQDataSource : QDDInviteDataSource

@end
