//
//  QDDInviteContactDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteContactDataSource.h"

#import <AddressBook/AddressBook.h>

@interface QDDInviteContactDataSource(){
    ABAddressBookRef _book;
}

@end

@implementation QDDInviteContactDataSource

-(id) init{
    
    if((self = [super init])){
        _book = ABAddressBookCreate();
    }
    
    return self;
}

-(void) dealloc{
    
    CFRelease(_book);
    
}

-(void) loadPeoples{
    
    
    NSMutableString * tels = [NSMutableString stringWithCapacity:128];
    
    CFArrayRef persons = ABAddressBookCopyArrayOfAllPeople(_book);
    
    CFIndex count = CFArrayGetCount(persons);
    
    for(CFIndex index=0;index < count;index ++){
        
        ABRecordRef record = CFArrayGetValueAtIndex(persons, index);
        
        ABMutableMultiValueRef phones = ABRecordCopyValue(record, kABPersonPhoneProperty);
        
        CFIndex c = ABMultiValueGetCount(phones);
        
        for(CFIndex i =0;i<c ;i++){
            
            CFStringRef phone = ABMultiValueCopyValueAtIndex(phones, i);
            
            if(phone && CFStringGetLength(phone) > 0){
                
                if([tels length]){
                    [tels appendString:@","];
                }
                
                NSString * tel = (__bridge NSString *) phone;
                
                tel = [tel stringByReplacingOccurrencesOfString:@" " withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"(" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@")" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"-" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"+" withString:@""];
                
                [tels appendString:tel];
                
            }
            
            CFRelease(phone);
        }
        
        CFRelease(phones);
    }
    
    CFRelease(persons);
    
    [self.queryValues setValue:tels forKey:@"tels"];
    
    [super reloadData];
    
}

-(void) reloadData{
    
    self.loading = YES;
    
    if([[[UIDevice currentDevice] systemVersion] doubleValue] >= 6.0){
        
        ABAddressBookRequestAccessWithCompletion(_book, ^(bool granted, CFErrorRef error) {
            
            if(granted){
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self loadPeoples];
                });
                
            }
            else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    if([self.delegate respondsToSelector:@selector(vtDataSource:didFitalError:)]){
                        [self.delegate vtDataSource:self didFitalError:[NSError errorWithDomain:NSStringFromClass([self class]) code:0 userInfo:[NSDictionary dictionaryWithObject:@"无法访问通讯录,请在隐私设置中打开" forKey:NSLocalizedDescriptionKey]]];
                    }
                });
                
            }
            
        });
        
    }
    else{
        
    }
}

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    id dataObject = [self dataObject];
    
    NSMutableArray * sections = [NSMutableArray arrayWithCapacity:4];
    
    NSMutableArray * users = [NSMutableArray arrayWithCapacity:4];
    
    NSMutableArray * peoples = [NSMutableArray arrayWithCapacity:4];
    
    CFArrayRef persons = ABAddressBookCopyArrayOfAllPeople(_book);
    
    CFIndex count = CFArrayGetCount(persons);
   
    for(CFIndex index=0;index < count;index ++){
        
        ABRecordRef record = CFArrayGetValueAtIndex(persons, index);
        
        ABMutableMultiValueRef phones = ABRecordCopyValue(record, kABPersonPhoneProperty);
        
        CFIndex c = ABMultiValueGetCount(phones);
        CFIndex i = 0;
        
        NSMutableArray * tels = [NSMutableArray arrayWithCapacity:4];
        
        
        for(i =0;i<c ;i++){
            
            CFStringRef phone = ABMultiValueCopyValueAtIndex(phones, i);
            
            if(phone && CFStringGetLength(phone) > 0){
                
                NSString * tel = nil;
                
                tel = (__bridge NSString *) phone;
                
                tel = [tel stringByReplacingOccurrencesOfString:@" " withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"(" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@")" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"-" withString:@""];
                tel = [tel stringByReplacingOccurrencesOfString:@"+" withString:@""];
            
                [tels addObject:tel];
                
                id user = [dataObject dataForKeyPath:tel];
                
                if(user){
                    
                    NSMutableDictionary * dataItem = [NSMutableDictionary dictionaryWithCapacity:4];
                    
                    [dataItem setValue:tel forKey:@"tel"];
                    [dataItem setValue:user forKey:@"user"];
                    
                    [users addObject:dataItem];
                    
                    break;
                }
            }
            
            CFRelease(phone);
        }
        
        CFRelease(phones);
        
        if(i >= c && [tels count] > 0){
            
            NSMutableDictionary * dataItem = [NSMutableDictionary dictionaryWithCapacity:4];
            
            ABRecordID recordID = ABRecordGetRecordID(record);
            
            [dataItem setValue:[NSNumber numberWithInteger:recordID] forKey:@"recordID"];
            
            NSMutableString * title = [NSMutableString stringWithCapacity:64];
            
            CFStringRef firstName = ABRecordCopyValue(record, kABPersonFirstNameProperty);
            CFStringRef lastName = ABRecordCopyValue(record, kABPersonLastNameProperty);
            
            if(firstName){
                [title appendString:(__bridge NSString *) firstName];
                CFRelease(firstName);
            }
            
            if(lastName){
                if([title length]){
                    [title appendString:@" "];
                }
                [title appendString:(__bridge NSString *) lastName];
                CFRelease(lastName);
            }
            
            if([title length] ==0){
                
                CFStringRef jobTitle = ABRecordCopyValue(record, kABPersonJobTitleProperty);
                
                if(jobTitle){
                    [title appendString:(__bridge NSString *) jobTitle];
                    CFRelease(jobTitle);
                }
                
            }
            
            [dataItem setValue:title forKey:@"title"];
            
            [dataItem setValue:tels forKey:@"tels"];
            
            if(ABPersonHasImageData(record)){
                
                CFDataRef data = ABPersonCopyImageData(record);
                
                [dataItem setObject:[UIImage imageWithData:(__bridge NSData *) data] forKey:@"image"];
                
                CFRelease(data);
            }
            
            [peoples addObject:dataItem];
            
        }
    }
    
    CFRelease(persons);
    
    if([users count]){
    
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"钱多多",@"title"
                             ,@"user",@"type",users,@"items", nil]];
    
    }
    
    if([peoples count]){
        
        [peoples sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
           
            NSString * title1 = [obj1 valueForKey:@"title"];
            NSString * title2 = [obj2 valueForKey:@"title"];
            
            return [title1 compare:title2];
        }];
        
        [sections addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"通讯录",@"title"
                             ,@"people",@"type",peoples,@"items", nil]];
        
    }
    
    self.sections = sections;
}


@end
