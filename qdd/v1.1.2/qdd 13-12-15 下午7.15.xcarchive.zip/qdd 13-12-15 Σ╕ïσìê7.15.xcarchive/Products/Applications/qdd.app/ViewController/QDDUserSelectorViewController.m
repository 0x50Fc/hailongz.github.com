//
//  QDDUserSelectorViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-1.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserSelectorViewController.h"

#import "QDDConcernTask.h"

@interface QDDUserSelectorViewController ()

@end

@implementation QDDUserSelectorViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if([(id<QDDContext>)self.context hasConcernChanged]){
        [self.context handle:@protocol(IQDDConcernTask) task:[[QDDConcernTask alloc] init] priority:0];
    }
    
    
    [[_tabController selectedController] reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) vtTabDataController:(VTTabDataController *) dataController didSelectedChanged:(NSUInteger) selectedIndex{
    if(![(VTDataSource *)[[dataController selectedController] dataSource] isLoaded]){
        [[dataController selectedController] reloadData];
    }
    [_segmentedControl setSelectedSegmentIndex:[dataController selectedIndex]];
}

- (IBAction)segmentedValueChangedAction:(id)sender {
    if([_segmentedControl selectedSegmentIndex] != [_tabController selectedIndex]){
        [_tabController setSelectedIndex:[_segmentedControl selectedSegmentIndex]];
    }
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"user"]){
        
        NSMutableDictionary * data = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [data setValue:[element attributeValueForKey:@"uid"] forKey:@"uid"];
        [data setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        [self.context setResultsData:data];
        
    }
}

@end
