//
//  QDDInviteWeiboViewController.m
//  qdd
//
//  Created by zhang hailong on 13-12-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDInviteWeiboViewController.h"

#import "QDDFollowTask.h"


@interface QDDInviteWeiboViewController ()

@end

@implementation QDDInviteWeiboViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(![[_dataController dataSource] isLoaded]
       && ![[_dataController dataSource] isLoading]){
       
        [_dataController reloadData];
    }
}



-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"follow"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        if(uid){
            
            QDDFollowTask * task = [[QDDFollowTask alloc] init];
            
            [task setTuid:[uid longLongValue]];
            
            [self.context handle:@protocol(IQDDFollowTask) task:task priority:0];
            
            if([element isKindOfClass:[VTDOMViewElement class]]){
                
                UIButton * button = (UIButton *) [(VTDOMViewElement *) element view];
                
                if([button isKindOfClass:[UIButton class]]){
                    
                    [button setTitle:@"已关注" forState:UIControlStateNormal];
                    [button setImage:nil forState:UIControlStateNormal];
                    [button setEnabled:NO];
                    [button setAdjustsImageWhenHighlighted:NO];
                    
                }
                
            }
            
        }
        
    }
    else if([actionName isEqualToString:@"wbuser"]){
        
        UITableViewCell * cell = (UITableViewCell *)[element.delegate superview];
        
        while(cell && ![cell isKindOfClass:[UITableViewCell class]]){
            
            cell = (UITableViewCell *) [cell superview];
        }
        
        NSIndexPath * indexPath = [dataController.tableView indexPathForCell:cell];
        
        if(indexPath){
            
            id dataItem = [dataController dataObjectByIndexPath:indexPath];
            
            [WeiboSDK inviteFriend:@"我在 钱多多 等你，快来吧 http://qdd.richland.com" withUid:[dataItem dataForKeyPath:@"id"] withToken:[(id<QDDContext>)self.context weiboToken] delegate:self];
            
        }
        
    }
    
}

- (void)didReceiveWeiboSDKResponse:(id)JsonObject err:(NSError *)error{
    
    dispatch_async(dispatch_get_main_queue(), ^{
       
        
        if(error){
            
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"邀请好友出错" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            
            [alertView show];
            
        }
        else{
            
            VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"邀请已发出"];
            
            [alertView showDuration:1.2];
            
        }
        
    });
    
}


@end
