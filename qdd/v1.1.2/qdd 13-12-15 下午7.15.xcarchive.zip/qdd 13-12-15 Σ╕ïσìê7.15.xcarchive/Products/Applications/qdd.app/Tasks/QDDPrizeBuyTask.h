//
//  QDDPrizeBuyTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDPrizeBuyTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) long long productId;
@property(nonatomic,retain) NSString * address;
@property(nonatomic,retain) NSString * postCode;
@property(nonatomic,retain) NSString * name;
@property(nonatomic,retain) NSString * phone;
@property(nonatomic,retain) NSString * other;

@end

@interface QDDPrizeBuyTask : VTUplinkTask<IQDDPrizeBuyTask>

@end
