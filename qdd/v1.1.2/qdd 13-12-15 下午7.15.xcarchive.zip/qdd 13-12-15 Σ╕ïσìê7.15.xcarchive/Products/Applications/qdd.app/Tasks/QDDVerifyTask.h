//
//  QDDVerifyTask.h
//  qdd
//
//  Created by zhang hailong on 13-12-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDVerifyTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * tel;

@end

@interface QDDVerifyTask : VTUplinkTask<IQDDVerifyTask>

@end
