//
//  QDDPublishTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishTask.h"

@implementation QDDPublishTask

@synthesize body = _body;
@synthesize images = _images;
@synthesize tagObjects = _tagObjects;
@synthesize classifyObjects = _classifyObjects;
@synthesize payMoney = _payMoney;
@synthesize expendMoney = _expendMoney;
@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@synthesize toWeibo = _toWeibo;
@synthesize toQQ = _toQQ;

@end
