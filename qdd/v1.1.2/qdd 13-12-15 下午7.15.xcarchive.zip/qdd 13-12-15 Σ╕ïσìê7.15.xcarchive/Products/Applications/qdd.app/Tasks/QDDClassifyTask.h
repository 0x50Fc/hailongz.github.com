//
//  QDDClassifyTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-8.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDClassifyTask <IQDDAPITask,IVTUplinkTask>


@end

@interface QDDClassifyTask : VTUplinkTask<IQDDClassifyTask>

@end
