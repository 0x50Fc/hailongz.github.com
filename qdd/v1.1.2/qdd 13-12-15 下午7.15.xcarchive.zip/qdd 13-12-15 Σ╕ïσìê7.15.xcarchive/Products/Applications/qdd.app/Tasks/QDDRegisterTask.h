//
//  QDDRegisterTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDRegisterTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * account;
@property(nonatomic,retain) NSString * tel;
@property(nonatomic,retain) NSString * telVerify;
@property(nonatomic,retain) NSString * password;
@property(nonatomic,retain) NSString * nick;

@end

@interface QDDRegisterTask : VTUplinkTask<IQDDRegisterTask>

@end
