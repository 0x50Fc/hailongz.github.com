//
//  QDDAuthTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDAuthTask <IQDDAPITask,IVTUplinkTask>

@end

@interface QDDAuthTask : VTUplinkTask<IQDDAuthTask>

@end
