//
//  QDDCommentService.m
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDCommentService.h"

#import "QDDCommentTask.h"

@implementation QDDCommentService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{

    if(taskType == @protocol(IQDDCommentTask)){
        
        id<IQDDCommentTask> commentTask = (id<IQDDCommentTask>) task;
        
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDCommentTask" forKey:@"taskType"];
        
        [body addItemValue:[commentTask body] forKey:@"qdd-body"];
        
        if([commentTask publishId]){
            [body addItemValue:[NSString stringWithFormat:@"%lld",[commentTask publishId]] forKey:@"qdd-pid"];
        }
        else{
            [body addItemValue:[NSString stringWithFormat:@"%lld",[commentTask commentId]] forKey:@"qdd-cid"];
        }
                
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>)task;
        
        if([respTask taskType] == @protocol(IQDDCommentTask)){
        
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
    }
    
    return NO;
}


@end
