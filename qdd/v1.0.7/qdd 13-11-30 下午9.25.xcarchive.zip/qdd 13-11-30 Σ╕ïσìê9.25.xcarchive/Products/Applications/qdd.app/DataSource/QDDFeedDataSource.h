//
//  QDDFeedDataSource.h
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDDownlinkTask.h"

@interface QDDFeedDataSource : VTStatusDataSource<IQDDDownlinkTask>

@property(nonatomic,retain) NSString * taskType;
@property(nonatomic,retain) NSString * classify;
@property(nonatomic,assign,getter = isMutual) BOOL mutual;

@end
