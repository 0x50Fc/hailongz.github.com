//
//  QDDSearchNearUserDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDSearchNearUserDataSource.h"

@implementation QDDSearchNearUserDataSource

-(id) init{
    if((self = [super init])){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locationDidChangedAction:) name:QDDLocationChangedNotification object:nil];
    }
    return self;
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDLocationChangedNotification object:nil];
    
}

-(void) reloadData{
    
    if([(id<QDDContext>)self.context isNeedsUpdateLocation]){
        [(id<QDDContext>)self.context startLocation];
    }
    
    CLLocation * location = [(id<QDDContext>)self.context location];
    
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",location.coordinate.latitude] forKey:@"latitude"];
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",location.coordinate.longitude] forKey:@"longitude"];
    
    [super reloadData];
}

-(void) locationDidChangedAction:(NSNotification *) notification{
    
    CLLocation * location = [(id<QDDContext>)self.context location];
    
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",location.coordinate.latitude] forKey:@"latitude"];
    [self.queryValues setValue:[NSString stringWithFormat:@"%lf",location.coordinate.longitude] forKey:@"longitude"];
    
    
}

@end
