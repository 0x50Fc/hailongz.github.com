/**
 *  QDDViewController.h
 *  qdd
 *
 *  Created by zhang hailong on 13-11-2.
 *  Copyright 9vteam 2013年. All rights reserved.
 */

#import <vTeam/vTeam.h>

#import "QDDPublishView.h"

@interface QDDViewController : VTViewController<UITabBarDelegate>

@property(nonatomic,retain) IBOutlet UITabBar * tabBar;
@property(nonatomic,retain) IBOutlet UITabBarItem * selectedTabItem;
@property(nonatomic,retain) IBOutlet QDDPublishView * publishView;
    
@end
