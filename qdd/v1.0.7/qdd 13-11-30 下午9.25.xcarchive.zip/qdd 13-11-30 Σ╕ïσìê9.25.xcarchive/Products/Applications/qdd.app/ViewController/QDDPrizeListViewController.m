//
//  QDDPrizeListViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeListViewController.h"

@interface QDDPrizeListViewController ()

@end

@implementation QDDPrizeListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_dataController reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
    
-(void) vtContainerDataController:(VTContainerDataController *)dataController itemViewController:(VTItemViewController *)itemViewController doAction:(id<IVTAction>)action{

    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"prize"]){
        
        id pid = [itemViewController.dataItem dataForKeyPath:@"pid"];
        
        if(pid){
            
            [self openUrl:[NSURL URLWithString:@"prizelist/prize-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:pid forKey:@"pid"]] animated:YES];
            
        }
        
    }
}

@end
