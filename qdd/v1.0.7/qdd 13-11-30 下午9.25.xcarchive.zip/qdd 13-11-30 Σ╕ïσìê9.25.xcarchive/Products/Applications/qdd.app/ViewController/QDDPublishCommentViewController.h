//
//  QDDPublishCommentViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDPublishCommentViewController : QDDViewController<VTKeyboardControllerDelegate,IVTUplinkTaskDelegate>

@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UIButton *sendButton;
@property (strong, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) IBOutlet VTKeyboardController *keyboardController;
@property (strong, nonatomic) IBOutlet VTStatusView *statusView;
- (IBAction)onSendAction:(id)sender;

@end
