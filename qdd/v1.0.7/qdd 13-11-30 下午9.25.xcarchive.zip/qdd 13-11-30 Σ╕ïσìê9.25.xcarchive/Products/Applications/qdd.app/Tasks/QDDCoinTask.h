//
//  QDDCoinTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDCoinTask <IQDDAPITask,IVTUplinkTask>


@end

@interface QDDCoinTask : VTUplinkTask<IQDDCoinTask>

@end
