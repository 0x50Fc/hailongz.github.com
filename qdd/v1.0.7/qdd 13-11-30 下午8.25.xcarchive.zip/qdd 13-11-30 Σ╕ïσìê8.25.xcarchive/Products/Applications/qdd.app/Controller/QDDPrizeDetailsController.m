//
//  QDDPrizeDetailsController.m
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeDetailsController.h"

#import "QDDPrizeSearchDataSource.h"

@interface QDDPrizeDetailsController()

@property(nonatomic,assign) NSTimeInterval localTime;
@property(nonatomic,readonly) NSDateFormatter * dateFormatter;

@end

@implementation QDDPrizeDetailsController

@synthesize localTime = _localTime;
@synthesize dateFormatter = _dateFormatter;

-(void) dealloc{
    
    [_dataSource setDelegate:nil];
    
}

-(NSDateFormatter *) dateFormatter{
    if(_dateFormatter == nil){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return _dateFormatter;
}

-(void) documentWillLoad{
    [super documentWillLoad];
    
    VTDOMElement * element = [self.document elementById:@"images"];
    
    [element setValue:[self.dataItem valueForKey:@"images"] forKey:@"images"];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(refreshTime) object:nil];
    
    [self refreshTime];
}

-(void) refreshTime{
    
    id dataItem = [self dataItem];
    
    NSTimeInterval timestamp = [self.dataSource nowTimestamp];
    
    NSTimeInterval saleTime = [[self.dataItem dataForKeyPath:@"saleTime"] doubleValue];
    NSTimeInterval endTime = [[self.dataItem dataForKeyPath:@"endTime"] doubleValue];
    
    NSInteger t = 0;
    
    if(timestamp >= saleTime && timestamp <= endTime){
        
        t = endTime - timestamp;
        
        [dataItem setValue:@"兑奖中" forKey:@"status"];
        
        [self performSelector:@selector(refreshTime) withObject:nil afterDelay:1.0];
    }
    else if(timestamp < saleTime){
        
        t = saleTime - timestamp;
        
        [dataItem setValue:@"未开始" forKey:@"status"];
        
        [self performSelector:@selector(refreshTime) withObject:nil afterDelay:1.0];
    }
    else{
        
        t = 0;
        
        [dataItem setValue:@"已结束" forKey:@"status"];
        
        
    }
    
    VTDOMElement * element = [self.document elementById:@"time"];
    
    if(element){

        VTDOMParse * parse = [[VTDOMParse alloc] init];
        
        for (VTDOMElement * child in [NSArray arrayWithArray:[element childs]]) {
            [child removeFromParentElement];
        }
        
        if(t != 0){
        
            NSInteger days = (t / (3600 * 24)) ;
            NSInteger hours = (t % (3600 * 24)) / 3600;
            NSInteger mins = ((t % (3600 * 24)) % 3600) / 60;
            NSInteger secs = ((t % (3600 * 24)) % 3600) % 60;

            [parse parseHTML:[NSString stringWithFormat:@"<label width='auto' height='auto' font='32 bold' color='#ffffff'>%d</label><label width='auto' height='auto'  font='14 bold' color='#ffffff' margin-top='16' margin-left='4' margin-right='4'>天</label><label width='auto' height='auto' font='32 bold' color='#ffffff'>%d</label><label width='auto' height='auto' font='14 bold' color='#ffffff' margin-top='16' margin-left='4' margin-right='4'>时</label><label width='auto' height='auto'  font='32 bold' color='#ffffff'>%d</label><label width='auto' height='auto' font='14 bold' color='#ffffff' margin-top='16' margin-left='4' margin-right='4'>分</label><label width='auto' height='auto'  font='32 bold' color='#ffffff'>%d</label><label width='auto' height='auto' font='14 bold' color='#ffffff' margin-top='16' margin-left='4' margin-right='4'>秒</label>"
                              ,days,hours,mins,secs] toElement:element];
            
        }
        else{
            
            [self.dateFormatter setDateFormat:@"yyyy年MM月dd日 HH时mm分ss秒"];
            
            [parse parseHTML:[NSString stringWithFormat:@"<label width='auto' height='auto' font='16 bold' color='#ffffff' margin-top='10'>%@</label>",[_dateFormatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:endTime]]] toElement:element];
            
        }
        
        [element layout];
        
        [element setNeedDisplay];
    }
    
    element = [self.document elementById:@"statusView"];

    if([element isKindOfClass:[VTDOMViewElement class]] && [(VTDOMViewElement *)element isViewLoaded]){
        
        [(UIButton *)[(VTDOMViewElement *)element view] setTitle:[dataItem valueForKey:@"status"] forState:UIControlStateNormal];
        
    }
}

-(void) cancel{
    
    [_dataSource cancel];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(refreshTime) object:nil];
    
}

-(void) reloadData{
    
    [_statusView setStatus:@"loading"];
    
    [_dataSource reloadData];
    
}

-(void) loadDataObject{
   
    self.dataItem = [_dataSource dataObject];
    
    self.document = nil;
    
    [super reloadData];
    
    if([self.delegate respondsToSelector:@selector(prizeDetailsControllerDidContentChanged:)]){
        [self.delegate prizeDetailsControllerDidContentChanged:self];
    }
}

-(void) vtDataSourceDidLoaded:(VTDataSource *)dataSource{
    [self loadDataObject];
    [_statusView setStatus:nil];
}

-(void) vtDataSourceDidLoadedFromCache:(VTDataSource *)dataSource timestamp:(NSDate *)timestamp{
    [self loadDataObject];
    [_statusView setStatus:nil];
}

-(void) vtDataSource:(VTDataSource *)dataSource didFitalError:(NSError *)error{
    [_statusView setStatus:@"error"];
}


-(void) setContext:(id<IVTUIContext>)context{
    [super setContext:context];
    [_dataSource setContext:context];
}

@end
