//
//  QDDBooksEditController.h
//  qdd
//
//  Created by zhang hailong on 13-11-16.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "QDDKeyboardView.h"

#import "QDDClassifyController.h"

@interface QDDBooksEditController : VTController<QDDKeyboardViewDelegate,UITextFieldDelegate,VTKeyboardControllerDelegate,IVTUplinkTaskDelegate>

@property(nonatomic,strong) IBOutlet UITextField * moneyField;
@property(nonatomic,strong) IBOutlet UITextField * remarkField;
@property(nonatomic,strong) IBOutlet QDDKeyboardView * keyboardView;
@property(nonatomic,strong) IBOutlet QDDClassifyController * classifyController;
@property(nonatomic,strong) IBOutlet VTKeyboardController * keyboardController;
@property (strong, nonatomic) IBOutlet UIScrollView *contentView;
@property(nonatomic,strong) IBOutlet VTStatusView * statusView;

-(IBAction) doSubmitAction:(id)sender;

@end


@protocol QDDBooksEditControllerDelegate

@optional

-(void) booksEditController:(QDDBooksEditController *) controller didFailWithError:(NSError *) error;

-(void) booksEditController:(QDDBooksEditController *) controller didSuccessResults:(id) results;

@end