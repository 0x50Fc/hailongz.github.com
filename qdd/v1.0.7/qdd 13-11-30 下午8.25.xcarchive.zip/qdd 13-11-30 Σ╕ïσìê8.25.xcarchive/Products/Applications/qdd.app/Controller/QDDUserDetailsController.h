//
//  QDDUserDetailsController.h
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

@interface QDDUserDetailsController : VTDocumentController<VTDataSourceDelegate>

@property(nonatomic,retain) IBOutlet VTDataSource * dataSource;

@property(nonatomic,assign) NSInteger fansCount;

@end

@protocol QDDUserDetailsControllerDelegate


@optional

-(void) userDetailsControllerDidContentSizeChanged:(QDDUserDetailsController *) controller;


@end