//
//  QDDCommentListDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-20.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDCommentListDataSource.h"

#import "NSDate+QDD.h"

@implementation QDDCommentListDataSource

-(void) loadResultsData:(id)resultsData{
    [super loadResultsData:resultsData];
    
    for(id dataItem in [self dataObjects]){
        
        if([dataItem valueForKey:@"fmtCreateTime"] == nil){
            
            NSDate * date = [NSDate dateWithTimeIntervalSince1970:[[dataItem valueForKey:@"createTime"] intValue]];
            
            [dataItem setValue:[date QDDFormatString] forKey:@"fmtCreateTime"];
        }
        
        if([dataItem valueForKey:@"html"] == nil){
            
            NSString * body = [dataItem valueForKey:@"body"];
            
            if(body == nil){
                body = @"";
            }
            
            body = [body stringByReplacingOccurrencesOfString:@" " withString:@"&nbsp;"];
            
            if([dataItem valueForKey:@"reply"]){
                
                body = [NSString stringWithFormat:@"回复:&nbsp;<a action-name='user' uid='%@'>%@</a><br/>%@"
                        ,[dataItem dataForKeyPath:@"reply.user.uid"]
                        ,[dataItem dataForKeyPath:@"reply.user.nick"],body];
                
            }
            
            
            [dataItem setValue:body forKey:@"html"];
            
        }
        
    }
}
@end
