//
//  QDDClassifyGetTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-22.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "QDDClassifyObject.h"

@protocol IQDDClassifyGetTask <IVTTask>

@property(nonatomic,assign) long long cid;

@property(nonatomic,retain) QDDClassifyObject * dataObject;

@end

@interface QDDClassifyGetTask : VTTask<IQDDClassifyGetTask>

@end
