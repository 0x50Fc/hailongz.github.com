//
//  QDDConcernTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

enum {
    QDDConcernTaskStatusNone,
    QDDConcernTaskStatusLoading
};

@protocol IQDDConcernTask <IVTTask,IQDDAPITask>

@property(nonatomic,assign) NSUInteger status;
@property(nonatomic,assign) NSInteger pageIndex;

@end

@interface QDDConcernTask : VTTask<IQDDConcernTask>

@end
