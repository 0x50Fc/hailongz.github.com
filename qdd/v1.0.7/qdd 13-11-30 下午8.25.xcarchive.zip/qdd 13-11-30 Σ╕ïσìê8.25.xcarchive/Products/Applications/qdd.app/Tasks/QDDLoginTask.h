//
//  QDDLoginTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDLoginTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,retain) NSString * account;
@property(nonatomic,retain) NSString * password;

@end

@interface QDDLoginTask : VTUplinkTask<IQDDLoginTask>

@end
