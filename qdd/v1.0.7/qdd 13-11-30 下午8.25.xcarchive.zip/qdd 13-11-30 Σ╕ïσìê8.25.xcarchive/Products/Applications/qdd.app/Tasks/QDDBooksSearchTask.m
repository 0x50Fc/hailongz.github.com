//
//  QDDBooksSearchTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-17.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksSearchTask.h"

@implementation QDDBooksSearchTask

@synthesize startTime = _startTime;
@synthesize endTime = _endTime;

@end
