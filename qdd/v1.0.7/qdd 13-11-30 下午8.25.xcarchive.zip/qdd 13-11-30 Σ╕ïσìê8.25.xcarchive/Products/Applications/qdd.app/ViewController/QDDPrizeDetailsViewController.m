//
//  QDDPrizeDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPrizeDetailsViewController.h"

@interface QDDPrizeDetailsViewController ()

@end

@implementation QDDPrizeDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSDictionary * queryValues = [self.url queryValues];
    
    [_detailsController.dataSource setValue:[queryValues valueForKey:@"pid"] forKey:@"productId"];
    
    [_detailsController reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) prizeDetailsControllerDidContentChanged:(QDDPrizeDetailsController *)detailsController{
    [self.dataOutletContainer applyDataOutlet:self];
}

-(void) vtDocumentController:(VTDocumentController *) controller doActionElement:(VTDOMElement *) element{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"buy"]){
        
        [self.context setFocusValue:controller.dataItem forKey:@"prize"];
        
        [self openUrl:[NSURL URLWithString:@"prize-details/prize-buy" relativeToURL:self.url] animated:YES];
        
    }
    
}

@end
