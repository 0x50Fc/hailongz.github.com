//
//  QDDImageViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDImageViewController.h"

#import "QDDImageView.h"

@interface QDDImageViewController ()

@property(nonatomic,retain) NSArray * images;
@property(nonatomic,assign) NSInteger pageIndex;

@end

@implementation QDDImageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        [self setWantsFullScreenLayout:YES];
        
    }
    return self;
}

-(void) dealloc{
    
    [self.context cancelHandleForSource:self];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSMutableDictionary * data = [self.context focusValueForKey:@"image"];
    
    self.images = [data objectForKey:@"images"];
    self.pageIndex = [[data objectForKey:@"pageIndex"] intValue];
    
    self.title = [NSString stringWithFormat:@"%d/%d",_pageIndex + 1,[_images count]];
    
    [self.dataOutletContainer applyDataOutlet:self];

    CGSize size = self.contentView.bounds.size;
    
    NSInteger index = 0;
    
    for (id image in _images) {
        
        UIScrollView * itemView = [[UIScrollView alloc] initWithFrame:CGRectMake(index * size.width, 0, size.width, size.height)];
        
        [itemView setTag:200 + index];
        [itemView setShowsHorizontalScrollIndicator:NO];
        [itemView setShowsVerticalScrollIndicator:NO];
        [itemView setDelegate:self];
        [itemView setMaximumZoomScale:10];
        [itemView setBounces:NO];
        
        [itemView setAutoresizingMask:UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth];
        
        QDDImageView * imageView = [[QDDImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        
        [imageView setTag:100];
        [imageView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        
        [itemView addSubview:imageView];
        
        [imageView setSrc:[image dataForKeyPath:@"uri"]];
        [imageView setSource:self];
        
        [_contentView addSubview:itemView];
        
        if(abs(_pageIndex - index) < 2){
            [self.context handle:@protocol(IVTImageTask) task:imageView priority:0];
        }
        
        index ++;
    }
    
    [_contentView setContentSize:CGSizeMake(index * size.width, 0)];
    [_contentView setContentOffset:CGPointMake(_pageIndex * size.width, 0) animated:NO];
    
    UITapGestureRecognizer * tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)];
    
    [tapGestureRecognizer setNumberOfTapsRequired:1];
    [tapGestureRecognizer setNumberOfTouchesRequired:1];
    
    [self.view addGestureRecognizer:tapGestureRecognizer];
    
    tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap2GestureAction:)];
    
    [tapGestureRecognizer setNumberOfTapsRequired:2];
    [tapGestureRecognizer setNumberOfTouchesRequired:1];
    
    [self.view addGestureRecognizer:tapGestureRecognizer];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doImageAction:(id)sender {
    
    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"保存到相册", nil];
    
    [actionSheet showInView:self.view];
    
}

-(void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
     [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

-(void) hiddenViews{
    
    for(UIView * v in _autoHiddenViews){
        [v setHidden:YES animated:YES];
    }
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
}

-(void) visableViews{
    
    for(UIView * v in _autoHiddenViews){
        [v setHidden:NO animated:YES];
    }
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
    
}

-(void) delayTapGestureAction{
    
    if([[UIApplication sharedApplication] isStatusBarHidden]){
        [self visableViews];
    }
    else{
        [self hiddenViews];
    }
}

-(void) tapGestureAction:(UITapGestureRecognizer *) gestureRecognizer{
    [self performSelector:@selector(delayTapGestureAction) withObject:nil afterDelay:0.3];
}

-(void) tap2GestureAction:(UITapGestureRecognizer *) gestureRecognizer{
 
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayTapGestureAction) object:nil];
    
    if(![[UIApplication sharedApplication] isStatusBarHidden]){
        [self hiddenViews];
    }
    
    UIScrollView * v = (UIScrollView *)[_contentView viewWithTag:200 + _pageIndex];
    
    if([v isKindOfClass:[UIScrollView class]]){
        if([v zoomScale] == 1.0){
            [v setZoomScale:2.0 animated:YES];
        }
        else{
            [v setZoomScale:1.0 animated:YES];
        }
    }
    
}


-(void) scrollViewDidScroll:(UIScrollView *)scrollView{

    if(_contentView == scrollView){
        
        self.pageIndex = _contentView.contentOffset.x / _contentView.bounds.size.width;
        
        self.title = [NSString stringWithFormat:@"%d/%d",_pageIndex + 1,[_images count]];
        
        [self.dataOutletContainer applyDataOutlet:self];
        
        UIScrollView * v = (UIScrollView *)[_contentView viewWithTag:200 + _pageIndex];
        
        if([v isKindOfClass:[UIScrollView class]]){
            [v setZoomScale:1.0 animated:YES];
        }
    
        
        for (int i= MAX(_pageIndex -1,0); i < _pageIndex + 1; i ++) {
            
            QDDImageView * imageView = (QDDImageView *) [[_contentView viewWithTag:200 + i] viewWithTag:100];
            
            if([imageView isKindOfClass:[QDDImageView class]] && ![imageView isLoaded] && ![imageView isLoading]){
                
                [self.context handle:@protocol(IVTImageTask) task:imageView priority:0];
                
            }
            
            
        }
    }
    
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    if(_contentView == scrollView){
        return nil;
    }
    
    return [scrollView viewWithTag:100];
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex == 0){
        
        QDDImageView * imageView = (QDDImageView *) [[_contentView viewWithTag:200 + _pageIndex] viewWithTag:100];
        
        
        if([imageView isKindOfClass:[QDDImageView class]]){
            
            if([imageView image] && [imageView image] != [imageView defaultImage]){
                
                UIImageWriteToSavedPhotosAlbum([imageView image], nil, nil, nil);
                
                UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"保存成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                
                [alertView show];
                
            }
            else{
                
                UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"图片还没有下载完成" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                
                [alertView show];
            }
            
        }
        
    }
    
}

@end
