//
//  QDDImageViewController.h
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDViewController.h"

@interface QDDImageViewController : QDDViewController<UIScrollViewDelegate,UIActionSheetDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *contentView;
@property (strong, nonatomic) IBOutletCollection(UIView) NSArray * autoHiddenViews;

 - (IBAction)doImageAction:(id)sender;

@end
