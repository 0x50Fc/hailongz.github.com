//
//  QDDPageDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPageDataSource.h"

#include <objc/runtime.h>


static id QDDPageDataSourceDynamicPropertyGet(id self,SEL sel){
    
    NSString * name = [NSString stringWithCString:sel_getName(sel) encoding:NSUTF8StringEncoding];
    
    return [[self queryValues] valueForKey:name];
    
}

static void QDDPageDataSourceDynamicPropertySet(id self,SEL sel,id value){
    
    NSString * name = [NSString stringWithCString:sel_getName(sel) encoding:NSUTF8StringEncoding];
    
    NSRange r = {3,1};
    NSString * c0 = [name substringWithRange:r];
    
    r.location = 4;
    r.length =[name length] - 5;
    
    name = [[c0 lowercaseString] stringByAppendingString:[name substringWithRange:r]];
    
    [[self queryValues] setValue:value forKey:name];
    
}

@implementation QDDPageDataSource

@synthesize queryValues = _queryValues;
@synthesize allowCached = _allowCached;
@synthesize taskType = _taskType;

+(BOOL) resolveInstanceMethod:(SEL)sel{
    
    BOOL rs = [super resolveInstanceMethod:sel];
    
    if(rs){
        return YES;
    }
    
    NSString * name = [NSString stringWithCString:sel_getName(sel) encoding:NSUTF8StringEncoding];
    
    if([name hasSuffix:@":"]){
         class_addMethod([self class], sel, (IMP)QDDPageDataSourceDynamicPropertySet, "v@:@");
    }
    else{
        class_addMethod([self class], sel, (IMP)QDDPageDataSourceDynamicPropertyGet, "@@:");
    }
    return YES;
}

-(NSMutableDictionary *) queryValues{
    if(_queryValues == nil){
        _queryValues = [[NSMutableDictionary alloc] init];
    }
    return _queryValues;
}

-(void) setPageIndex:(NSInteger)pageIndex{
    [super setPageIndex:pageIndex];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageIndex] forKey:@"pageIndex"];
}

-(void) setPageSize:(NSInteger)pageSize{
    [super setPageSize:pageSize];
    [self.queryValues setValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
}

-(void) reloadData{
    [super reloadData];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
    
}

-(void) loadMoreData{
    [super loadMoreData];
    
    [self.context handle:@protocol(IQDDDownlinkTask) task:self priority:0];
}

-(void) cancel{
    [super cancel];
    
    [self.context cancelHandle:@protocol(IQDDDownlinkTask) task:self];
}


@end
