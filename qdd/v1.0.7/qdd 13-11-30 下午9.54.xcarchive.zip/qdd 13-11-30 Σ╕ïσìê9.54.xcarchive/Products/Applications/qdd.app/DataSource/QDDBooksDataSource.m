//
//  QDDBooksDataSource.m
//  qdd
//
//  Created by zhang hailong on 13-11-15.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksDataSource.h"

#import "QDDBooksObject.h"

#import "QDDClassifyObject.h"

#import "QDDBooksSearchTask.h"

@implementation QDDBooksDataSource

@synthesize date = _date;

-(id) init{
    if((self = [super init])){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(booksChangedAction:) name:QDDBooksChangedNotification object:nil];
    }
    return self;
}

-(void) dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:QDDBooksChangedNotification object:nil];
    

}

-(NSDate *) date{
    if(_date == nil){
        self.date = [NSDate date];
    }
    return _date;
}

-(void) loadDataObjects{
    
    _expendMoney = 0.0;

    [self.dataObjects removeAllObjects];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    NSDateComponents * dateComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:_date];
    NSDateComponents * nowComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:[NSDate date]];
    
    NSRange range = [calendar rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:_date];
    
    if(dateComponents.year == nowComponents.year && dateComponents.month == nowComponents.month){
        
        while(range.length > nowComponents.day){
            range.length --;
        }
        
    }
    
    NSTimeInterval startTime , endTime;
    
    NSDateComponents * components = [[NSDateComponents alloc] init];
    
    [components setYear:dateComponents.year];
    [components setMonth:dateComponents.month];
    [components setDay:1];
    [components setHour:0];
    [components setMinute:0];
    [components setSecond:0];
    
    startTime = [[calendar dateFromComponents:components] timeIntervalSince1970];
    
    [components setDay:range.length];
    [components setHour:23];
    [components setMinute:59];
    [components setSecond:59];
    
    endTime = [[calendar dateFromComponents:components] timeIntervalSince1970];
    
    NSMutableDictionary * dataObjects = [NSMutableDictionary dictionaryWithCapacity:4];
    
    VTDBContext * dbContext = [(id<QDDContext>)self.context userDBContext];
    
    id<IVTSqliteCursor> cursor = [dbContext query:[QDDBooksObject tableClass] sql:[NSString stringWithFormat:@"WHERE [timestamp] >= %d AND [timestamp] <= %d ORDER BY bid ASC",(int)startTime,(int)endTime] data:nil];
    
    while([cursor next]){
        
        QDDBooksObject * dataObject = [[QDDBooksObject alloc] init];
        
        [cursor toDataObject:dataObject];
        
        NSDate * timestamp = [NSDate dateWithTimeIntervalSince1970:dataObject.timestamp];
        
        NSDateComponents * components = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:timestamp];
        
        NSNumber * key = [NSNumber numberWithInt:components.day];
        
        NSMutableArray * items = [dataObjects objectForKey:key];
        
        if(items == nil){
            
            items = [NSMutableArray arrayWithCapacity:4];
            
            [dataObjects setObject:items forKey:key];
        
        }
        
        [items addObject:dataObject];
        
        _expendMoney += dataObject.expendMoney;
        
    }
    
    [cursor close];
    
    NSMutableDictionary * classifys = [NSMutableDictionary dictionaryWithCapacity:4];
    
    for (QDDClassifyObject * dataObject in [[(id<QDDContext>)self.context appDBContext] queryObjects:[QDDClassifyObject tableClass]]) {
        
        NSNumber * cid = [NSNumber numberWithLongLong:dataObject.cid];
        
        [classifys setObject:dataObject forKey:cid];
        
    }
    
    NSNumberFormatter * formatter = [[NSNumberFormatter alloc] init];
    
    [formatter setPositiveFormat:@"￥###,###.##"];
    
    while(range.location <= range.length){
        
        NSMutableDictionary * dataObject = [NSMutableDictionary dictionaryWithCapacity:4];
        
        NSNumber * day = [NSNumber numberWithInteger:range.length];
        
        [dataObject setValue:day forKey:@"day"];
        
        [dataObject setValue:[NSString stringWithFormat:@"%d日",range.length] forKey:@"title"];
      
        [self.dataObjects addObject:dataObject];
        
        NSNumber * key = [NSNumber numberWithInt:range.length];
        
        NSArray * items = [dataObjects objectForKey:key];
        
        if([items count]){
            
            for (QDDBooksObject * item in items) {
                
                NSMutableDictionary * dataItem = [NSMutableDictionary dictionaryWithCapacity:4];
                
                [dataItem setValue:day forKey:@"day"];
                [dataItem setValue:item forKey:@"data"];
                
                NSMutableArray * ctitles = [NSMutableArray arrayWithCapacity:4];
                
                for(id cid in [item cids]){
                    id classifyObject = [classifys objectForKey:[NSNumber numberWithLongLong:[cid longLongValue]]];
                    if(classifyObject){
                        [ctitles addObject:[classifyObject title]];
                    }
                }
                
                if([ctitles count]){
                    if([[item remark] length]){
                        [dataItem setValue:[NSString stringWithFormat:@"%@ %@",[item remark],[ctitles componentsJoinedByString:@"\\"]] forKey:@"title"];
                    }
                    else{
                        [dataItem setValue:[ctitles componentsJoinedByString:@"\\"] forKey:@"title"];
                    }
                }
                else if([[item remark] length]){
                    [dataItem setValue:[item remark] forKey:@"title"];
                }
                else{
                    [dataItem setValue:@"无分类" forKey:@"title"];
                }
                
                [dataItem setValue:[formatter stringFromNumber:[NSNumber numberWithDouble:item.expendMoney]] forKey:@"expendMoney"];
                
                [self.dataObjects addObject:dataItem];
            }
        }
        else{
            [self.dataObjects addObject:[NSMutableDictionary dictionary]];
        }
        
        range.length --;
    }
    
}

-(void) sendSearchTask{
    
    QDDBooksSearchTask * task = [[QDDBooksSearchTask alloc] init];
    
    [task setSource:self];
    [task setDelegate:self];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    NSDateComponents * dateComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:_date];
    NSDateComponents * nowComponents = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:[NSDate date]];
    
    NSRange range = [calendar rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:_date];
    
    if(dateComponents.year == nowComponents.year && dateComponents.month == nowComponents.month){
        
        while(range.length > nowComponents.day){
            range.length --;
        }
        
    }
  
    NSDateComponents * components = [[NSDateComponents alloc] init];
    
    [components setYear:dateComponents.year];
    [components setMonth:dateComponents.month];
    [components setDay:1];
    [components setHour:0];
    [components setMinute:0];
    [components setSecond:0];
    
    task.startTime = [[calendar dateFromComponents:components] timeIntervalSince1970];
    
    [components setDay:range.length];
    [components setHour:23];
    [components setMinute:59];
    [components setSecond:59];
    
    task.endTime = [[calendar dateFromComponents:components] timeIntervalSince1970];
    
    [self.context handle:@protocol(IQDDBooksSearchTask) task:task priority:0];
}

-(void) refreshData{
    
    [self sendSearchTask];
    
    [self loadDataObjects];
    
    if([self.delegate respondsToSelector:@selector(vtDataSourceDidContentChanged:)]){
        [self.delegate vtDataSourceDidContentChanged:self];
    }
    
}

-(void) reloadData{
    
    [self sendSearchTask];
    
    [self loadDataObjects];
    
    if([self.delegate respondsToSelector:@selector(vtDataSourceDidLoaded:)]){
        [self.delegate vtDataSourceDidLoaded:self];
    }
}


-(void) booksChangedAction:(NSNotification *) notification{
    
    [self loadDataObjects];
    
    if([self.delegate respondsToSelector:@selector(vtDataSourceDidContentChanged:)]){
        [self.delegate vtDataSourceDidContentChanged:self];
    }
}


@end
