//
//  QDDPublishService.m
//  qdd
//
//  Created by zhang hailong on 13-11-9.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishService.h"

#import "QDDPublishTask.h"

#import "QDDClassifyObject.h"

#import "QDDTagObject.h"

#import "QDDImageUploadTask.h"

@interface QDDPublishService(){
    NSMutableArray * _workers;
}

@end

@interface QDDPublishImageUploadTask : QDDImageUploadTask

@property(nonatomic,assign) id worker;

@end


@interface QDDPublishWorker : NSObject

@property(nonatomic,retain) id task;
@property(nonatomic,retain) id taskType;

@property(nonatomic,retain) NSArray * imageTasks;

@end

@implementation QDDPublishWorker

-(void) dealloc{
    
    for(QDDPublishImageUploadTask * imageTask in _imageTasks){
        [imageTask setWorker:nil];
    }
    
}
@end


@implementation QDDPublishImageUploadTask


@end

@implementation QDDPublishService

-(void) sendRequestPublishTask:(id<IQDDPublishTask>) task taskType:(Protocol *) taskType imageTasks:(NSArray *) imageTasks{
    
    VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
    
    [httpTask setTaskType:taskType];
    [httpTask setTask:task];
    [httpTask setSource:[task source]];
    
    [httpTask setApiKey:@"url"];
    
    VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
    
    [body addItemValue:@"config_qdd" forKey:@"config"];
    [body addItemValue:@"QDDPublishTask" forKey:@"taskType"];
    [body addItemValue:[task body] forKey:@"qdd-body"];

    NSMutableString * tags = [NSMutableString stringWithCapacity:100];
    
    for(QDDTagObject * tagObject in [task tagObjects]){
        
        if([tags length]){
            [tags appendFormat:@",%@",tagObject.tag];
        }
        else{
            [tags appendString:tagObject.tag];
        }
        
    }
    
    [body addItemValue:tags forKey:@"qdd-tags"];
    
    NSMutableString * cids = [NSMutableString stringWithCapacity:100];
    
    for(QDDClassifyObject * tagObject in [task classifyObjects]){
        
        if([cids length]){
            [cids appendFormat:@",%lld",tagObject.cid];
        }
        else{
            [cids appendFormat:@"%lld",tagObject.cid];
        }
        
    }
    
    [body addItemValue:cids forKey:@"qdd-cids"];
    
    if(imageTasks){
        
        NSMutableArray * images = [NSMutableArray arrayWithCapacity:4];
    
        for(QDDImageUploadTask * imageTask in imageTasks){
            if([imageTask resultsData]){
                
                NSString * width = [NSString stringWithFormat:@"%lf",[imageTask imageSize].width];
                NSString * height = [NSString stringWithFormat:@"%lf",[imageTask imageSize].height];
                NSString * uri = [[imageTask resultsData] dataForKeyPath:@"uri"];
                
                if(uri){
                    [images addObject:[NSDictionary dictionaryWithObjectsAndKeys:uri,@"uri",width,@"width",height,@"height", nil]];
                }
            }
        }
        
        [body addItemValue:[VTJSON encodeObject:images] forKey:@"qdd-images"];
    }
    
    
    [body addItemValue:[NSString stringWithFormat:@"%lf",[task latitude]] forKey:@"qdd-latitude"];
    [body addItemValue:[NSString stringWithFormat:@"%lf",[task longitude]] forKey:@"qdd-longitude"];
    [body addItemValue:[NSString stringWithFormat:@"%lf",[task payMoney]] forKey:@"qdd-payMoney"];
    [body addItemValue:[NSString stringWithFormat:@"%lf",[task expendMoney]] forKey:@"qdd-expendMoney"];
    
    if([task toWeibo]){
        [body addItemValue:@"1" forKey:@"qdd-toWeibo"];
    }
    
    if([task toQQ]){
        [body addItemValue:@"1" forKey:@"qdd-toQQ"];
    }
    
    [httpTask setBody:body];
    
    [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
    
}

-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDPublishTask)){
        
        id<IQDDPublishTask> pubTask = (id<IQDDPublishTask>) task;
        
        if([[pubTask images] count] ==0){
            [self sendRequestPublishTask:pubTask taskType:taskType imageTasks:nil];
        }
        else{
            
            QDDPublishWorker * worker = [[QDDPublishWorker alloc] init];
            
            [worker setTask:task];
            [worker setTaskType:taskType];
            
            NSMutableArray * imageTasks = [NSMutableArray arrayWithCapacity:4];
            
            [worker setImageTasks:imageTasks];
            
            if(_workers== nil){
                _workers = [[NSMutableArray alloc] initWithCapacity:4];
            }
            
            [_workers addObject:worker];
            
            for(UIImage * image in [pubTask images]){
                
                QDDPublishImageUploadTask * imageTask = [[QDDPublishImageUploadTask alloc] init];
                
                [imageTask setSource:[pubTask source]];
                [imageTask setDelegate:self];
                [imageTask setImage:image];
                [imageTask setMaxWidth:640];
                [imageTask setWorker:worker];
                
                [imageTasks addObject:imageTask];
                
                
            }
            
            for(QDDPublishImageUploadTask * imageTask in imageTasks){
                [self.context handle:@protocol(IQDDImageUploadTask) task:imageTask priority:0];
            }
            
        }
        
        return YES;
    }
    else if(taskType == @protocol(IVTAPIResponseTask)){
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDPublishTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
    }
    return NO;
}

-(void) vtUploadTask:(id<IVTUplinkTask>) uplinkTask didSuccessResults:(id) results forTaskType:(Protocol *) taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDPublishImageUploadTask * imageTask = (QDDPublishImageUploadTask *) uplinkTask;
        
        QDDPublishWorker * worker = [imageTask worker];
        
        if(worker){
            
            BOOL isImagePosted = YES;
            
            for(QDDPublishImageUploadTask * t in [worker imageTasks]){
                if([t resultsData] == nil){
                    isImagePosted = NO;
                    break;
                }
            }
            
            if(isImagePosted){
                
                [self sendRequestPublishTask:[worker task] taskType:[worker taskType] imageTasks:[worker imageTasks]];
                
                [_workers removeObject:worker];
            }
        }
    }
    
}

-(void) vtUploadTask:(id<IVTUplinkTask>) uplinkTask didFailWithError:(NSError *)error forTaskType:(Protocol *)taskType{
    
    if(taskType == @protocol(IQDDImageUploadTask)){
        
        QDDPublishImageUploadTask * imageTask = (QDDPublishImageUploadTask *) uplinkTask;
        
        QDDPublishWorker * worker = [imageTask worker];
        
        if(worker){
            
            for(QDDPublishImageUploadTask * t in [worker imageTasks]){
                [t setWorker:nil];
            }
            
            [self vtUploadTask:[worker task] didFailWithError:error forTaskType:[worker taskType]];
            
            [_workers removeObject:worker];
    
        }
    }
}

@end
