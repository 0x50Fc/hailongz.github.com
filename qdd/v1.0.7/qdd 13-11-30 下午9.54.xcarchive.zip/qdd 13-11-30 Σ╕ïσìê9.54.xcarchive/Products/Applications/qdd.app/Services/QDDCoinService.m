//
//  QDDCoinService.m
//  qdd
//
//  Created by zhang hailong on 13-11-30.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDCoinService.h"

#import "QDDCoinTask.h"

@implementation QDDCoinService


-(BOOL) handle:(Protocol *)taskType task:(id<IVTTask>)task priority:(NSInteger)priority{
    
    if(taskType == @protocol(IQDDCoinTask)){
     
        VTAPIRequestTask * httpTask = [[VTAPIRequestTask alloc] init];
        
        [httpTask setTaskType:taskType];
        [httpTask setTask:task];
        [httpTask setSource:[task source]];
        
        [httpTask setApiKey:@"url"];
        
        VTHttpFormBody * body = [[VTHttpFormBody alloc] init];
        
        [body addItemValue:@"config_qdd" forKey:@"config"];
        [body addItemValue:@"QDDCoinTask" forKey:@"taskType"];
       
        [httpTask setBody:body];
        
        [self.context handle:@protocol(IVTAPIRequestTask) task:httpTask priority:0];
        
        return YES;
        
    }
    else if(taskType == @protocol(IVTAPIResponseTask)) {
        
        id<IVTAPIResponseTask> respTask = (id<IVTAPIResponseTask>) task;
        
        if([respTask taskType] == @protocol(IQDDCoinTask)){
            
            int errorCode = [[[respTask resultsData] dataForKeyPath:@"error-code"] intValue];
            
            if(errorCode){
                
                NSString * error = [[respTask resultsData] dataForKeyPath:@"error"];
                
                if(![error isKindOfClass:[NSString class]]){
                    error = @"";
                }
                
                [self vtUplinkTask:[respTask task] didFailWithError:[NSError errorWithDomain:NSStringFromClass([self class]) code:errorCode userInfo:[NSDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey]] forTaskType:[respTask taskType]];
            }
            else{
                
                id results = [[respTask resultsData] dataForKeyPath:@"coin-results"];
                
                if(results){
                    
                    [(id<QDDContext>)self.context setIntegral:[results longLongValue]];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:QDDUserInfoChangedNotification object:nil];
                }
                
                [self vtUplinkTask:[respTask task] didSuccessResults:[respTask resultsData] forTaskType:[respTask taskType]];
            }
            
            return YES;
        }
        
    }
    
    return NO;
}

@end
