//
//  QDDPublishBooksViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDPublishBooksViewController.h"

@interface QDDPublishBooksViewController ()

@end

@implementation QDDPublishBooksViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) booksEditController:(QDDBooksEditController *)controller didFailWithError:(NSError *)error{
    
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:[error QDDMessage] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
    
    [alertView show];
    
}

-(void) booksEditController:(QDDBooksEditController *) controller didSuccessResults:(id) results{
    
    VTAlertView * alertView = [[VTAlertView alloc] initWithTitle:@"保存成功"];
    
    [alertView showDuration:1.2];
    
    [self openUrl:[NSURL URLWithString:@"." relativeToURL:self.url] animated:YES];
    
}

@end
