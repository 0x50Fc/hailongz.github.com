//
//  QDDUserDetailsViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-6.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserDetailsViewController.h"

#import "QDDFollowTask.h"
#import "QDDUnFollowTask.h"

@interface QDDUserDetailsViewController ()

@end

@implementation QDDUserDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSDictionary * queryValues = [self.url queryValues];
   
    self.title = [queryValues valueForKey:@"nick"];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_statusView setStatus:@"loading"];
    
    [_feedController.dataSource setValue:[queryValues valueForKey:@"uid"] forKey:@"uid"];
    [_detailsController.dataSource setValue:[queryValues valueForKey:@"uid"] forKey:@"uid"];

    [_feedController reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) vtDataControllerWillLoading:(VTDataController *)controller{
    if(controller == _feedController){
        [_detailsController reloadData];
    }
}

-(void) vtDataControllerDidLoaded:(VTDataController *)controller{
    [_statusView setStatus:nil];
}

-(void) vtDataController:(VTDataController *)controller didFitalError:(NSError *)error{
    [_statusView setStatus:nil];
}

-(void) refreshFollowButton{
    
    id dataItem = [_detailsController dataItem];
    
        if([[dataItem valueForKey:@"uid"] longLongValue] != [[(id<QDDContext>)self.context uid] longLongValue]){
        
        BOOL isFollow = [[dataItem valueForKey:@"isFollow"] boolValue];
        
        if(isFollow){
            [_followButton setImage:nil forState:UIControlStateNormal];
            [_followButton setTitle:@"已关注" forState:UIControlStateNormal];
        }
        else {
            [_followButton setImage:[UIImage imageNamed:@"ico61.png"] forState:UIControlStateNormal];
            [_followButton setTitle:@"关注" forState:UIControlStateNormal];
        }
        
        [_followButton setHidden:NO];
    }
    else{
        [_followButton setHidden:YES];
    }
}

-(void) userDetailsControllerDidContentSizeChanged:(QDDUserDetailsController *) controller{
    
    CGSize size = [controller contentSize];
    
    CGRect r = [_detailsTableViewCell frame];
    
    r.size.height = size.height - 20;
    
    [_detailsTableViewCell setFrame:r];
    
    [_feedController.tableView reloadData];
   
    [self refreshFollowButton];
    
    [_statusView setStatus:nil];
}


- (IBAction)onFollowAction:(id)sender {
   
    id dataItem = [_detailsController dataItem];
    BOOL isFollow = [[dataItem valueForKey:@"isFollow"] boolValue];
    
    if(isFollow){
        
        QDDUnFollowTask * task = [[QDDUnFollowTask alloc] init];
        
        [task setTuid:[[dataItem valueForKey:@"uid"] longLongValue]];
        
        [self.context handle:@protocol(IQDDUnFollowTask) task:task priority:0];
        
        _detailsController.fansCount --;
        
    }
    
    else{
        QDDFollowTask * task = [[QDDFollowTask alloc] init];
        
        [task setTuid:[[dataItem valueForKey:@"uid"] longLongValue]];
        
        [self.context handle:@protocol(IQDDFollowTask) task:task priority:0];
        
        _detailsController.fansCount ++;
    }
    
    [dataItem setValue:[NSNumber numberWithBool:!isFollow] forKey:@"isFollow"];
    
    [self refreshFollowButton];
}


-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [action actionName];
    
    if([actionName isEqualToString:@"feed"]){
        
        NSURL * url = [NSURL URLWithString:@"user-details/feed-details"
                             relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:[element attributeValueForKey:@"pid"] forKey:@"pid"]];
        
        [self openUrl:url animated:YES];
        
    }
    
    else if([actionName isEqualToString:@"user"]){
        
        
        
    }
}

@end
