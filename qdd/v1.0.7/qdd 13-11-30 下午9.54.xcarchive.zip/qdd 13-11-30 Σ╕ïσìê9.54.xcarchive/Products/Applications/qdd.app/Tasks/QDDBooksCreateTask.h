//
//  QDDBooksCreateTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-16.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <vTeam/vTeam.h>

#import "IQDDAPITask.h"

@protocol IQDDBooksCreateTask <IQDDAPITask,IVTUplinkTask>

@property(nonatomic,assign) double payMoney;
@property(nonatomic,assign) double expendMoney;
@property(nonatomic,assign) double latitude;
@property(nonatomic,assign) double longitude;
@property(nonatomic,retain) NSString * shopTitle;
@property(nonatomic,retain) NSString * shopAddress;
@property(nonatomic,retain) NSString * remark;
@property(nonatomic,retain) NSArray * classifyObjects;

@end

@interface QDDBooksCreateTask : VTUplinkTask<IQDDBooksCreateTask>

@end
