//
//  QDDConcernTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDConcernTask.h"

@implementation QDDConcernTask

@synthesize status = _status;
@synthesize pageIndex = _pageIndex;

@end
