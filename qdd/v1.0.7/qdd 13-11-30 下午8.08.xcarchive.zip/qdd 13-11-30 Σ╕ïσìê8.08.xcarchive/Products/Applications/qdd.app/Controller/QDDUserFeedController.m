//
//  QDDUserFeedController.m
//  qdd
//
//  Created by zhang hailong on 13-11-23.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDUserFeedController.h"

#import "QDDFeedDocumentController.h"

@implementation QDDUserFeedController

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataSource count] + [self.headerCells count] + [self.footerCells count];
}

-(void) document:(VTDOMDocument *)document willLoadDataObject:(id)dataObject{
    
    [QDDFeedDocumentController document:document willLoadDataObject:dataObject context:self.context];
    
    VTDOMElement * element = [document elementById:@"bg"];
    
    if(element){
        
        NSUInteger index =  [[self.dataSource dataObjects] indexOfObject:dataObject];
        
        if(index % 2 !=0){
            [element setAttributeValue:@"#f7e3db" forKey:@"background-color"];
        }
        else{
            [element setAttributeValue:@"#f8ece5" forKey:@"background-color"];
        }
        
    }
    
}

@end
