//
//  QDDCommentViewController.m
//  qdd
//
//  Created by zhang hailong on 13-11-5.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDCommentViewController.h"

@interface QDDCommentViewController ()

@end

@implementation QDDCommentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [_statusView setStatus:@"loading"];
    
    [_listController reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) vtDocumentDataController:(VTDocumentDataController *) dataController element:(VTDOMElement *) element
                        doAction:(id<IVTAction>) action{
    
    NSString * actionName = [element attributeValueForKey:@"action-name"];
    
    if([actionName isEqualToString:@"reply"]){
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:4];
        
        [queryValues setValue:[element attributeValueForKey:@"cid"] forKey:@"cid"];
        [queryValues setValue:[NSString stringWithFormat:@"回复: %@",[element attributeValueForKey:@"nick"]] forKey:@"title"];
        
        [self openUrl:[NSURL URLWithString:@"pop:///publish-comment"
                               queryValues:queryValues] animated:YES];
    }
    else if([actionName isEqualToString:@"user"]){
        
        id uid = [element attributeValueForKey:@"uid"];
        
        NSMutableDictionary * queryValues = [NSMutableDictionary dictionaryWithCapacity:2];
        
        [queryValues setValue:uid forKey:@"uid"];
        [queryValues setValue:[element attributeValueForKey:@"nick"] forKey:@"nick"];
        
        [self openUrl:[NSURL URLWithString:@"root:///root/fold/center/comment/user-details" relativeToURL:self.url queryValues:queryValues] animated:YES];
        
    }
    else if([actionName isEqualToString:@"feed"]){
        
        UIView * v = element.delegate;
        
        while(v && ![v isKindOfClass:[UITableViewCell class]]){
            
            v = [v superview];
        }
        
        if([v isKindOfClass:[UITableViewCell class]]){
        
            NSIndexPath * indexPath = [dataController.tableView indexPathForCell:(UITableViewCell *)v];
            
            id dataItem = [dataController dataObjectByIndexPath:indexPath];
            
            id feed = [dataItem dataForKeyPath:@"publish"];
            
            if(feed){
            
                [self.context setFocusValue:feed forKey:@"feed"];
                
                NSURL * url = [NSURL URLWithString:@"root:///root/fold/center/comment/feed-details" relativeToURL:self.url queryValues:[NSDictionary dictionaryWithObject:[element attributeValueForKey:@"pid"] forKey:@"pid"]];
                
                [self openUrl:url animated:YES];
            }
        }
        
    }
    
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [_listController.tableView reloadData];
    
}

-(void) vtDataController:(VTDataController *)controller didFitalError:(NSError *)error{
    [_statusView setStatus:nil];
}

-(void) vtDataControllerDidLoaded:(VTDataController *)controller{
    [_statusView setStatus:nil];
}

-(void) vtDataControllerDidLoadedFromCache:(VTDataController *)controller timestamp:(NSDate *)timestamp{
    [_statusView setStatus:nil];
}


@end
