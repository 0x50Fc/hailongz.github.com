//
//  QDDBooksCreateTask.m
//  qdd
//
//  Created by zhang hailong on 13-11-16.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import "QDDBooksCreateTask.h"

@implementation QDDBooksCreateTask

@synthesize payMoney = _payMoney;
@synthesize expendMoney = _expendMoney;
@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@synthesize shopTitle = _shopTitle;
@synthesize shopAddress = _shopAddress;
@synthesize remark = _remark;
@synthesize classifyObjects = _classifyObjects;

@end
