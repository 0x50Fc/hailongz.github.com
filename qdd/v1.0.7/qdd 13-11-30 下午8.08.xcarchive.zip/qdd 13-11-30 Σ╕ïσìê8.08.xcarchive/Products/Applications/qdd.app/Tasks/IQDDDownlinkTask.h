//
//  IQDDDownlinkTask.h
//  qdd
//
//  Created by zhang hailong on 13-11-7.
//  Copyright (c) 2013年 9vteam. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IQDDAPITask.h"

@protocol IQDDDownlinkTask <IQDDAPITask,IVTDownlinkPageTask>

@property(nonatomic,assign,getter = isAllowCached) BOOL allowCached;
@property(nonatomic,readonly) NSMutableDictionary * queryValues;
@property(nonatomic,retain) NSString * taskType;

@end
